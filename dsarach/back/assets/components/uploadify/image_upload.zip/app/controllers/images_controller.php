<?php
class ImagesController extends AppController
{
	var $name = 'Images';
	var $components = array('Upload','RequestHandler');
	var $helpers = array('Html','Form','Javascript');
	var $uses = array('Image','Tempfile');
	
	function beforeFilter()
	{
		if($this->action == 'upload'){
			if (isset($this->params['pass'][0])){
				$this->Session->id($this->params['pass'][0]);
				$this->Session->start();
			}else{
				$this->redirect('/');
			}
		}
		// Si utilizamos Auth debemos dar permiso a todo el mundo a las acciones 'upload' y 'ajax_add'
		//$this->Auth->allowedActions = array('upload','ajax_add');
		parent::beforeFilter();
	}

	function add()
	{
		Configure::write('debug',0);
		$images = $this->Image->find('all',array('fields'=>array('Image.id','Image.file')));
		foreach ($images as $image){
			$this->Image->delete($image['Image']['id']);
			@unlink(WWW_ROOT.'img/upload/thumb/'.$image['Image']['file']);
			@unlink(WWW_ROOT.'img/upload/full/'.$image['Image']['file']);
		}
		$tempfiles = $this->Tempfile->find('all',array('fields'=>array('Tempfile.id','Tempfile.location')));
		foreach ($tempfiles as $tempfile){
			$this->Tempfile->delete($tempfile['Tempfile']['id']);
			@unlink($tempfile['Tempfile']['location']);
		}
		$this->pageTitle = "Carga de ficheros con Uploadify y CakePHP";
	}

	function upload()
	{
		Configure::write('debug', 0);
		//header("Content-type: text/x-json");
		$this->autoRender = false;
		$this->layout = 'ajax';
		if (isset($this->params['form']['Filedata'])){
// Si utilizáis Auth eliminad estos comentarios
//			$user = $this->Auth->user();
//			if (!empty($user)){
				// Creamos la primera miniatura
				$thumb = $this->Upload->upload(
					$this->params['form']['Filedata'],'img/upload/thumb/', null, 
					array(
						'type' => 'resizecrop',
						'size' => array(400,250),
						'output' => 'jpg',
						'quality'=>80),
					array('jpg','jpeg','png','gif'));
				// Si no se crea correctamente gestionamos los errores
				if (!empty($this->Upload->errors)){
					// Error que mostraremos al usuario
					$message = __("Error subiendo el fichero",true);
					// Guardamos el nombre original del fichero
					$data = $this->params['form']['Filedata']['name'];
					$this->set('errors', compact('message','data'));
					// Creamos un log con el auténtico error
					$this->log("Error creando la miniatura: " . 
						implode(" | ",$this->Upload->errors),'upload/images');
				} else {
					// Si se ha guardado correctamente guardamos el 'fichero temporal' en la BD
					$file = $this->Upload->result;
					$location = realpath(WWW_ROOT . 'img/upload/thumb/' . $file);
					$tempfile['location'] = $location;
					$this->Tempfile->save($tempfile,false);
					// Generamos una miniatura temporal (la que mostraremos al usuario al guardar las imágenes)
					$tempThumb = $this->Upload->upload(
						$this->params['form']['Filedata'],'img/upload/tmp/', null, 
						array(
							'type' => 'resizecrop',
							'size' => array(100,150),
							'output' => 'jpg',
							'quality'=>80),
						array('jpg','jpeg','png','gif'));
					if(!empty($this->Upload->errors)){
						// Si tiene errores lo guardamos en un log. A mi parecer, aquí no nos interesa mostrar error al usuario (ya que en realidad es una imagen temporal que más adelante borraremos) 
						$this->log("Error creando la miniatura temporal: " . 
							implode(" | ",$this->Upload->errors),'upload/images');
					} else {
						// Si no hay errores guardamos el 'fichero temporal'
						$location = realpath(WWW_ROOT . 'img/upload/tmp/' . $this->Upload->result);
						$tempfile['location'] = $location;
						// Es importante hacer el 'create' a partir de la segunda vez
						$this->Tempfile->create($tempfile);
						$this->Tempfile->save();
					}
					// Si se ha creado la primera miniatura subimos la original a la carpeta deseada
					$result = $this->Upload->upload($this->params['form']['Filedata'], 'img/upload/full/', $this->Upload->result);
					if (!empty($this->Upload->errors)){
						// Si no se guarda generamos log
						$this->log("Error subiendo la imagen: " . 
							implode(" | ",$this->Upload->errors),'upload/images');
						// Y mostramos mensaje de error al usuario
						$message = __("Error subiendo el fichero",true);
						$data = $this->params['form']['Filedata']['name'];
						$this->set('errors', compact('message','data'));
					}else{
						// Guardamos 'fichero temporal'
						$data = $this->Upload->result;
						$location = realpath(WWW_ROOT . 'img/upload/full/' . $data);
						$tempfile['location'] = $location;
						$this->Tempfile->create($tempfile);
						$this->Tempfile->save();
						// Mostramos mensaje de éxito al usuario
						$message = sprintf(__("%s subido correctamente.",true),"<b>" . $this->params['form']['Filedata']['name'] . "</b>");
						$this->set('success',compact('data','message'));
					}
				}
// Si utilizáis Auth eliminad estos comentarios
//			}else{
//    			$message = "<b>" . __("Error",true) . ":</b> " . __("Tu sesión ha expirado. Vuelve a iniciarla por favor",true);
//				$this->set('sessionTimeOut',compact('message'));
//			}
			// Renderizamos la vista (/views/ajax/upload.ctp)
			$this->render('/ajax/upload');
		}
	}

	function ajaxAdd()
	{
		Configure::write('debug', 0);
		$this->autoRender = false;
		$this->layout = 'ajax';
		if ($this->RequestHandler->isAjax()){
			if (!empty($this->data)){
				//$user = $this->Auth->user();
				//if (!empty($user)){
					// Inicializamos las variables que contendrán errores y demás información
					$data = $dataOk = array();
					$error = false;
					// Iniciamos un bucle con todas las imágenes que recibamos
					foreach($this->data['Image']['name'] as $key=>$name){
						// Nombre de fichero
						$imageFile = $this->data['Image']['file'][$key];
						// Datos a guardar de la imagen
						$imageData = array(
							'Image'=>array(
								'name'		=> $name,
								'tags'		=> $this->data['Image']['tags'][$key],
								'description'=>$this->data['Image']['description'][$key],
								'file'		=> $imageFile));
						// Inicializamos el modelo (importante ya que estamos haciendo un bucle)
						$this->Image->create($imageData);
						// Validamos los campos
						if ($this->Image->validates()){
							// Guardamos la imagen en la base de datos
							$image = $this->Image->save($imageData);
							if (!empty($image)){
								// Eliminamos los 'ficheros temporales'
								$location = array('tmp','full','thumb');
								foreach ($location as $dir){
									$loc = realpath(WWW_ROOT . 'img/upload/' . $dir . '/' . $imageFile);
									$this->log($loc);
									// Si la carpeta es "tmp" eliminamos la imagen del servidor
									if($dir == 'tmp'){
										if (!unlink($loc)) $this->log('Error eliminando miniatura temporal ' . $imageFile);
										else $this->Tempfile->deleteAll(array('Tempfile.location'=>$loc)); 
									}else $this->Tempfile->deleteAll(array('Tempfile.location'=>$loc));
								}
								// Mensaje a mostrar cuando una sola imagen es guardada
								$message = sprintf(__("Imagen %s guardada correctamente",true),$imageFile);
								$dataOk[$key] = array('message'=>$message,'data'=>$imageFile);
							}
						}else {
							// Errores
							$error = true;
							$Image = $this->Image->invalidFields();
							$data[$key] = compact('Image');
						}
					}
					// Si no tenemos errores..
					if(!$error){
						$message = "<b>" . __("Todas las imágenes han sido guardadas correctamente", true) . "</b>";
						$data = $this->data;
						$this->set('success',compact('message','data'));
					} else {
						$message = "<b>" . __("Error",true) . ":</b> " . __("Hay campos que no son válidos, compruébalos por favor.",true);
						$set = compact('message','data');
						// Si tenemos algunas imágenes guardadas y otras no guardamos la variable dataOk
						if(!empty($dataOk)) $set = array_merge($set,compact('dataOk'));
						$this->set('errors',$set); 
					}
// Auth
//        		}else{
//        			$message = "<b>" . __("Error",true) . ":</b> " . __("Tu sesión ha expirado. Vuelve a iniciarla por favor",true);
//					$data = $this->data;
//					$this->set('sessionTimeOut',compact('message','data'));
//        		}
// fin Auth
	    	}
			$this->render('/ajax/form_validation_array');
	    }else $this->redirect('/');
	}
}
