<?php
class Image extends AppModel {
	var $name = 'Image';
	var $validate = array(
		'name'=>array(
			'length'=>array(
				'rule'=>array('between',3,45),
				'message'=>"El nombre debe contener entre 3 y 45 caracteres")),
		'description'=>array(
			'length'=>array(
				'rule'=>array('maxLength',100),
				'message'=>"La descripción no puede tener más de 255 caracteres")));
}