<?php
class Tempfile extends AppModel
{
	var $name = 'Tempfile';
}
