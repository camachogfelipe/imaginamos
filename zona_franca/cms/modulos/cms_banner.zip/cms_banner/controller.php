<?php
/*
 * @file               : cms_banner.db.php
 * @brief              : Clase para la interaccion con la tabla cms_banner
 * @version            : 3.3
 * @ultima_modificacion: 2013-05-28
 * @author             : Carlos A. Mock-kow M.
 * @generated          : Generador DAO version 1.1
 *
 * @class: DbcmsBanner
 * @brief: Clase para la interaccion con la tabla cms_banner
 */

class controller
{
  public $mSiteUrl      = NULL;
  public $mThisUrl      = NULL;
  public $mCrear        = NULL;
  public $mEditar       = NULL;
  public $mElimin       = NULL;
  public $mList         = NULL;
  public $mModo         = NULL;
  public $mData         = NULL;

  /*
   * Constructor de clase
   * @fn __construct
   * @brief Inicializa las variables necesarias de la clase
   */
  public function __construct()
  {
    $this -> mIdSeccion = GetData( "id", NULL );

    $this -> mSiteUrl = Link::Build("");

    if( NULL != $this -> mIdSeccion )
    {
      $this -> mThisUrl = Link::ToSection( array( "s" => $_GET["seccion"], "i" => $this -> mIdSeccion ) );
      $this -> mCrear   = Link::ToSection( array( "s" => $_GET["seccion"], "m" => "create", "i" => $this -> mIdSeccion ) );
      $this -> mRegres  = Link::ToSection( array( "s" => "cms_secciones", "m" => "list" ) );
    }
    else
    {
      $this -> mThisUrl = Link::ToSection( array( "s" => $_GET["seccion"] ) );
      $this -> mCrear   = Link::ToSection( array( "s" => $_GET["seccion"], "m" => "create" ) );
      $this -> mRegres  = Link::Build("");
    }

    $this -> mEditar  = Link::ToSection( array( "s" => $_GET["seccion"], "m" => "edit" ) );
    $this -> mElimin  = Link::ToSection( array( "s" => $_GET["seccion"], "m" => "delete" ) );

    //Verifica los permisos del usuario
    //si la seccion es publica eliminar o comentar
    $mOpciones = array( "clase" => "cms_banner" );

    $mValida = havePermision( $mOpciones );
    if( TRUE !== $mValida )
    {
      header( "location:".$this->mSiteUrl );
    }
  }

  /*
   * Funcion principal
   * @fn init
   * @brief Logica del modulo
   */
  public function init()
  {
    $this -> mModo = GetData( "modo", "list" );

    switch( strtolower( $this -> mModo ) )
    {
      case "save":
      {

        $mId = GetData( "id", FALSE );

        $mBanner = new Dbcms_banner();

        if( FALSE !== $mId )
          $mBanner -> getByPk( $mId );

        $mIdSeccion = GetData( "id_seccion" );

        $mBanner -> setid_seccion( $mIdSeccion );
        $mBanner -> settxt_titulo( GetData( "txt_titulo" ) );
        $mBanner -> settxt_descripcion( GetData( "txt_descripcion" ) );
        $mBanner -> setfil_image( GetData( "default.jpg" ) );
        $mBanner -> setind_estado( "1" );
        $mBanner -> setfec_creasi( date( "Y-m-d h:i:s" ) );
        $mBanner -> save();

        if( FALSE === $mId )
          $mId = $mBanner -> getMaxId();

        $retorno = ClassFile::UploadImagenFile( "fil_image", FILES_DIR."banner", "bann_".$mIdSeccion."_".$mId, "thum_".$mIdSeccion."_".$mId, 330, 200 );

        if ( $retorno["Status"]=="Uploader" )
        {
          $mBanner -> getByPk( $mId );
          $mBanner -> setfil_image( $mIdSeccion."_".$mId.$retorno["Ext"] );
          $mBanner -> save();
        }

        header( "location: ".GetData( "redirect" ) );
        break;
      }

      case "list":
      {

        if( NULL != $this -> mIdSeccion )
        {
          $mQuery = "SELECT a.id, a.txt_titulo, a.txt_descripcion, a.fil_image, a.id_seccion ".
                      "FROM cms_banner AS a ".
                     "WHERE a.ind_estado = '1' ".
                       "AND a.id_seccion = '".$this -> mIdSeccion."' ";
        }
        else
        {
          $mQuery = "SELECT a.id, a.txt_titulo, a.txt_descripcion, ".
                           "a.fil_image, a.id_seccion, b.txt_titulo AS nom_seccion ".
                      "FROM cms_banner AS a LEFT JOIN cms_secciones AS b ON a.id_seccion = b.id ".
                     "WHERE a.ind_estado = '1' ";
        }

        $lista = new DinamicList( $this -> mThisUrl );
        $lista -> setQuery( $mQuery );
        $lista -> setAction( $this -> mThisUrl );

        $lista -> setHeader( "Titulo", array( "dbfield" => "a.txt_titulo" ) );

        if( NULL == $this -> mIdSeccion )
          $lista -> setHeader( "Seccion", array( "dbfield" => "nom_seccion",
                                               "filtfield" => "b.txt_titulo" ) );

        $lista -> setHeader( "Descripcion", array( "dbfield" => "a.txt_descripcion" ) );
        //$lista -> setHeader( "Imagen", array( "dbfield" => "a.fil_image" ) );

        $lista -> setHidden( "id", array( "label" => "id_banner" ) );
        $lista -> setHidden( "id_seccion", array( "label" => "id" ) );
        $lista -> setButton( "action", "Editar", array( "action" => $this -> mEditar ) );

        if( "1" == $_SESSION["user"]["ind_delete"] )
          $lista -> setButton( "action", "Eliminar", array( "action" => $this -> mElimin,
                                                           "confirm" => "Seguro que desea eliminar este cliente?" ) );

        $this -> mList = $lista -> generateList( "cms_bannerList" );
        break;
      }

      case "create":
      {
        //Inicializamos las variables
        $this -> mData["id"] = NULL;
        $this -> mData["id_seccion"] = $this -> mIdSeccion;
        $this -> mData["txt_titulo"] = NULL;
        $this -> mData["txt_descripcion"] = NULL;
        $this -> mData["fil_image"] = NULL;
        $this -> mData["ind_estado"] = NULL;
        $this -> mData["fec_creasi"] = date( "Y-m-d h:i:s" );

        if( NULL == $this -> mIdSeccion )
        {
          // Obtener listado de modulos
          $cSecciones = new Dbcms_secciones();
          $this -> mSecciones = $cSecciones -> getList( array( "ind_estado" => "1" ) );
        }
        else
          $this -> mSecciones = NULL;

        break;
      }

      case "edit":
      {
        //Obtenemos el registro deseado por llave primaria
        $mId = GetData( "id_banner" );

        $cData = new Dbcms_banner();
        $this -> mData = $cData -> getByPk( $mId );

        if( NULL == $this -> mIdSeccion )
        {
          // Obtener listado de modulos
          $cSecciones = new Dbcms_secciones();
          $this -> mSecciones = $cSecciones -> getList( array( "ind_estado" => "1" ) );
        }
        else
          $this -> mSecciones = NULL;
        break;
      }

      case "delete":
      {
        //Obtenemos el registro deseado por llave primaria
        $mId = GetData( "id" );

        $cData = new Dbcms_banner();
        $cData -> getByPk( $mId );
        $cData -> deleteLogic();
        break;
      }
    }
  }
}
?>