-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 28-05-2013 a las 12:06:50
-- Versión del servidor: 5.5.31
-- Versión de PHP: 5.3.10-1ubuntu3.6

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT=0;
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Base de datos: `db_contitucionaldia`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_banner`
--

CREATE TABLE IF NOT EXISTS `cms_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_seccion` int(11) NOT NULL,
  `txt_titulo` varchar(45) NOT NULL,
  `txt_descripcion` varchar(255) NOT NULL,
  `fil_image` varchar(255) NOT NULL,
  `ind_estado` varchar(2) NOT NULL DEFAULT '1',
  `fec_creasi` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_seccion` (`id_seccion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cms_banner`
--
ALTER TABLE `cms_banner`
  ADD CONSTRAINT `cms_banner_ibfk_1` FOREIGN KEY (`id_seccion`) REFERENCES `cms_secciones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

--
-- Modificacion para la tabla `cms_secciones`
--

ALTER TABLE `cms_secciones`  ADD `ind_banner` VARCHAR(2) NOT NULL DEFAULT '0' AFTER `ind_estado`


