<?php
/*
 * @file               : cms_secciones.db.php
 * @brief              : Clase para la interaccion con la tabla cms_secciones
 * @version            : 3.3
 * @ultima_modificacion: 2013-05-24
 * @author             : Carlos A. Mock-kow M.
 * @generated          : Generador DAO version 1.1
 *
 * @class: DbcmsSecciones
 * @brief: Clase para la interaccion con la tabla cms_secciones
 */

class controller
{
  public $mSiteUrl      = NULL;
  public $mThisUrl      = NULL;
  public $mVolver       = NULL;
  public $mCrear        = NULL;
  public $mEditar       = NULL;
  public $mElimin       = NULL;
  public $mList         = NULL;
  public $mModo         = NULL;
  public $mData         = NULL;
  public $mBanner       = NULL;

  /*
   * Constructor de clase
   * @fn __construct
   * @brief Inicializa las variables necesarias de la clase
   */
  public function __construct()
  {
    $this -> mSiteUrl = Link::Build("");
    $this -> mThisUrl = Link::ToSection( array( "s" => $_GET["seccion"] ) );
    $this -> mCrear   = Link::ToSection( array( "s" => $_GET["seccion"], "m" => "create" ) );
    $this -> mEditar  = Link::ToSection( array( "s" => $_GET["seccion"], "m" => "edit" ) );
    $this -> mElimin  = Link::ToSection( array( "s" => $_GET["seccion"], "m" => "delete" ) );

    $this -> mBanner  = Link::ToSection( array( "s" => "cms_banner", "m" => "list" ) );

    //Verifica los permisos del usuario
    //si la seccion es publica eliminar o comentar
    $mOpciones = array( "clase" => "cms_secciones" );

    $mValida = havePermision( $mOpciones );
    if( TRUE !== $mValida )
    {
      header( "location:".$this->mSiteUrl );
    }
  }

  /*
   * Funcion principal
   * @fn init
   * @brief Logica del modulo
   */
  public function init()
  {
    $this -> mModo = GetData( "modo", "list" );

    switch( strtolower( $this -> mModo ) )
    {
      case "list":
      {
        /* Consulta para generar el listado si no tiene banners. */
        $mQuery = "SELECT id, txt_titulo, txt_descripcion, ind_estado, ".
                         "fec_creasi ".
                    "FROM cms_secciones ".
                   "WHERE ind_estado = '1' ";

        /* Consulta si para generar el listado si tiene banners. *
        $mQuery = "SELECT id, txt_titulo, txt_descripcion, ind_estado, ".
                         "fec_creasi, ind_banner ".
                    "FROM cms_secciones ".
                   "WHERE ind_estado = '1' ";
        /* */

        $lista = new DinamicList( $this -> mThisUrl );
        $lista -> setQuery( $mQuery );
        $lista -> setAction( $this -> mThisUrl );
        $lista -> setHeader( "Titulo", array( "dbfield" => "txt_titulo" ) );
        $lista -> setHeader( "Descripcion", array( "dbfield" => "txt_descripcion" ) );

        $lista -> setHidden( "id", array( "label" => "id" ) );
        $lista -> setButton( "action", "Editar", array( "action" => $this -> mEditar ) );

        /* boton banner *
        $lista -> setButton( "action", "Banner", array( "action" => $this -> mBanner,
                                                     "condition" => array( array( "field" => "ind_banner", "value" => "1" ) ) ) );
        /* */

        if( "1" == $_SESSION["user"]["ind_delete"] )
          $lista -> setButton( "action", "Eliminar", array( "action" => $this -> mElimin,
                                                           "confirm" => "Seguro que desea eliminar este cliente?" ) );

        $this -> mList = $lista -> generateList( "cms_seccionesList" );
        break;
      }

      case "create":
      {
        //Inicializamos las variables
        $this -> mData["id"] = NULL;
        $this -> mData["txt_titulo"] = NULL;
        $this -> mData["txt_descripcion"] = NULL;
        $this -> mData["ind_estado"] = 1;
        $this -> mData["fec_creasi"] = date( "Y-m-d h:i:s" );

        break;
      }

      case "edit":
      {
        //Obtenemos el registro deseado por llave primaria
        $mId = GetData( "id" );

        $cData = new Dbcms_secciones();
        $this -> mData = $cData -> getByPk( $mId );
        break;
      }

      case "delete":
      {
        //Obtenemos el registro deseado por llave primaria
        $mId = GetData( "id" );

        $cData = new Dbcms_secciones();
        $cData -> getByPk( $mId );
        $cData -> deleteLogic();
        break;
      }
    }
  }
}
?>