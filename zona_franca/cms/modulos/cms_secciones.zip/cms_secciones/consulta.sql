-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 27-05-2013 a las 09:24:15
-- Versión del servidor: 5.5.31
-- Versión de PHP: 5.3.10-1ubuntu3.6

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT=0;
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Base de datos: `db_contitucionaldia`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_secciones`
--

CREATE TABLE IF NOT EXISTS `cms_secciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txt_titulo` varchar(45) NOT NULL,
  `txt_descripcion` text NOT NULL,
  `ind_estado` varchar(2) NOT NULL DEFAULT '1',
  `fec_creasi` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;
