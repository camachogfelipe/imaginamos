== About ===============================================================================

Software: Text Chat Room
Developer: Pro Chat Rooms
Url: http://prochatrooms.com

========================================================================================


== Information =========================================================================

Pro Chat Rooms is NOT free software - For more details visit, http://www.prochatrooms.com
This software and all of its source code/files are protected by Copyright Laws. 
The software license permits you to install this software and/or plugin on one domain only.
Pro Chat Rooms is unable to provide support if this software is modified by the end user. 

========================================================================================


== New Installation Only ===============================================================

Upload the folder 'prochatrooms' to your server (eg. http://yoursite.com/prochatrooms)

Type the url to the 'prochatrooms/install/' folder in your browser address bar and follow the on-screen prompts.

========================================================================================


== Upgrade 7.x.x to 8.x.x ==============================================================

IMPORTANT: BEFORE UPGRADING THE CHAT ROOM SOFTWARE CREATE A BACKUP COPY OF YOUR EXISTING
CHAT ROOM SOFTWARE AND CHAT ROOM MySQL DATABASE. PROCHATROOMS DOES NOT ACCEPT ANY 
RESPONSIBLITITY FOR LOSS OF USER DATA DURING UPGRADING THE CHAT ROOM SOFTWARE.

Upload the folder 'prochatrooms' to your server (eg. http://yoursite.com/prochatrooms)

Type the url to the 'prochatrooms/install/upgrade/' folder in your browser address bar and follow the on-screen prompts.

NOTE: You must enter your version 7.x.x chat room MySQL database details during installation

========================================================================================


== CMS Integration =====================================================================

Refer to the online integration documents,

http://prochatrooms.com/clients.php

========================================================================================


== Support =============================================================================

:: Community Support

http://community.prochatrooms.com

:: Technical Support

http://support.prochatrooms.com

========================================================================================

