<?php

/*
* Software Version
* Inc. Patch Release
*/

$CONFIG['version'] = 'v8.0.5';

?>