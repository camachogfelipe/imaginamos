

<div style="width: 300px ;margin-left: auto ;margin-right: auto ;">

<span class="result">
	&nbsp;<?php echo $result;?>
</span>

<form action ="index.php" method="post" name="login" style="width:300px;">

  	<table>

		<?php echo $html;?>

	</table>

</form>

</div>

<br>
