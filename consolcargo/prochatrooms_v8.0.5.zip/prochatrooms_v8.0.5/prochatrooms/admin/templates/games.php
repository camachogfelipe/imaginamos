
<div>

<span class="result">
	&nbsp;<?php echo $result;?>
</span>

<form enctype="multipart/form-data" action ="index.php?option=games" method="post" name="games">

	<table>

		<?php echo $html;?>

	</table>

</form>

</div>