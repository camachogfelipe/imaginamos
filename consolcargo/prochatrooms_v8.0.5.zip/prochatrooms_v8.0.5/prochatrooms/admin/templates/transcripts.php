
<div>

<span class="result">
	&nbsp;<?php echo $result;?>
</span>

<form action ="index.php?option=transcripts&page=<?php echo $_GET['page'];?>" method="post" name="transcripts">

	<table> 

		<?php echo $html;?>

	</table>

</form>

</div>