
<br>

<div class="footer">
	<span style="color: #FFFFFF;"><?php echo copyrightFooter();?></a>
</div> 

</body>
</html>