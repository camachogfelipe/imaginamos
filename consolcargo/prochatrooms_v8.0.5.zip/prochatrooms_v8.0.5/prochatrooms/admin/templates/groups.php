
<div>

<span class="result">
	&nbsp;<?php echo $result;?>
</span>

<form action ="index.php?option=groups" method="post" name="groups">

	<table>

		<?php echo $html;?>

	</table>

</form>

</div>