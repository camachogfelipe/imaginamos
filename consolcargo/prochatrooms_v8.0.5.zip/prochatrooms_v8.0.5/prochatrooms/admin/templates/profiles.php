
<div>

<span class="result">
	&nbsp;<?php echo $result;?>
</span>

<form action ="index.php?option=profiles" method="post" name="profiles">

	<table>

		<?php echo $html;?>

	</table>

</form>

</div>