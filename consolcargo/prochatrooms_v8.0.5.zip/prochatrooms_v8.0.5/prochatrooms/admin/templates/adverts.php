
<div>

<span class="result">
	&nbsp;<?php echo $result;?>
</span>

<form action ="index.php?option=adverts" method="post" name="adverts">

	<table>

		<?php echo $html;?>

	</table>

</form>

</div>