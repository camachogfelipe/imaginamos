:: [Tutorial] How to create a plugin for userlist

http://community.prochatrooms.com/viewtopic.php?f=78&t=1161