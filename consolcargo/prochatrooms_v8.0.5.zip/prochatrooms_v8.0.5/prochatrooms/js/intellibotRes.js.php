<?php

/**
 * Declare header
*/

header("content-type: application/x-javascript");

?>

/*
* intellibot engine
* version 3.0.0
* (c)Pro Chat Rooms
*/

/*
* user
* welcome messages
*/

var uEntryResponse = new Array();

uEntryResponse[0]="hey"; 
uEntryResponse[1]="hello";

/*
* intellibot
* welcome responses
*/

var iEntryResponse = new Array();

iEntryResponse[0]="hey"; 
iEntryResponse[1]="hello";
iEntryResponse[2]="hey there";
iEntryResponse[2]="welcome";

/*
* user
* goodbye responses
*/

var uExitResponse = new Array();

uExitResponse[0]="bye"; 
uExitResponse[1]="see yer";
uExitResponse[2]="outta here";

/*
* intellibot
* goodbye responses
*/

var iExitResponse = new Array();

iExitResponse[0]="bye"; 
iExitResponse[1]="safe journey!";
iExitResponse[2]="thanks for visiting";

/*
* user
* help responses
*/

var uHelpResponse = new Array();

uHelpResponse[0]="help"; 
uHelpResponse[1]="question"; 
uHelpResponse[2]="assist"; 

/*
* intellibot
* help responses
*/

var iHelpResponse = new Array();

iHelpResponse[0]="If you have a question about this chat room software, please visit http://prochatrooms.com or email sales@prochatrooms.com for assistance."; 
