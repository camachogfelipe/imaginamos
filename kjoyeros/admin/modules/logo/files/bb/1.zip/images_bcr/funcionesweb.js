function muestracotizador(obj){
	window.location=obj.value
	
}