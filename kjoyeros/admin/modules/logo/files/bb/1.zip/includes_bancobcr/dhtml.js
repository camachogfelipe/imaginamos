if(!Array.indexOf){
    Array.prototype.indexOf = function(obj, start){
        for(var i=(start||0); i<this.length; i++){
            if(this[i]==obj){
                return i;
            }
        }

        return -1;
    }
}
function ReadFileSync(sUri) {
   var async = false;
sUri = sUri.replace("//","/");
   try {

     var xmlHttp = XmlHttp.create();

     xmlHttp.open("GET", sUri, async);

   } catch (ex) {

     alert('Descripci�n: ' + ex.description
        //+ ' L�nea ' + ex.number
        //+ ' Mensaje: ' + e.message
        );
   };

   xmlHttp.send(null);
   return xmlHttp.responseText;
}

function SendFormAsXMLHTTP(form, returnString) {
   var async = false;

   try {

     var xmlHttp = XmlHttp.create();

     sUri = form.action;

	 //seg�n la documentaci�n el url debe ser absoluto
	 //FireFox completa el action de los forms en caso de ser ruta relativa, IE no,
	 //por lo tanto es necesario completar
     if (sUri.toUpperCase().indexOf('HTTP://') == -1) {
     	sUri = location.protocol + '//' + location.host + sUri;
	 	alert(sUri);
	}

     xmlHttp.open(form.method, sUri, async);

   } catch (ex) {

     alert('Descripci�n: ' + ex.description
        //+ ' L�nea ' + ex.number
        //+ ' Mensaje: ' + e.message
        );
   };

   xmlHttp.send(buildQueryString(form));
   //return xmlHttp.responseText;

   if (returnString)
     return returnString;
   else
     form.innerHTML = xmlHttp.responseText;
}

var listaLinks = [];


function copyArray(oldArray) {
	var newArray = [];

	for (var j=0; j<oldArray.length; j++)
		newArray[ newArray.length ] = oldArray[j];

	return newArray;

}


function copyArray(oldArray, skipDuplicates) {

	if (isUndefined(skipDuplicates))
	  skipDuplicates = false;


	var newArray = [];

	for (var j=0; j<oldArray.length; j++)
	  if (skipDuplicates) {
	    //ver si ya estaba
	    if (newArray.indexOf(oldArray[j]) == -1 )
	       newArray[ newArray.length ] = oldArray[j];
	  }
	  else
	    newArray[ newArray.length ] = oldArray[j];

	return newArray;

}


var _hermesShowAlert = true;

function alertAndSkip(s) {
	if (_hermesShowAlert)
		_hermesShowAlert = confirm(s,s);
}




var lastURLincluded = "";
function ReplaceLinksWithContent() {
    try {
		var links  = copyArray( document.getElementsByTagName("a") ); //obtener un array que no se modifique
		var links2 = copyArray( document.getElementsByName("HERMES_INCLUDES") );

		links = links.concat( links2 );
		links = copyArray(links , true); //para quitar los repetidos

		var E = null;
		var ext = null;

		var urlToLoad;
		var href;

		for (var i = 0; i < links.length; i++) {
		//for (var i = links.length-1; i > -1; i--) {

			if (links[i].alt){ //si era imagen
				href = links[i].alt;
				//links[i].style.display = "none";
			}
			else {
				href = links[i].href;
			}

			if (href.indexOf("|") >= 0 || href.indexOf(escape("|")) >= 0) {
				E = links[i];

				while ((E.tagName!="TD") && (E.tagName!="DIV")) {
					//alertAndSkip( 'E.tagName:' + E.tagName +  '\n E.innerHTML:' + E.innerHTML );
					E = E.parentNode;
				}

				urlToLoad = href.substring(href.indexOf("|")+1,href.length);
				


				if (urlToLoad.indexOf(escape("|")) > 0)
					urlToLoad = href.substring(href.indexOf(escape("|"))+3,href.length);

				ext = GetValueFromQueryString(urlToLoad, 'ext');

				if (ext != null) {
					if (listaLinks[ ext ] == null)
						listaLinks[ ext ] = [];

					listaLinks[ ext ][ listaLinks[ ext ].length ] = urlToLoad;
				}
                		lastURLincluded = urlToLoad;
				var content = ReadFileSync(urlToLoad);
				BaseHTTP = new String;
				BaseHTTP = href.replace("|","")
				BaseHTTP = BaseHTTP.replace(/\/\//g,"/");
				BaseHTTP = (BaseHTTP.match(/^.*\//));
				content = content.replace(/{\$BaseHTTP}/g,BaseHTTP);


				E.innerHTML = "";
				var resultDiv = document.createElement('div');
				resultDiv.innerHTML = content;

				E.appendChild(resultDiv);


				// saca todos los scripst y los pone en el head
				var dummyDiv = document.createElement('body');
				dummyDiv.innerHTML = content;


				var scripts = dummyDiv.getElementsByTagName("script");
				var styles = dummyDiv.getElementsByTagName("style");
				var tagLinks = dummyDiv.getElementsByTagName("link");
				var headID = document.getElementsByTagName("head")[0];
				
				BrowserDetect.init();
				if (BrowserDetect.browser.toLowerCase().indexOf("firefox") == -1)
				{
					for (var k=0; k < scripts.length; k++)
					{
						var myScript = document.createElement('script');
						if (scripts[k].text){
							myScript.text = scripts[k].text;
						}
						else {
							myScript.src = scripts[k].src;	
						}
						headID.appendChild(myScript);
					}
				}


				for (var k=0; k < styles.length; k++)
				{
					var myStyle = document.createElement('style');
					if (styles[k].text){
						myStyle.text = styles[k].text;
						headID.appendChild(myStyle);
					}
				}

				for (var k=0; k < tagLinks.length; k++)
				{
					if (tagLinks[k].rel == "stylesheet"){
						var myLink = document.createElement('link');
						myLink.href = tagLinks[k].href;
						myLink.rel = tagLinks[k].rel;
						myLink.type = tagLinks[k].type;
						headID.appendChild(myLink);
					}
				}



/*

				E.innerHTML = "";
				var resultDiv = document.createElement('div');
				resultDiv.innerHTML = content;

				E.appendChild(resultDiv);
*/				
				//alert( urlToLoad );
				//alert(E.innerHTML);
			}
		}

		ProcessPlayers();
    } catch (e) {
    	alert(e);
    }
}



function ProcessSWGPlayer() {
	var swfs = copyArray(document.getElementsByName("unSWF"));

	var cualUrl;
	var w;
	var h;
	var urls = [];
	var ids = [];
	var ws = [];
	var hs = [];
	for (var j=0; j<swfs.length; j++) {

		cualUrl = GetValueFromQueryString(listaLinks['swf'][j], 'url');
		w = GetValueFromQueryString(listaLinks['swf'][j], 'w');
		h = GetValueFromQueryString(listaLinks['swf'][j], 'h');

		swfs[j].id = swfs[j].id + j;
		var divId=swfs[j].id;

		if (typeof(swfobject_version)=="undefined"){
			swfobject_version = null;
		}
		switch(swfobject_version){
			case("2.0"):
				if (swfobject.hasFlashPlayerVersion("8.0.0")) {
					urls[j] = cualUrl;
					ids[j] = divId;
					hs[j] = h;
					ws[j]= w;
				}
				break;
			default:
				var cualSWF = new SWFObject(cualUrl, swfs[j].id, w, h, "8", "#ffffff");
				cualSWF.addParam("wmode", "opaque");
				cualSWF.write(swfs[j].id);
				break;
		}

		//alert('swfs.length al final=' + swfs.length);
		//alert(swfsOriginal.length);
	}

	if (urls.length > 0){
		var func = function() {
				var attributes = {};
				var params = {};
				params.menu="false";
				params.wmode="opaque";
				var id = divId;

				for (l=0;l<urls.length;l++){
					attributes.data = urls[l];
					attributes.width= ws[l];
					attributes.height= hs[l];
					swfobject.createSWF(attributes, params, ids[l]);
					}
				};
		swfobject.addDomLoadEvent(func);
	}

}



function ProcessYouTubePlayer() {
	var youtubes = copyArray(document.getElementsByName("unYouTube"));
	var cualUrl;
	var w;
	var h;
	var tmp;
	var urls = [];
	var ids = [];
	for (var j=0; j<youtubes.length; j++) {
		cualUrl = GetValueFromQueryString(listaLinks['youtube'][j], 'url');
		cualUrl = 'http://www.youtube.com/watch/v/' + cualUrl;

		youtubes[j].id = youtubes[j].id + j;
		var DivID = youtubes[j].id;

		if (typeof(swfobject_version)=="undefined"){
					swfobject_version = null;
		}


		switch(swfobject_version){
			case("2.0"):
				if (swfobject.hasFlashPlayerVersion("8.0.0")) {
					urls[j] = cualUrl;
					ids[j] = DivID;
				}
				break;
			default:
				var cualswf = new SWFObject(cualUrl,DivID, '425', '355', "7", "#ffffff");
				cualswf.addParam("movie",cualUrl);
				cualswf.addParam("wmode","transparent");
				cualswf.write(DivID);
		}
	}
	if (urls.length > 0){
		var func = function() {
				var attributes = {};
				attributes.width= '425';
				attributes.height= '355';
				var params = {};
				params.menu="false";
				params.wmode="transparent";
				for (l=0;l<urls.length;l++){
					attributes.data = urls[l];
					params.movie = urls[l];
					swfobject.createSWF(attributes, params, ids[l]);
				}
			};
		swfobject.addDomLoadEvent(func);
	}
}



function ProcessIMGPlayer() {
	var imgs = copyArray(document.getElementsByName("unIMG"));
	var cualUrl;

	for (var j=0; j<imgs.length; j++) {

		cualUrl = GetValueFromQueryString(listaLinks['img'][j], 'url');

		imgs[j].id = imgs[j].id + j;

		imgs[j].src = cualUrl;

	}
}

function ProcessVIDEOPlayer() {
	var elems = copyArray(document.getElementsByName("unVIDEO"));
	var elemsDIV = copyArray(document.getElementsByName("unVIDEODIV"));
	var cualUrl;
	var w;
	var h;

	for (var j=0; j<elems.length; j++) {

		cualUrl = GetValueFromQueryString(listaLinks['video'][j], 'url');
		w = GetValueFromQueryString(listaLinks['video'][j], 'w');
		h = GetValueFromQueryString(listaLinks['video'][j], 'h');


		elems[j].id = elems[j].id + j;
		elemsDIV[j].id = elemsDIV[j].id + j;

		elems[j].src = cualUrl;

		if (h==0){
			elems[j].height = 240;
			//alert('h usando valores default');
		}else{
			elems[j].height = h;
		}

		if(w==0){
			elems[j].width = 320;
			//alert('w usando valores default');
		}else{
			elems[j].width = w;
		}


		elemsDIV[j].innerHTML = elemsDIV[j].innerHTML;  //truco para firefox
	}
}




function ProcessFLVPlayer() {
	var flvs = copyArray(document.getElementsByName("unFLV"));

	var cualUrl;
	var w;
	var h;
	var urls = [];
	var ids = [];
	for (var j=0; j<flvs.length; j++) {

		cualUrl = GetValueFromQueryString(listaLinks['flv'][j], 'url');
		w = 320;
		h = 240;
		flvs[j].id = flvs[j].id + j;
		var flv_id = flvs[j].id;
		if (typeof(swfobject_version)=="undefined"){
			swfobject_version = null;
		}

		switch(swfobject_version){
			case("2.0"):
				if (swfobject.hasFlashPlayerVersion("8.0.0")) {
					urls[j] =  cualUrl;
					ids[j] =  flv_id;
				}
				break;
			default:
				var cualFLV = new SWFObject("/js_srv/flvplayer.swf", flvs[j].id, w, h, "7", "#ffffff");
				cualFLV.addParam("allowfullscreen","true");
		//		cualFLV.addParam("wmode", "opaque");
				cualFLV.addVariable("file",cualUrl);
				cualFLV.write(flvs[j].id);
				break;
		}
	}

	if (urls.length > 0){
		var func = function() {
			var attributes = {};
			attributes.data = "/js_srv/flvplayer.swf";
			attributes.width= w;
			attributes.height= h;
			var params = {};
			params.menu="false";
			params.allowfullscreen="true";
			for (l=0;l<urls.length;l++){
				params.flashvars = "file="+ urls[l];
				swfobject.createSWF(attributes, params, ids[l]);
			}

			};
		swfobject.addDomLoadEvent(func);
	}
}



//buscar en el DOM actualizado luego de ReplaceLinksWithContent() elementos que deban desplegarse en un player
function ProcessPlayers() {
	ProcessSWGPlayer();
	ProcessIMGPlayer();
	ProcessVIDEOPlayer();
	ProcessYouTubePlayer();
	ProcessFLVPlayer();

}


function GetValueFromQueryString(queryString, sParam) {

    var sKey = sParam + "=";

    //var myregexp = new RegExp(regexstring, "gims").

    //var oParams = queryString.split("?")[1].split("&");
    var oParams = queryString.split("?");
    oParams = oParams[oParams.length-1].split("&");

    for(var i = 0; i < oParams.length; i++)
        if(oParams[i].indexOf(sKey) == 0)
            return oParams[i].substring(sKey.length);
    return null;
};


function TravelDOM(elem, actionFunction) {
	if (elem.childNodes) {
		for (var i=0; i < elem.childNodes.length; i++) {
			TravelDOM(elem.childNodes[i], actionFunction);
		}
	}
	actionFunction( elem )
}

function TravelCollection(collection, actionFunction) {
	if (collection) {
		//el recorrido se hace inverso pues si el "actionFunction" elimina elementos la colecci�n tambi�n se acorta
		for (var i=collection.length-1; i >= 0; i--) {
			actionFunction( collection[i] )
		}
	}
}

function FindElementWithAttributeValue(elems, attName, attValue) {

	for (var i=0; i<elems.length; i++) {
		attribs = elems[i].attributes;

		for (var j=0; j < attribs.length; j++) {

			//alert('name:' + attribs[j].nodeName + ', value=' + attribs[j].nodeValue);

			if (attribs[j].nodeName == attName && attribs[j].nodeValue == attValue)
				return elems[i];
		}
	}

	return null;
}

function FindElementsWithAttributeValue(elems, attName, attValue, parcial) {
	var returnElems = [];

	if (isUndefined(parcial))
	  parcial = false;

	for (var i=0; i<elems.length; i++) {
		attribs = elems[i].attributes;
		//alert('name:' + attribs[i].nodeName + ', value=' + attribs[i].nodeValue);

		for (var j=0; j < attribs.length; j++)
			if (attribs[j].nodeName == attName) {

				if (!parcial && attribs[j].nodeValue == attValue)
					returnElems[returnElems.length] = elems[i];
				else
				  if (parcial && attribs[j].nodeValue.indexOf(attValue) != -1) //==0
				    	returnElems[returnElems.length] = elems[i];
			}
	}


	return returnElems;
}

function RemoveAttributes(elems, attName)
{

	for (var i = 0; i < elems.length; i++) {

		elems[i].removeAttribute(attName);

	}

}

function buildQueryString(theForm) {
  var qs = ''
  for (e=0;e<theForm.elements.length;e++) {
    if (theForm.elements[e].name!='') {
      qs+=(qs=='')?'?':'&'
      qs+=theForm.elements[e].name+'='+escape(theForm.elements[e].value)
      }
    }
  return qs
}

/*
function CambiarImage(cual) {
	var img = document.getElementById("destino");
	if (img != null){
		img.src = cual;
	}
}

function AlterarHRefs() {
	var imgLinks = document.getElementsByTagName('A');
	var actual;

	for (var i=0; i<imgLinks.length; i++) {
	  actual = imgLinks[i].href.toUpperCase();
	  if (actual.lastIndexOf('.JPG') > 0 || actual.lastIndexOf('.GIF') > 0 || actual.lastIndexOf('.PNG') > 0)
		  imgLinks[i].href = "javascript:CambiarImage('" + actual + "')";

	 }
}*/


function AutoFitIframe(iFrameObj) {
	try {
		//alert('antes de resize');
		iFrameObj.height = iFrameObj.contentWindow.document.body.scrollHeight + 40;
		//alert('despues de resize');
	}
	catch(e)
	   {
		//alert(e);
		iFrameObj.height = 800;
	   }
}



function FixMenuStyle() {

  var tablasConMenu = FindElementsWithAttributeValue(document.getElementsByTagName("table"), 'class', 'topMenu', true); //apy0m0TB
  var tds;
  var tablas;

  for (var t=0; t < tablasConMenu.length; t++) {

    tds = tablasConMenu[t].getElementsByTagName("td");
    tablas = tablasConMenu[t].getElementsByTagName("table");

    RemoveAttributes(tds, "style");
    RemoveAttributes(tds, "cellpadding");
    RemoveAttributes(tds, "cellspacing");

    RemoveAttributes(tablas, "cellpadding");
    RemoveAttributes(tablas, "cellspacing");
  }
}

//nuevas funciones incluidas en el objecto HASObject

if(typeof HASObject=="undefined"){var HASObject=new Object();}

HASObject.FormMailForm = null;

HASObject.GetElementValue = function(obj) {
	var resultado = null;

	//alert( 'GetElementValue obj.type=' + obj.type );
	//alert( 'GetElementValue obj.length=' + obj.length );

	if (obj == null)
		alert('GetElementValue, obj == null');

	if (isUndefined(obj))
		alert('GetElementValue, obj == undefined');

	if (obj.length != null)
		for ( var i = 0; i < obj.length; i++) {
			resultado = HASObject.GetElementValue( obj[i] );
			if (resultado != null)
				return resultado
		}

	if ( obj.type == 'hidden' || obj.type == 'text' || obj.type == 'password' || obj.type == 'textarea' || obj.type == 'button' || obj.type == 'submit' || obj.type == 'reset' || obj.type == 'file') {
		return obj.value;
	} else if ( obj.type == 'checkbox' || obj.type == 'radio' ) {
		//alert( 'GetElementValue obj.value=' + obj.value );
		if (obj.checked)
			return obj.value;

	} else if ( obj.type == 'select-one' || obj.type == 'select-multiple') {

		//alert(obj.type);

	    for ( var i = 0; i < obj.options.length; i++) {
		  if (obj.options[i].selected) {
		    return obj.options[i].value
		  }
		}
	}

	return null;
}

HASObject.ProcessingMethodCall = function (){
	if (HASObject.FormMailForm != null){
		PrepareFormMail(HASObject.FormMailForm);
	}
}

HASObject.RevisarCamposRequeridos = function () {
	if(typeof __HermesRequeridos=="undefined"){
			HASObject.ProcessingMethodCall();
			return true; //no hay campos requeridos por tanto no hay problema
		}
	var campos = __HermesRequeridos;
	var faltantes = "";
	var elem, elems;
	var focalizado = false;
	var valor = null;

	for (var i=0; i<campos.length; i++) {
	  elems = document.getElementsByName(campos[i])

	  if (elems.length > 0) //posiblemente un radio
	  	valor = HASObject.GetElementValue(elems);
	  else
		valor = HASObject.GetElementValue(elems[0]);

	  if (valor == null || valor.length == 0 ) {
		faltantes += '\n' +campos[i];

		if (!focalizado) {
		  elems[0].focus();
		  focalizado = true;
		}
	  }
	}

	if (faltantes == ""){
	  HASObject.ProcessingMethodCall();
	  return true;
	  }
	else {
	  alert('Los siguientes datos son requeridos:\n' + faltantes);
	  return false;
	}
}


HASObject.Enmarcar = function() {

	var divs =  FindElementsWithAttributeValue(document.getElementsByTagName('div'), 'class', 'hermes_enmarcar', false);  // document.getElementsByTagName('div');
 	var actual = 0;

 	//alert( divs.length );

 	for (var i=0; i<divs.length; i++) {
	// 	if (divs[i].id.toLowerCase().indexOf("hermes_enmarcar") > -1) {


			var E = divs[i];

			var contenido = E.innerHTML; //salvar el contenido anterior
			E.innerHTML = ReadFileSync('/redondeo.html'); //poner el html de redondeo

			var contenidoRedondeado = document.getElementById("contenidoRedondeado");

			contenidoRedondeado.innerHTML = contenido;  //ubicar dentro del html de redondeo el elemento donde se pone el contenido

			contenidoRedondeado.id = contenidoRedondeado.id + i
	//	}
	}
}


HASObject.ConvertirElementoEnToolTip = function(elem) {
	elem = document.getElementById(elem);
	var texto = elem.innerHTML;

	if (texto.length > 63) {
		var descripcion = texto.substring(0,63) + " ...<br>";

		// celda.innerHTML = descripcion + '<br><a class="info" href="#">[+ info]<span>' + texto + '</span></a>'
		elem.innerHTML = descripcion + '<div align="right"><span class="txt_masinfo" >[<a class="info" href="#" >+ info<span>' + texto + '</span></a>]</span></div>';
	}
 }


HASObject.fileExist = function (fileurl){
	var xmlHttp = XmlHttp.create();
	xmlHttp.open('GET', fileurl, false);
	xmlHttp.send(null);
	return(xmlHttp.status == 200)
}

function encodeHTML(str) {
    var aStr = str.split(''),
    i = aStr.length,
    aRet = [];

    while (--i) {
        var iC = aStr[i].charCodeAt();
        if ( iC > 127 ) {
            aRet.push('&#' + iC + ';');
        } else {
            aRet.push(aStr[i]);
        }
    }
    return aRet.reverse().join('');
}

function SaveFormBodyForHAF() {
	var formBody = document.createElement('input');
	var theForm = FindElementsWithAttributeValue(document.forms, 'action', 'RecibirFormulario.aspx', true);
        if (theForm.length > 0) {
	        theForm = theForm[0]; //solo un formulario x page
                formBody.name = 'HERMESFORMBODY';
                formBody.type = 'hidden';
                formBody.value = encodeHTML(theForm.innerHTML);
                theForm.appendChild(formBody);
    	}
}

function HasGalleries(){
	Elements = document.getElementsByName("HERMES_INCLUDES");
	for(i=0;i < Elements.length;i++){
		if (Elements[i].alt.indexOf("/galeria_")>=0)return true;
	}
	return false;
}

function IncludeGalleriesStuff(){
	if (HasGalleries()){
		head =document.getElementsByTagName('head')[0];
		AppendCSSToElement(head,"/includes_bancobcr/lightbox.css");
		AppendCSSToElement(head,"/includes_bancobcr/galeria.css");
		AppendJavascriptToElement(head,"/includes_bancobcr/prototype.js");
		AppendJavascriptToElement(head,"/includes_bancobcr/scriptaculous.js?load=effects");
		AppendJavascriptToElement(head,"/includes_bancobcr/lightbox.js");
	}
}

function AppendJavascriptToElement(element, src){
	var script = document.createElement('script');
	script.type = 'text/javascript';
	script.src = src;
	element.appendChild(script);
}

function AppendCSSToElement(element, src){
	var css   = document.createElement('link');
	css.rel   = 'stylesheet';
	css.href  = src;
	css.type  ="text/css";
	css.media ="screen";
	element.appendChild(css);
}
