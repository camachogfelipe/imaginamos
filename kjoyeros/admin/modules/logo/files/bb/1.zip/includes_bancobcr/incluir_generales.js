/*   include('/css_srv/stiloAdmin.css'); REVISAR DONDE SE USA*/
   include('/includes_bancobcr/browserDetect.js');
   include('/includes_bancobcr/swfobject_v2.js');
   include('/includes_bancobcr/formMailUtils.js');
   include('/includes_bancobcr/xmlextras.js');
   include('/includes_bancobcr/debug.js');
   include('/includes_bancobcr/hse.js');
   include('/includes_bancobcr/dhtml.js');
   include('/includes_bancobcr/swfObject_Params.js');
   include('/includes_bancobcr/hermes_containers.js');
   include('/includes_bancobcr/hf.js');