   include('/includes_bancobcr/togglemenu.js');
   include('/includes_bancobcr/collapsemenu_style.css');
   include('/includes_bancobcr/togglemenu.js');
   include('/includes_bancobcr/collapsemenu_style.css');
   if (_HAS_ie){
       include('/includes_bancobcr/collapsemenu_style-fixie.css');
   }