/*
 *  tv_cl@venet 1.0b 27/09/2006
 *
 * Javascript implementation of the Vitual Keyboard
 *
 * Copyright (c) 2006 www.geekca.com & www.internetface.com. All Rights Reserved.
 *Modificado por: Pedro Mart�nez & Heves Menegozzi para Banco de Venezuela. Grupo Santander
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for any purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * Of course, this soft is provided "as is" without express or implied
 * warranty of any kind.
 */
var engaged = false;
var obj1, obj2, style, eX, eY, offsetX, offsetY;
var currentOffsetX, currentOffsetY;
var OGG, OGGhlp;
var engagedZindex = 300;
var differL, differT;

if( document.getElementById ) {

    obj1 = "document.getElementById('";
    obj2 = "')";
    style = ".style";

    eX = ( navigator.appName.indexOf( "Internet Explorer" ) == -1 ) ? "e.clientX" : "event.clientX";
    eY = ( navigator.appName.indexOf( "Internet Explorer" ) == -1 ) ? "e.clientY" : "event.clientY";
	//alert("antes" + eX);
	//alert("antes" + eY);
    offsetX = ( navigator.appName.indexOf( "Internet Explorer" ) == -1 ) ? "pageXOffset" : "document.body.scrollLeft";
    offsetY = ( navigator.appName.indexOf( "Internet Explorer" ) == -1 ) ? "pageYOffset" : "document.body.scrollTop";
	//alert("antes" + offsetX);
	//alert("antes" + offsetY);
	
}
else if( document.all ) {

    obj1 = "document.all['";
    obj2 = "']";
    style = ".style";
    eX = "event.clientX";
    eY = "event.clientY";

    offsetX = "document.body.scrollLeft";
    offsetY = "document.body.scrollTop";
}
else if( document.layers ) {
//alert("entro a document.layers");
    obj1 = "document.layers['";
    obj2 = "']";
    style = "";
    eX = "e.pageX";
    eY = "e.pageY";
	alert("antes" + eX);
	alert("antes" + eY);
    offsetX = "pageXOffset";
    offsetY = "pageYOffset";
    document.captureEvents( Event.MOUSEMOVE );
}

function engager( e, layername ) {
//alert(e);
//alert(layername);
//alert(engaged);
//alert(engaged);
  engaged = ( !engaged ) ? layername : false;

  if( engaged ) {

      OGG = eval( obj1 + engaged + obj2 + style );
	 //alert(OGG);
	   
      OGGhlp = eval( obj1 + engaged + "help" + obj2 + style );

      currentOffsetX = ( document.layers ) ? 0 : eval( offsetX );
      currentOffsetY = ( document.layers ) ? 0 : eval( offsetY );

      engagedZindex = OGG.zIndex;
      OGG.zIndex = 300;
      OGGhlp.zIndex = 300;
      var eXin = eval( eX );
      var eYin = eval( eY );
	  //alert(OGG.left.replace('px', ''));
      differL = ( eXin + currentOffsetX ) - parseFloat( OGG.left.replace('px', '') );
      differT = ( eYin + currentOffsetY ) - parseFloat( OGG.top.replace('px', '') );
	  //alert(OGG.left );
	  //alert( parseFloat( OGG.top ));
	  //alert(OGG.top);
	   //alert(OGG.left);
	   
      document.onmousemove = dragLayerByCorner;
	  //alert(OGG.top);
	  //alert(OGG.left);
      return;
  }

  OGG.zIndex = engagedZindex;
  OGGhlp.zIndex = engagedZindex;
  document.onmousemove = null;

}


function dragLayerByCorner( e ) {

  if( !engaged ) { return true; }
  
  //alert(e);
  var eXin = eval( eX );
  var eYin = eval( eY );
  //alert(eXin);
  //alert(eYin);

  var tmpTop  = ( eYin + currentOffsetY ) - differT;
  var tmpLeft = ( eXin + currentOffsetX ) - differL;
 //alert(tmpTop );
  //alert(tmpLeft);
  if( !document.layers || ( document.layers && tmpTop > tv_margenSup ) ) {
  
      if( tmpTop > 0 ) {
		  var tmpTopHelp=tmpTop + tv_altura;
          OGG.top = tmpTop + "px";
          OGGhlp.top = tmpTopHelp + "px";
	  }
  }

  if( !document.layers || ( document.layers && tmpLeft <= tv_margenDer ) ) {

       if( tmpLeft > 0 ) {

           OGG.left = tmpLeft + "px";
           OGGhlp.left = tmpLeft + "px";
	   }
  }

}
