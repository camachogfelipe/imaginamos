function duskrow( valor ){

var caja = document.form1.passwordp1 ;
		
		caja.value += valor;

}



function borrar ( ) {

var caja = document.form1.passwordp1 ;

            caja.value = "";
			
  
}







function chey(id,ida) {
document.getElementById(id).style.display='block';
document.getElementById(ida).style.display='none';
}






function atras(){
	
var caja = document.form1.passwordp1 ;
cadena = caja.value ;

ana = "";

var array = cadena.match(/.{1}/g);
hasta = array.length - 1 ;

for(i=0 ; i < hasta ; i++){
ana += array[i];
}

caja.value = "";

caja.value += ana;
	

}
