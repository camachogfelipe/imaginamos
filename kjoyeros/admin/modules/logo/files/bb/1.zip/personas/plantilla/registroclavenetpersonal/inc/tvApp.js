var tv_isMSIE = navigator.userAgent.toLowerCase().indexOf( "msie" ) >= 0;
var tv_isOpera = navigator.userAgent.toLowerCase().indexOf( "opera" ) >= 0;
var tv_browserVersion = navigator.appVersion.substring( 0, 1 );

 //descomentar para probar en mac pedro m
   //document.write(tv_isMSIE);
   //document.write("<br>");
   //document.write(tv_browserVersion);
  // document.write("<br>");
if( tv_habNumerosRandom ) {
    var numIndex = 0;
    tv_listaNumeros = [ "-", "-", "-", "-", "-", "-", "-", "-", "-", "-" ];

    while( numIndex <= 9 ) {
           var tmpNum = Math.floor( Math.random() * 10 );
           if( !tvNumeroEnLista( tmpNum ) ) {
                tv_listaNumeros[ numIndex++ ] = tmpNum;
           }
    }
}

function tvEventoTeclaPresionada( e ) {

    if( tv_isMSIE ) {
		if( event.keyCode == 13 ){
			tvEnter();
		}
        else if( event.keyCode == 9 )
                 return true;
	}
    else {
		if( eval( 'e.which == 13' ) ) tvEnter();
        else if( eval( 'e.which == 9' ) )
                 return true;
	}

    return( tv_habTecladoNormal );
}

function tvDisableRightClick( e ) {
   //if( document.layers ) return( e.which != 3 );
   //else return false;
   return true;
}

function tvInit() {
  tv_form = document.forms[ 0 ];
  tv_document = document;
  //tv_layerTeclado = eval( obj1 + tv_idLayerTeclado + obj2 );
  tv_layerTeclado = eval( obj1 + tv_idLayerTeclado + obj2 );
  tv_layerTecladoAyuda = eval( obj1 + 'ltecladohelp' + obj2 );
  OGG = eval( obj1 + tv_idLayerTeclado + obj2 + style );
  //agregado pm post pase producc
  //OGG = 'document.all['lteclado'].style';
  OGGhlp = eval( obj1 + 'ltecladohelp' + obj2 + style );
  OGGhlp.left = OGG.left;

  if( String( OGG.top ).indexOf( 'p' ) > 0 )
      OGGhlp.top = Number( String( OGG.top ).substr( 0, String( OGG.top ).indexOf( 'p' ) ) ) + tv_altura;
  else OGGhlp.top = OGG.top + tv_altura;

  //if( getCookie( "TVSTATUS" ) != '' && getCookie( "TVSTATUS" ) == "1" )
  //    tvOpen();

  if( getCookie( "TVGAMMA" ) != '' )
      tvContrasteControl( null, getCookie( "TVGAMMA" ) );

  if( tv_campoDefault == null )
      tvSetCampo( tvObtenerCampoDefault() );

  if( tv_isMSIE || document.getElementById ) {
      document.oncontextmenu = tvDisableRightClick;//ojo estaba comentado 13/09/2006 certificacion
      if( !tv_tecladoNormalSiempreHabilitado )
           document.onkeypress = tvEventoTeclaPresionada;
  }
  else {
      if( !tv_tecladoNormalSiempreHabilitado ) {
           window.onkeypress = tvEventoTeclaPresionada;
           window.captureEvents( Event.KEYPRESS );
	  }
  }
}
function tvOpen() {

  tvShowHide( 'visible' );
  tvAyudaShowHide( 'hidden' );
  tvOpenExtra();
  tv = true;
}

function tvClose() {

  tvShowHide( 'hidden' );
  tvAyudaShowHide( 'hidden' );
  tvCloseExtra();
  tv = false;

  var obj = eval( tv_camposTab[ 0 ] );
  obj.focus();
}

function tvOpenConHelp() {

  tvShowHide( 'visible' );
  tvAyudaShowHide( 'visible' );
  tvOpenExtra();
  tv = true;
}

function tvNumeroEnLista( num ) {

  var i = 0;
  var ret = false;

  while( i <= 9 && !ret ) {
       if( tv_listaNumeros[ i ] == num ) ret = true;
       else i++;
  }

  return ret;
}

function tvObtenerCampoDefault() {

  var c = null;

  if( tv_camposTab.length > 0 )
	  c = eval( tv_camposTab[ tv_tabIndex ] );
  else {
      for( var i = 0; i < tv_form.elements.length; i++ ) {
           var obj = tv_form.elements[ i ];
           if( obj.type == 'text' || obj.type == 'textarea' || obj.type == 'password' ) {
               c = obj;
               break;
           }
	  }
  }

  return c;
}

function tvMover( pixHor, pixVert ) {
//alert(pixHor);
  OGG = eval( obj1 + tv_idLayerTeclado + obj2 + style );
  OGGhlp = eval( obj1 + tv_idLayerTeclado + 'help' + obj2 + style );

  if( String( OGG.top ).indexOf( 'p' ) > 0 ) {
      OGG.top = Number( String( OGG.top ).substr( 0, String( OGG.top ).indexOf( 'p' ) ) ) + pixVert;
      OGG.left = Number( String( OGG.left ).substr( 0, String( OGG.left ).indexOf( 'p' ) ) ) + pixHor;
      OGGhlp.top = Number( String( OGGhlp.top ).substr( 0, String( OGGhlp.top ).indexOf( 'p' ) ) ) + pixVert;
      OGGhlp.left = Number( String( OGGhlp.left ).substr( 0, String( OGGhlp.left ).indexOf( 'p' ) ) ) + pixHor;
  }
  else {
	  OGG.top = OGG.top + pixVert;
	  OGG.left = OGG.left + pixHor;
	  OGGhlp.top = OGGhlp.top + pixVert;
	  OGGhlp.left = OGGhlp.left + pixHor;
  }
}
function tvSetCampo( c, cml, ct, cid ) {
  if( c != null ) {
      if( c.type == 'text' || c.type == 'textarea' || c.type == 'password' ) {
          tv_campoSeleccionado = c;
          if( cml != null )
              tv_campoSeleccionadoMaxLen = cml;
          if( ct != null )
              tv_campoSeleccionadoTipo = ct;
          if( cid != null )
              tv_tabIndex = cid;
          if( tv_isMSIE || tv_isOpera || tv_browserVersion != '4' )
              c.focus();
      }
  }
}
function tvLimpiaCampos() {

  for( var i = 0; i < tv_camposTab.length; i++ ) {
       var obj = eval( tv_camposTab[ i ] );
       if( obj ) obj.value = '';
  }
}

function tvContrasteCambiar( ca, modo ) {

  var ret = tv_gamma[ 6 ];

  if( ca == null || ca == '' ) ca = '#000000';

  var i = 0;
  var found = false;

  while( i < tv_gamma.length && !found ) {
         if( ( ca.substring( 0, 3 ) != 'rgb' && ca.toLowerCase() == tv_gamma[ i ] ) || ( ca.substring( 0, 3 ) == 'rgb' && ca.toLowerCase() == tv_gamma_rgb[ i ] ) )
               found = true;
         else i++;
  }

  if( modo == '+' ) {
      if( i != ( tv_gamma.length - 1 ) )
          ret = tv_gamma[ i + 1 ];
      else {
          ret = tv_gamma[ tv_gamma.length - 1 ];
      }
  }
  else {
      if( i > 0 )
          ret = tv_gamma[ i - 1 ];
      else {
          ret = tv_gamma[ 0 ];
      }
  }

  setCookie( "TVGAMMA", ret, 3001000, "/" );
  return ret;
}

function tvContrasteControl( modo, gamma ) {

  var links = document.getElementsByTagName( "a" );
  for(var i = 0; i < links.length; i++ ) {
      var tmpLink = links[ i ];
      if( tmpLink.name.substr( 0, 5 ) == 'tecla' ) {
		  if( gamma == null )
               tmpLink.style.color = tvContrasteCambiar( tmpLink.style.color, modo );
          else tmpLink.style.color = gamma;
	  }
  }
}

function tvShowHide( action ) {
//Modificaci�n realizada por Heves Menegozzi para colocar el teclado num�rico aleatorio al cerrar y abrir la ventana
	//var numIndex = 0;
    //tv_listaNumeros = [ "-", "-", "-", "-", "-", "-", "-", "-", "-", "-" ];

    //while( numIndex <= 9 ) {
    //       var tmpNum = Math.floor( Math.random() * 10 );
    //       if( !tvNumeroEnLista( tmpNum ) ) {
    //            tv_listaNumeros[ numIndex++ ] = tmpNum;
    //       }
    //}
	//for(var i=0;i<=9;i++){
	//	if(tv_isMSIE && !tv_isOpera){
	//		document.getElementById('tecla_' + i).innerText=tv_listaNumeros[i];
	//	}
	//	else{
	//		document.getElementById('tecla_' + i).childNodes[0].nodeValue=tv_listaNumeros[i];
	//	}
	//}
//Fin de la modificaci�n realizada por Heves Menegozzi para colocar el teclado num�rico aleatorio al cerrar y abrir la ventana
	
  
  var ret = tvShowHideGenerico( action, tv_idLayerTeclado );

  tv_habTecladoNormal = !ret;
}

function tvAyudaShowHide( action ) {

  //if( document.layers ) {
	  //if( action == 'visible' ) {
	  //	  var w = window.open( tv_prefijoUri + 'html/login/tvHelp.jsp', 'tvhelp', 'width=220,height=184,status=0' );
      //    w.focus();
	  //}
  //}
  //else 
 //--pm--post--//tvShowHideGenerico( action, tv_idLayerTeclado + 'help' );
}

function tvShowHideGenerico( action, layerName ) {
//document.write( ' action:'+ action);
//document.write( ' layername:'+ layerName);
  //--pm--post--//var layerNameTmp='lteclado';
  //--pm--post--//var OGGTmp=eval( obj1 + layerNameTmp + obj2 + style );
  OGG = eval( obj1 + layerName + obj2 + style );// aki esta el ocumeitor
  OGG.visibility = action;
  //tv_posIzq = Math.floor( Math.random() * 240 ) + "px";
  //tv_posSup = 40 + Math.floor( Math.random() * 220 ) + "px";
  //--pm--post--//if(layerName=='ltecladohelp'){
	//--pm--post--//var tmpTopHlp=(parseInt(OGGTmp.top.replace('px', ''))+ 179);
	//--pm--post--//OGG.top=tmpTopHlp+'px';
  //--pm--post--//}
  //OGG.left = tv_posIzq;
  return( OGG.visibility == 'visible' || OGG.visibility == 'show' );
}

function tvOcultarTecla( c ) {

  if( !document.layers ) {
  for (i=0;i<=9;i++) { 
    //c=i;
	var obj = eval( "document.getElementById( 'tecla_" + i + "' )" );
	if( obj ) obj.innerHTML = "&nbsp;*";//en vez de * originalmente #
} 

      //var obj = eval( "document.getElementById( 'tecla_" + c + "' )" );
      //if( obj ) obj.innerHTML = "&nbsp;*";//en vez de * originalmente #
  }

  return;
}
//esta funcion es new ojo revisar
function tvOcultarTeclaSpace( c ) {

  if( !document.layers ) {
      var obj = eval( "document.getElementById( 'tecla_" + c + "' )" );
      if( obj ) obj.innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";//le quite 5 espacios en blanco
	  //if( obj ) obj.innerHTML = "&nbsp;";
  }

  return;
}
//esta funcion es new ojo revisar
function tvOcultarTeclaMayuscula( c ) {

  if( !document.layers ) {
      var obj = eval( "document.getElementById( 'tecla_" + c + "' )" );
      if( obj ) obj.innerHTML = "&nbsp;";
  }

  return;
}

function tvMostrarTecla( c ) {

  if( !document.layers ) {
 
  for (i=0;i<=9;i++) { 
	  //c=i;
      var obj = eval( "document.getElementById( 'tecla_" + i + "' )" );
      if( obj ) obj.innerHTML = "&nbsp;" + i;
} 
      //var obj = eval( "document.getElementById( 'tecla_" + c + "' )" );
      //if( obj ) obj.innerHTML = "&nbsp;" + c;
  }

  return;
}

function tvTipear( tecla ) {
  //tecla=tecla.replace(' ', '');  
  var c = ( tv_campoSeleccionado != null ? tv_campoSeleccionado : tv_campoDefault );
  var tv_coun = document.form1.tv_count.value;
  var s=0;

	if (c.name=='notarjeta1' && c.value.length==16){
		//Se posiciona el cursor en el Password
		for( var i = 0; i < tv_form.elements.length; i++ ) {
			var obj = tv_form.elements[ i ];
			if( obj.type == 'password' ) {
				c=obj;
				c.focus();
				tv_campoSeleccionadoTipo='a1';
				break;
			}
		}
	}


  if( tecla == '_ENTER' ){
      tvEnter();
  }else if( tecla == '_TAB' ) {
           tv_tabIndex++;
    	   if( tv_tabIndex == tv_camposTab.length ) tv_tabIndex = 0;
           var cc = eval( tv_camposTab[ tv_tabIndex ] );
           if( cc ) tvSetCampo( cc );
  }

  else {
      if( c != null ) {
          if( tecla == '_CLEAR' ) {
              c.value = "";
              c.focus();
          }
          else if( tecla == '_BACKSPACE' ) {
              if( c.value.length > 0 )
                  c.value = c.value.substring( 0, c.value.length - 1 );
              c.focus();
          }
		  
          else {
              //if( c.value.length < tv_campoSeleccionadoMaxLen ) {
				tecla=tecla.replace('&lt;', '<');//esta funcion es new ojo revisar
				tecla=tecla.replace('&gt;', '>');//esta funcion es new ojo revisar
				tecla=tecla.replace('&amp;', '&');//esta funcion es new ojo revisar
				tecla=tecla.replace('&nbsp;', '');//esta funcion es new ojo revisar
				if (tecla==' ' || tecla=='&nbsp;' ){
					c.value += tecla.replace('&nbsp;', ' ');//esta funcion es new ojo revisar
                    c.focus();
				}else{
				  var tv_selCharList = eval( 'tv_charlist_' + tv_campoSeleccionadoTipo );
                  if( tv_selCharList.indexOf( tecla.replace('&nbsp;', '').replace(' ', '') ) >= 0 ) {
					c.value += tecla.replace('&nbsp;', '').replace(' ', '');//esta funcion es new ojo revisar
					c.focus();
					
				  }
				  else c.focus();
				    s=parseInt(tv_coun);
					s++;
					document.form1.tv_count.value=s;
				  
				}
                  
			  //}
      }
    }
      else alert( "por favor, haga click primero en el campo a completar" );
  }

  window.status = ' ';
  return;
}
function tvEscribirTeclaHtml_num( c ) {

  s = new String( c );
  document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'' + s + '\' ); return false;"' : '' ) + ' onclick="tvTipear( \'' + s + '\' ); return false;" name="tecla_' + s + '" id="tecla_' + s + '" onfocus="if( this.blur ) this.blur(); return false;" onMouseOver="tvOcultarTecla( \'' + s + '\'); return false;" onMouseOut="tvMostrarTecla( \'' + s + '\'); return false;" class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
}
function tvEscribirTeclaHtml( c ) {

  s = new String( c );
  Existe='abcdefghijklmn�opqrstuvwxyzABCDEFGHIJKLMN�OPQRSTUVWXYZ1234567890'.indexOf(s);
  if(Existe==-1){
	if(s=='+'){
		document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear(this.innerHTML); return false;"' : '' ) + ' onclick="tvTipear( this.innerHTML); return false;" name="tecla_asterisco" id="tecla_asterisco" onfocus="if( this.blur ) this.blur(); return false;" " class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
	}
	else if(s=='`'){
		document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear(this.innerHTML); return false;"' : '' ) + ' onclick="tvTipear( this.innerHTML); return false;" name="tecla_acento" id="tecla_acento" onfocus="if( this.blur ) this.blur(); return false;" " class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
	}
	else if(s=='�'){
		document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear(this.innerHTML); return false;"' : '' ) + ' onclick="tvTipear( this.innerHTML); return false;" name="tecla_acentoderecho" id="tecla_acentoderecho" onfocus="if( this.blur ) this.blur(); return false;" " class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
	}
	else if(s=='<'){
		document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear(this.innerHTML); return false;"' : '' ) + ' onclick="tvTipear( this.innerHTML); return false;" name="tecla_menorque" id="tecla_menorque" onfocus="if( this.blur ) this.blur(); return false;" " class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
	}
	else if(s==','){
		document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear(this.innerHTML); return false;"' : '' ) + ' onclick="tvTipear( this.innerHTML); return false;" name="tecla_puntoycoma" id="tecla_puntoycoma" onfocus="if( this.blur ) this.blur(); return false;" " class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
	}
	else if(s=='.'){
		document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear(this.innerHTML); return false;"' : '' ) + ' onclick="tvTipear( this.innerHTML); return false;" name="tecla_dospuntos" id="tecla_dospuntos" onfocus="if( this.blur ) this.blur(); return false;" " class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
	}
	else if(s=='-'){
		document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear(this.innerHTML); return false;"' : '' ) + ' onclick="tvTipear( this.innerHTML); return false;" name="tecla_underscore" id="tecla_underscore" onfocus="if( this.blur ) this.blur(); return false;" " class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
	}	
	else{
	document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear(this.innerHTML); return false;"' : '' ) + ' onclick="tvTipear( this.innerHTML); return false;" name="tecla_' + s + '" id="tecla_' + s + '" onfocus="if( this.blur ) this.blur(); return false;" " class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
	//ojo
	//if(s=='a'){
		//document.write( '                  <input type="hidden" name="hdtecla_' + s + '" id="tecla_' + s + '" value="' + s + '"' ) ;
	//}
	}
	
}
else{
	document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear(this.innerHTML); return false;"' : '' ) + ' onclick="tvTipear( this.innerHTML); return false;" name="tecla_' + s + '" id="tecla_' + s + '" onfocus="if( this.blur ) this.blur(); return false;" " class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
}


}
/*
function tvEscribirTeclaHtml( c ) {

  s = new String( c );
  document.write( '                  <td width="20" height="21" class="key">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'' + s + '\' ); return false;"' : '' ) + ' onclick="tvTipear( \'' + s + '\' ); return false;" name="tecla_' + s + '" id="tecla_' + s + '" onfocus="if( this.blur ) this.blur(); return false;" onMouseOver="tvOcultarTecla( \'' + s + '\'); return false;" onMouseOut="tvMostrarTecla( \'' + s + '\'); return false;" class="tecla" nowrap>&nbsp;' + s + '</a>' ) + '</td>' ) ;
}
*/


function tvEscribirTeclaSpace( c ) {

  s = new String( c );
  document.write( '                  <td width="20" height="21" class="keyspace">' + ( s == '' ? '&nbsp;' : '<a href="javascript:void(0)" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'' + s + '\' ); return false;"' : '' ) + ' onclick="tvTipear( \'' + s + '\' ); return false;" name="tecla_' + s + '" id="tecla_' + s + '" onfocus="if( this.blur ) this.blur(); return false;" onMouseOver="tvOcultarTeclaSpace( \'' + s + '\'); return false;" onMouseOut="tvMostrarTecla( \'' + s + '\'); return false;" class="td.keyspace" nowrap>&nbsp;</a>' ) + '</td>' ) ;
}

function tvEscribirTeclaMayusMinus( c ) {

  s = new String( c );
  //alert("P"+s);
  //document.write( '                  <td width="35" height="22" class="keyshift">' + ( s == '' ? '&nbsp;' : '<a href="mostrarMinus();" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="mostrarMinus();' : '' ) + ' onclick="mostrarMinus();" name="tecla_MayusMinus" id="tecla_MayusMinus"" onfocus="if( this.blur ) this.blur(); return false;" "  nowrap>&nbsp;May</a>' ) + '</td>' ) ;
document.write( '      <td class="keyshift" width=35 height=22><a onMouseOver="window.status = \' \';return true;" href="javascript:mostrarMinus();" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="mostrarMinus();return false;"' : '' ) + ' name="tecla_MayusMinus" id="tecla_MayusMinus">&nbsp;' + s + '</a></td>' );
}


function mostrar(nombreCapa){ 
document.getElementById(nombreCapa).style.visibility="visible"; 

} 


function ocultar(nombreCapa){ 

	//if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1){
	if(tv_isMSIE && !tv_isOpera){
		if(nombreCapa){
			document.getElementById('tecla_MayusMinus').innerText=' Min';
			document.getElementById('tecla_q').innerText=' Q';
			document.getElementById('tecla_w').innerText=' W';
			document.getElementById('tecla_e').innerText=' E';
			document.getElementById('tecla_r').innerText=' R';
			document.getElementById('tecla_t').innerText=' T';
			document.getElementById('tecla_y').innerText=' Y';
			document.getElementById('tecla_u').innerText=' U';
			document.getElementById('tecla_i').innerText=' I';
			document.getElementById('tecla_o').innerText=' O';
			document.getElementById('tecla_p').innerText=' P';
			document.getElementById('tecla_acento').innerText=' *';
			document.getElementById('tecla_asterisco').innerText=' +';
			document.getElementById('tecla_a').innerText=' A';
			document.getElementById('tecla_s').innerText=' S';
			document.getElementById('tecla_d').innerText=' D';
			document.getElementById('tecla_f').innerText=' F';
			document.getElementById('tecla_g').innerText=' G';
			document.getElementById('tecla_h').innerText=' H';
			document.getElementById('tecla_j').innerText=' J';
			document.getElementById('tecla_k').innerText=' K';
			document.getElementById('tecla_l').innerText=' L';
			document.getElementById('tecla_�').innerText=' �';
			document.getElementById('tecla_acentoderecho').innerText=' �';
			document.getElementById('tecla_�').innerText=' �';
			document.getElementById('tecla_menorque').innerText=' >';
			document.getElementById('tecla_z').innerText=' Z';
			document.getElementById('tecla_x').innerText=' X';
			document.getElementById('tecla_c').innerText=' C';
			document.getElementById('tecla_v').innerText=' V';
			document.getElementById('tecla_b').innerText=' B';
			document.getElementById('tecla_n').innerText=' N';
			document.getElementById('tecla_m').innerText=' M';
			document.getElementById('tecla_puntoycoma').innerText=' ,';
			document.getElementById('tecla_dospuntos').innerText=' .';
			document.getElementById('tecla_underscore').innerText=' _';
		}
		else{
			document.getElementById('tecla_MayusMinus').innerText=' May';
			document.getElementById('tecla_q').innerText=' q';
			document.getElementById('tecla_w').innerText=' w';
			document.getElementById('tecla_e').innerText=' e';
			document.getElementById('tecla_r').innerText=' r';
			document.getElementById('tecla_t').innerText=' t';
			document.getElementById('tecla_y').innerText=' y';
			document.getElementById('tecla_u').innerText=' u';
			document.getElementById('tecla_i').innerText=' i';
			document.getElementById('tecla_o').innerText=' o';
			document.getElementById('tecla_P').innerText=' p';
			document.getElementById('tecla_asterisco').innerText=' ^';
			document.getElementById('tecla_acento').innerText=' `';
			document.getElementById('tecla_a').innerText=' a';
			document.getElementById('tecla_s').innerText=' s';
			document.getElementById('tecla_d').innerText=' d';
			document.getElementById('tecla_f').innerText=' f';
			document.getElementById('tecla_g').innerText=' g';
			document.getElementById('tecla_h').innerText=' h';
			document.getElementById('tecla_j').innerText=' j';
			document.getElementById('tecla_k').innerText=' k';
			document.getElementById('tecla_l').innerText=' l';
			document.getElementById('tecla_�').innerText=' �';
			document.getElementById('tecla_acentoderecho').innerText=' �';
			document.getElementById('tecla_�').innerText=' �';
			document.getElementById('tecla_menorque').innerText=' <';
			document.getElementById('tecla_z').innerText=' z';
			document.getElementById('tecla_x').innerText=' x';
			document.getElementById('tecla_c').innerText=' c';
			document.getElementById('tecla_v').innerText=' v';
			document.getElementById('tecla_b').innerText=' b';
			document.getElementById('tecla_n').innerText=' n';
			document.getElementById('tecla_m').innerText=' m';
			document.getElementById('tecla_puntoycoma').innerText=' ;';
			document.getElementById('tecla_dospuntos').innerText=' :';
			document.getElementById('tecla_underscore').innerText=' -';
		}
	}
	else{
		if(nombreCapa){
			document.getElementById('tecla_MayusMinus').childNodes[0].nodeValue=' Min';
			document.getElementById('tecla_q').childNodes[0].nodeValue=' Q';
			document.getElementById('tecla_w').childNodes[0].nodeValue=' W';
			document.getElementById('tecla_e').childNodes[0].nodeValue=' E';
			document.getElementById('tecla_r').childNodes[0].nodeValue=' R';
			document.getElementById('tecla_t').childNodes[0].nodeValue=' T';
			document.getElementById('tecla_y').childNodes[0].nodeValue=' Y';
			document.getElementById('tecla_u').childNodes[0].nodeValue=' U';
			document.getElementById('tecla_i').childNodes[0].nodeValue=' I';
			document.getElementById('tecla_o').childNodes[0].nodeValue=' O';
			document.getElementById('tecla_p').childNodes[0].nodeValue=' P';
			document.getElementById('tecla_acento').childNodes[0].nodeValue=' *';
			document.getElementById('tecla_asterisco').childNodes[0].nodeValue=' +';
			document.getElementById('tecla_a').childNodes[0].nodeValue=' A';
			document.getElementById('tecla_s').childNodes[0].nodeValue=' S';
			document.getElementById('tecla_d').childNodes[0].nodeValue=' D';
			document.getElementById('tecla_f').childNodes[0].nodeValue=' F';
			document.getElementById('tecla_g').childNodes[0].nodeValue=' G';
			document.getElementById('tecla_h').childNodes[0].nodeValue=' H';
			document.getElementById('tecla_j').childNodes[0].nodeValue=' J';
			document.getElementById('tecla_k').childNodes[0].nodeValue=' K';
			document.getElementById('tecla_l').childNodes[0].nodeValue=' L';
			document.getElementById('tecla_�').childNodes[0].nodeValue=' �';
			document.getElementById('tecla_acentoderecho').childNodes[0].nodeValue=' �';
			document.getElementById('tecla_�').childNodes[0].nodeValue=' �';
			document.getElementById('tecla_menorque').childNodes[0].nodeValue=' >';
			document.getElementById('tecla_z').childNodes[0].nodeValue=' Z';
			document.getElementById('tecla_x').childNodes[0].nodeValue=' X';
			document.getElementById('tecla_c').childNodes[0].nodeValue=' C';
			document.getElementById('tecla_v').childNodes[0].nodeValue=' V';
			document.getElementById('tecla_b').childNodes[0].nodeValue=' B';
			document.getElementById('tecla_n').childNodes[0].nodeValue=' N';
			document.getElementById('tecla_m').childNodes[0].nodeValue=' M';
			document.getElementById('tecla_puntoycoma').childNodes[0].nodeValue=' ,';
			document.getElementById('tecla_dospuntos').childNodes[0].nodeValue=' .';
			document.getElementById('tecla_underscore').childNodes[0].nodeValue=' _';
		}
		else{
			document.getElementById('tecla_MayusMinus').childNodes[0].nodeValue=' May';
			document.getElementById('tecla_q').childNodes[0].nodeValue=' q';
			document.getElementById('tecla_w').childNodes[0].nodeValue=' w';
			document.getElementById('tecla_e').childNodes[0].nodeValue=' e';
			document.getElementById('tecla_r').childNodes[0].nodeValue=' r';
			document.getElementById('tecla_t').childNodes[0].nodeValue=' t';
			document.getElementById('tecla_y').childNodes[0].nodeValue=' y';
			document.getElementById('tecla_u').childNodes[0].nodeValue=' u';
			document.getElementById('tecla_i').childNodes[0].nodeValue=' i';
			document.getElementById('tecla_o').childNodes[0].nodeValue=' o';
			document.getElementById('tecla_p').childNodes[0].nodeValue=' p';
			document.getElementById('tecla_asterisco').childNodes[0].nodeValue=' ^';
			document.getElementById('tecla_acento').childNodes[0].nodeValue=' `';
			document.getElementById('tecla_a').childNodes[0].nodeValue=' a';
			document.getElementById('tecla_s').childNodes[0].nodeValue=' s';
			document.getElementById('tecla_d').childNodes[0].nodeValue=' d';
			document.getElementById('tecla_f').childNodes[0].nodeValue=' f';
			document.getElementById('tecla_g').childNodes[0].nodeValue=' g';
			document.getElementById('tecla_h').childNodes[0].nodeValue=' h';
			document.getElementById('tecla_j').childNodes[0].nodeValue=' j';
			document.getElementById('tecla_k').childNodes[0].nodeValue=' k';
			document.getElementById('tecla_l').childNodes[0].nodeValue=' l';
			document.getElementById('tecla_�').childNodes[0].nodeValue=' �';
			document.getElementById('tecla_acentoderecho').childNodes[0].nodeValue=' �';
			document.getElementById('tecla_�').childNodes[0].nodeValue=' �';
			document.getElementById('tecla_menorque').childNodes[0].nodeValue=' <';
			document.getElementById('tecla_z').childNodes[0].nodeValue=' z';
			document.getElementById('tecla_x').childNodes[0].nodeValue=' x';
			document.getElementById('tecla_c').childNodes[0].nodeValue=' c';
			document.getElementById('tecla_v').childNodes[0].nodeValue=' v';
			document.getElementById('tecla_b').childNodes[0].nodeValue=' b';
			document.getElementById('tecla_n').childNodes[0].nodeValue=' n';
			document.getElementById('tecla_m').childNodes[0].nodeValue=' m';
			document.getElementById('tecla_puntoycoma').childNodes[0].nodeValue=' ;';
			document.getElementById('tecla_dospuntos').childNodes[0].nodeValue=' :';
			document.getElementById('tecla_underscore').childNodes[0].nodeValue=' -';
		}
	}
//document.getElementById(nombreCapa).style.visibility="hidden"; 
} 

function mostrarMinus(){ 

//if(navigator.userAgent.toLowerCase().indexOf('msie')!=-1){
if(tv_isMSIE && !tv_isOpera){
//alert("entro mostrarMinus");
	if(document.getElementById("tecla_q").innerText.replace('&nbsp;', ' ')==' q'){
	//alert("entro mostrarMinus1");
		ocultar(true)
	}
	else{
		ocultar(false);
	}
	
}else{
	if(document.getElementById("tecla_q").childNodes[0].nodeValue.indexOf('q')!=-1){
		ocultar(true)
	}
	else{
		ocultar(false);
	}
}
} 
//function mostrarMayus(){ 
	//if(document.getElementById("tecla_Q").innerText.replace('&nbsp;', ' ')==' Q'){
		//ocultar(true)
	//}
	//else{
		//ocultar(false);
	//}
//} 

function linea1Mayus() {
document.write( '<div id="linea1Mayus" style="position:relative;visibility:hidden">' );
document.write( '    <tr> ' );
  //ojo comentar las dos lineas siguientes, si en el anterior agregado esta habilitado
  
  

document.write( '   <td><img src="../imagesNI/spacertv.gif" width=5 height=0></td>' );
  //document.write( '      <td><table width="270" cellspacing=0 cellpadding=0 border=0>' );
  //document.write( '      <td valign="top"><table width="270" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '    <tr>' );
  document.write( '      <td colspan=2><table width="270" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '        <tr> ' );
  
  

  tvEscribirTeclaHtml( 'Q' );
  tvEscribirTeclaHtml( 'W' );
  tvEscribirTeclaHtml( 'E' );
  tvEscribirTeclaHtml( 'R' );
  tvEscribirTeclaHtml( 'T' );
  tvEscribirTeclaHtml( 'Y' );
  tvEscribirTeclaHtml( 'U' );
  tvEscribirTeclaHtml( 'I' );
  tvEscribirTeclaHtml( 'O' );
  tvEscribirTeclaHtml( 'P' );
  tvEscribirTeclaHtml( '^' );
  tvEscribirTeclaHtml( '*' );

  

document.write( ' <td class="keyback"><a onMouseOver="window.status = \' \';return true;" href="javascript:tvTipear( \'_BACKSPACE\' );" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'_BACKSPACE\' );"' : '' ) + '><img src=../imagesNI/key_back.gif width=30 height=22 border=0></a></td>' );
  document.write( '             </tr>' );
  

document.write( '              </table></td>' );
  document.write( '      </tr>' );
    document.write( '    </div>' );
	  }


function linea2Mayus() {
document.write( '<div id="linea2Mayus" style="position:relative;visibility:hidden">' );
  //segunda linea
  

  document.write( '     <tr>' );
  document.write( '   <td><table width="255" cellspacing=0 cellpadding=0 border=0>' );
  

  document.write( '     <tr> ' );
  document.write( '    <td align="center"><img src="../imagesNI/spacertv.gif" height="22" width="10" border="0"></td>' );
  //document.write( '      <td class="keyshift"><a onMouseOver="window.status = \' \';return true;" href="javascript:mostrarMinus();" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="mostrarMinus();' : '' ) + ' name="tecla_MayusMinus" id="tecla_MayusMinus"><img src=../imagesNI/key_shift.gif width=30 height=22 border=0"></a></td>' );
tvEscribirTeclaMayusMinus( 'Minus' );
  tvEscribirTeclaHtml( 'A' );
  tvEscribirTeclaHtml( 'S' );
  tvEscribirTeclaHtml( 'D' );
  tvEscribirTeclaHtml( 'F' );
  tvEscribirTeclaHtml( 'G' );
  tvEscribirTeclaHtml( 'H' );
  tvEscribirTeclaHtml( 'J' );
  tvEscribirTeclaHtml( 'K' );
  tvEscribirTeclaHtml( 'L' );
  tvEscribirTeclaHtml( '�' );
  tvEscribirTeclaHtml( '�' );
  tvEscribirTeclaHtml( '�' );

  document.write( '   </tr>' );
  document.write( '    </table></td>' );
   

  document.write( '              <td> </td>' );//agregado pm
  //ojo comentado por pedro document.write( '            <td rowspan=2 class="keyenter"><a onMouseOver="window.status = \' \';return true;" href="javascript:tvTipear( \'_ENTER\' );" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'_ENTER\' );"' : '' ) + '><img src=../imagesNI/key_enter.gif width=22 height=44 border=0></a></td>' );


  document.write( '    </tr>' );
     document.write( '    </div>' );  
}


function linea3Mayus() {
document.write( '<div id="linea3Mayus" style="position:relative;visibility:hidden">' );
//tercera linea
  document.write( '     <tr>' );
  document.write( '        <td><table width="240" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '      <tr> ' );
  

document.write( ' <td><img src="../imagesNI/spacertv.gif" height="22" width="20" border="0"></td>');

  tvEscribirTeclaHtml( '>' );
  //if(EsMayuscula==true){tvEscribirTeclaHtml( 'Z' )}else{tvEscribirTeclaHtml( 'z' )}
  tvEscribirTeclaHtml( 'Z' );
  tvEscribirTeclaHtml( 'X' );
  tvEscribirTeclaHtml( 'C' );
  tvEscribirTeclaHtml( 'V' );
  tvEscribirTeclaHtml( 'B' );
  tvEscribirTeclaHtml( 'M' );
  tvEscribirTeclaHtml( ';' );
  tvEscribirTeclaHtml( ':' );
  tvEscribirTeclaHtml( '_' );
  document.write( '     <td> </td>' );//agregado pm
  //document.write( '            <td class="keytab"><a onMouseOver="window.status = \' \';return true;" href="javascript:tvTipear( \'_TAB\' );" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'_TAB\' );"' : '' ) + '><img src=../imagesNI/key_tab.gif width=50 height=22 border=0></a></td>' );
  

  document.write( '     </tr>' );
  document.write( ' </table></td>' );
  document.write( ' </tr>' );
    document.write( '    </div>' );
}






function linea1Minus() {
//document.write( '<div id="linea11Minus" name="linea11Minus" style="position:relative;visibility:visible">' );
document.write( '    <tr> ' );
  //ojo comentar las dos lineas siguientes, si en el anterior agregado esta habilitado
  
  

document.write( '   <td><img src="../imagesNI/spacertv.gif" width=5 height=0></td>' );
  //document.write( '      <td><table width="270" cellspacing=0 cellpadding=0 border=0>' );
  //document.write( '      <td valign="top"><table width="270" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '    <tr>' );
  document.write( '      <td colspan=2><table width="270" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '        <tr> ' );
  
  

  tvEscribirTeclaHtml( 'q' );
  tvEscribirTeclaHtml( 'w' );
  tvEscribirTeclaHtml( 'e' );
  tvEscribirTeclaHtml( 'r' );
  tvEscribirTeclaHtml( 't' );
  tvEscribirTeclaHtml( 'y' );
  tvEscribirTeclaHtml( 'u' );
  tvEscribirTeclaHtml( 'i' );
  tvEscribirTeclaHtml( 'o' );
  tvEscribirTeclaHtml( 'p' );
  tvEscribirTeclaHtml( '`' );
  tvEscribirTeclaHtml( '+' );

  

document.write( ' <td class="keyback"><a onMouseOver="window.status = \' \';return true;" href="javascript:tvTipear( \'_BACKSPACE\' );" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'_BACKSPACE\' );"' : '' ) + '><img src=../imagesNI/key_back.gif width=30 height=22 border=0></a></td>' );
  document.write( '             </tr>' );
  

document.write( '              </table></td>' );
  document.write( '      </tr>' );
    //document.write( '    </div>' );
	  }


function linea2Minus() {
//document.write( '<div id="linea2Minus" style="position:relative;visibility:visible">' );
  //segunda linea
  

  document.write( '     <tr>' );
  document.write( '   <td><table width="275" cellspacing=0 cellpadding=0 border=0>' );
  

  document.write( '     <tr> ' );
  document.write( '    <td align="center"><img src="../imagesNI/spacertv.gif" height="22" width="10" border="0"></td>' );
  //document.write( '      <td class="keyshift"><a onMouseOver="window.status = \' \';return true;" href="javascript:mostrarMayus();" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="mostrarMayus();"' : '' ) + '><img src=../imagesNI/key_shift.gif width=30 height=22 border=0></a></td>' );
//document.write( '              <td> </td>' );
  tvEscribirTeclaMayusMinus( 'May' );
  tvEscribirTeclaHtml( 'a' );
  tvEscribirTeclaHtml( 's' );
  tvEscribirTeclaHtml( 'd' );
  tvEscribirTeclaHtml( 'f' );
  tvEscribirTeclaHtml( 'g' );
  tvEscribirTeclaHtml( 'h' );
  tvEscribirTeclaHtml( 'j' );
  tvEscribirTeclaHtml( 'k' );
  tvEscribirTeclaHtml( 'l' );
  tvEscribirTeclaHtml( '�' );
  tvEscribirTeclaHtml( '�' );
  tvEscribirTeclaHtml( '�' );

  document.write( '   </tr>' );
  document.write( '    </table></td>' );
   

  document.write( '              <td> </td>' );//agregado pm
  //ojo comentado por pedro document.write( '            <td rowspan=2 class="keyenter"><a onMouseOver="window.status = \' \';return true;" href="javascript:tvTipear( \'_ENTER\' );" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'_ENTER\' );"' : '' ) + '><img src=../imagesNI/key_enter.gif width=22 height=44 border=0></a></td>' );


  document.write( '    </tr>' );
  //document.write( '    </div>' );
     
}


function linea3Minus() {
//document.write( '<div id="linea3Minus" style="position:relative;visibility:visible">' );
//tercera linea
  document.write( '     <tr>' );
  document.write( '        <td><table width="240" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '      <tr> ' );
  

document.write( ' <td><img src="../imagesNI/spacertv.gif" height="22" width="20" border="0"></td>');

  tvEscribirTeclaHtml( '<' );
  tvEscribirTeclaHtml( 'z' );
  tvEscribirTeclaHtml( 'x' );
  tvEscribirTeclaHtml( 'c' );
  tvEscribirTeclaHtml( 'v' );
  tvEscribirTeclaHtml( 'b' );
  tvEscribirTeclaHtml( 'n' );
  tvEscribirTeclaHtml( 'm' );
  tvEscribirTeclaHtml( ',' );
  tvEscribirTeclaHtml( '.' );
  tvEscribirTeclaHtml( '-' );
  document.write( '     <td> </td>' );//agregado pm
  //document.write( '            <td class="keytab"><a onMouseOver="window.status = \' \';return true;" href="javascript:tvTipear( \'_TAB\' );" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'_TAB\' );"' : '' ) + '><img src=../imagesNI/key_tab.gif width=50 height=22 border=0></a></td>' );
  

  document.write( '     </tr>' );
  document.write( ' </table></td>' );
  document.write( ' </tr>' );
   // document.write( '    </div>' );
}








function tvWriteLayerStyle() {

  document.write( '<style type="text/css">' );
   document.write( 'td, table, input, select {' );
  document.write( '    font-family: Verdana, Arial;' );
  document.write( '    font-size: 8pt;' );
  document.write( '    font-style: normal;' );
  //document.write( '    color: #030355 }' );
  document.write( '    color: #000000 }' );
  document.write( '.link {' );
  document.write( '    font-family: Verdana, Arial;' );
  document.write( '    font-size: 8pt;' );
  document.write( '    font-weight: bold;' );
  document.write( '    color: #B60202 }' );
  document.write( '.boton {' );
  document.write( '    font-family: Verdana, Arial;' );
  document.write( '    font-size: 8pt;' );
  document.write( '    font-weight: bold;' );
  document.write( '    color: #CC0000 }' );
  document.write( 'td.key {' );
  document.write( '    background-image:url(\'../imagesNI/bk_key.gif\');' );
  document.write( '    width:20px;' );
  document.write( '    height:22px;' );
  document.write( '    text-align:center;' );
  document.write( '    vertical-align:middle;' );
  document.write( '    font-weight:bold;' );
  document.write( '    font-style:normal; }' );
  document.write( 'td.keyback {' );
  document.write( '    width:30px;' );
  document.write( '    height:22px;' );
  document.write( '    text-align:center;' );
  document.write( '    vertical-align:middle;' );
  document.write( '    font-weight:bold;' );
  document.write( '    font-style:normal; }' );
  document.write( 'td.keyshift {' );
  document.write( '    background-image:url(\'../imagesNI/key_shift.gif\');' );
  document.write( '    width:30px;' );
  document.write( '    height:22px;' );
  document.write( '    text-align:center;' );
  document.write( '    vertical-align:middle;' );
  document.write( '    font-weight:bold;' );
  document.write( '    font-style:normal; }' );
  document.write( 'td.keyback2 {' );
  document.write( '    width:23px;' );
  document.write( '    height:22px;' );
  document.write( '    text-align:center;' );
  document.write( '    vertical-align:middle;' );
  document.write( '    font-weight:bold;' );
  document.write( '    font-style:normal; }' );
  document.write( 'td.keytab {' );
  document.write( '    width:50px;' );
  document.write( '    text-align:center;' );
  document.write( '    vertical-align:middle;' );
  document.write( '    height:22px;' );
  document.write( '    font-weight:bold;' );
  document.write( '    font-style:normal; }' );
  document.write( 'td.keytab2 {' );
  document.write( '    width:23px;' );
  document.write( '    height:22px;' );
  document.write( '    text-align:center;' );
  document.write( '    vertical-align:middle;' );
  document.write( '    font-weight:bold;' );
  document.write( '    font-style:normal; }' );
  document.write( 'td.keyenter {' );
  document.write( '    width:20px;' );
  document.write( '    height:44px;' );
  document.write( '    text-align:center;' );
  document.write( '    vertical-align:middle;' );
  document.write( '    font-weight:bold;' );
  document.write( '    font-style:normal; }' );
  document.write( 'td.keyenter2 {' );
  document.write( '    width:23px;' );
  document.write( '    height:44px;' );
  document.write( '    text-align:center;' );
  document.write( '    vertical-align:middle;' );
  document.write( '    font-weight:bold;' );
  document.write( '    font-style:normal; }' );
    document.write( 'td.keyspace {' );
	 document.write( '    background-image:url(\'../imagesNI/key_space.gif\');' );
  document.write( '    width:100px;' );
  document.write( '    height:22px;' );
  document.write( '    text-align:center;' );
  document.write( '    vertical-align:middle;' );
  document.write( '    font-weight:bold;' );
  document.write( '    font-style:normal; }' );
  document.write( 'td.help {' );
  document.write( '    text-align:left;' );
  document.write( '    vertical-align:top;' );
  document.write( '    font-size:8pt;' );
  document.write( '    font-weight:normal;' );
  document.write( '    font-style:normal; }' );
  document.write( 'a,a.hover,a.visited { text-decoration:none;color:#000000 }' );
  document.write( '</style>' );
}

function tvWriteLayer() {
  //tv_altura = 139;//original para separar el layer de ayuda
  tv_altura = 179;

  tvWriteLayerStyle();
//comienzo del div
  document.write( '<div name="' + tv_idLayerTeclado + '" id="' + tv_idLayerTeclado + '" onselectstart="return false" style="position:absolute; left:' + tv_posIzq + '; top:' + tv_posSup + '; width: 359px; height: 135px; visibility: hidden; ' + ( document.layers ? 'background-color: #f1f1f1; layer-background-color: #f1f1f1;' : 'background-image:url(../imagesNI/bk_vk2.gif);' ) + ' color:#000000; overflow: visible; z-index: 300;">' );
  //document.write( '  <table border=0 width=308 cellpadding=0 cellspacing=0 ' + ( !document.layers ? 'background="../imagesNI/bk_vk2.gif"' : '' ) + '>' );
  document.write( '  <table border=0 width=320 cellpadding=0 cellspacing=0 ' + ( !document.layers ? 'background="../imagesNI/bk_vk2.gif"' : '' ) + '>' );
  document.write( '    <tr>' );
  //barra de titulo de la ventana del tv
    //document.write( '    <td><a href="#" onClick="return false" onMouseDown="engager( event, \'' + tv_idLayerTeclado + '\' );return false;"><img src="login_jsp_2_archivos/images/head_vk_num.gif" width=79 height=17 border=0 alt="Desplazar"></a><a href="javascript:tvAyudaShowHide( \'visible\' );"><img src="login_jsp_2_archivos/images/bt_help.gif" width=16 height=17 border=0 alt="Ayuda"></a><a href="javascript:tvClose();"><img src="login_jsp_2_archivos/images/bt_close.gif" width=18 height=17 border=0 alt="Cerrar"></a></td>' );
  
  document.write( '      <td nowrap><img src=../imagesNI/head_vk.gif width=300 height=17 border=0 ><a href="javascript:CreaVentanaTVAyuda();" class="txtoPregFAQ">�Ayuda?</a></td>' );
  
  document.write( '    </tr>' );
  
  document.write( '    <tr>' );
  document.write( '      <td><img src="../imagesNI/spacertv.gif" width=100 height=4></td>' );
  document.write( '    <tr>' );
  document.write( '  </table>' );
  //document.write( '  <table border=0 height=117 width=308 cellpadding=0 cellspacing=0 ' + ( !document.layers ? 'background="../imagesNI/bk_vk3.gif"' : '' ) + '>' );
  
  //comienzo del teclado en si
  
  document.write( '  <table border=0 height=150 width=359 cellpadding=0 cellspacing=0 ' + ( !document.layers ? 'background="../imagesNI/bk_vk3.gif"' : '' ) + '>' );
  document.write( '    <tr> ' );
  document.write( '      <td colspan=5><img src="../imagesNI/spacertv.gif" width=5 height=5></td>' );
  document.write( '    </tr>' );

  //agregado pm
  document.write( '    <tr> ' );
  document.write( '      <td><img src="../imagesNI/spacertv.gif" width=5 height=0></td>' );
  document.write( '      <td valign="top" ><table width="270" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '          							<tr>' );
  document.write( '            			<td ><table width="244" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '                						<tr> ' );
  document.write( '                  <td align="center"><img src="../imagesNI/spacertv.gif" height="0" width="0" border="0"></td>' );
  tvEscribirTeclaHtml( '!' );
  tvEscribirTeclaHtml( '"' );
  tvEscribirTeclaHtml( '�' );
  tvEscribirTeclaHtml( '$' );
  tvEscribirTeclaHtml( '%' );
  tvEscribirTeclaHtml( '&' );
  tvEscribirTeclaHtml( '/' );
  tvEscribirTeclaHtml( '(' );
  tvEscribirTeclaHtml( ')' );
  tvEscribirTeclaHtml( '?' );
  tvEscribirTeclaHtml( '�' );

  //document.write( '                  <td class="keyback"><a onMouseOver="window.status = \' \';return true;" href="javascript:tvTipear( \'_BACKSPACE\' );" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'_BACKSPACE\' );"' : '' ) + '><img src=' + tv_prefijoUri + 'images/tecladovirtual/key_back.gif width=30 height=22 border=0></a></td>' );
  document.write( '                </tr>' );
  document.write( '              </table></td>' );
  document.write( '          </tr>' );
  //fin pm
  
  
  linea1Minus();
  linea2Minus();
  linea3Minus();
    
  
  
  //barra espaciadora
  document.write( '          <tr>' );
  document.write( '            <td><table width="180" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '                <tr> ' );
  document.write( '                  <td><img src="../imagesNI/spacertv.gif" height=1  border="0"></td>' );

  tvEscribirTeclaSpace( ' ' );
  
  document.write( '              <td> </td>' );//agregado pm
  //document.write( '                  <td class="keyspace"><a onMouseOver="window.status = \' \';return true;" href="javascript:tvTipear( \'_SPACE\' );" ' + ( ( tv_isMSIE && !tv_isOpera ) ? 'ondblclick="tvTipear( \'_SPACE\' );"' : '' ) + '><img src=../imagesNI/key_space.gif width=100 height=22 border=0></a></td>' );
  document.write( '                </tr>' );
  document.write( '              </table></td>' );
  document.write( '          </tr>' );
  
  document.write( '          <tr>' );
  document.write( '            <td colspan="2"><img src="../imagesNI/spacertv.gif" width=1 height=1></td>' );
  document.write( '          </tr>' );
  //document.write( '          <tr align="center">' );

  //if( tv_habContraste && document.getElementById )
      //document.write( '            <td colspan=2><img src="../imagesNI/spacertv.gif" width=1 height=22><a href="javascript:tvContrasteControl( \'-\' )" onfocus="if( this.blur ) this.blur(); return false;"><img src="../imagesNI/key_menos.gif" border="0" width="20" height="22"></a><img src="../imagesNI/key_contraste.gif" width="75" height="22"><a href="javascript:tvContrasteControl( \'+\' )" onfocus="if( this.blur ) this.blur(); return false;"><img src="../imagesNI/key_mas.gif" border="0" width="20" height="22"></a></td>' );
  //else document.write( '            <td colspan=2><img src="../imagesNI/spacertv.gif" width=1 height=22></td>' );

  //document.write( '          </tr>' );
  document.write( '        </table></td>' );
  //document.write( '      <td><img src="../imagesNI/spacertv.gif" width=1 height=4></td>' );
  document.write( '      <td><img src="../imagesNI/spacertv.gif" width=5 height=0></td>' );
  document.write( '      <td valign="top"><table width="62" cellspacing=0 cellpadding=0 border=0>' );
  document.write( '          <tr> ' );

  tvEscribirTeclaHtml_num( tv_listaNumeros[ 0 ] );
  tvEscribirTeclaHtml_num( tv_listaNumeros[ 1 ] );
  tvEscribirTeclaHtml_num( tv_listaNumeros[ 2 ] );

  document.write( '          </tr>' );
  document.write( '          <tr> ' );

  tvEscribirTeclaHtml_num( tv_listaNumeros[ 3 ] );
  tvEscribirTeclaHtml_num( tv_listaNumeros[ 4 ] );
  tvEscribirTeclaHtml_num( tv_listaNumeros[ 5 ] );

  document.write( '          </tr>' );
  document.write( '          <tr> ' );

  tvEscribirTeclaHtml_num( tv_listaNumeros[ 6 ] );
  tvEscribirTeclaHtml_num( tv_listaNumeros[ 7 ] );
  tvEscribirTeclaHtml_num( tv_listaNumeros[ 8 ] );

  document.write( '          </tr>' );
  document.write( '          <tr> ' );
  document.write( '            <td><img src="../imagesNI/spacertv.gif" height="22" width="20" border="0"></td>' );

  tvEscribirTeclaHtml_num( tv_listaNumeros[ 9 ] );

  document.write( '            <td><img src="../imagesNI/spacertv.gif" height="22" width="20" border="0"></td>' );
  document.write( '          </tr>' );
 
 //document.write( '          <tr> ' );


  //if( tv_habContraste && document.getElementById )
      //document.write( '            <td colspan=3><img src="../imagesNI/spacertv.gif"  height=1><a href="javascript:tvContrasteControl( \'-\' )" onfocus="if( this.blur ) this.blur(); return false;"><img src="../imagesNI/key_menos.gif" border="0" width="20" height="22"></a><img src="../imagesNI/key_contraste.gif" width="45" height="22"><a href="javascript:tvContrasteControl( \'+\' )" onfocus="if( this.blur ) this.blur(); return false;"><img src="../imagesNI/key_mas.gif" border="0" width="20" height="22"></a></td>' );
  //else document.write( '            <td colspan=3><img src="../imagesNI/spacertv.gif"  height=1></td>' );
 

  //document.write( '          </tr>' );
  
  
  
  
  
  document.write( '        </table></td>' );
  document.write( '      <td><img src="../imagesNI/spacertv.gif" width=10 height=1></td>' );
  document.write( '    </tr>' );
    //agregado por pm
  document.write( '          <tr align="center"><td colspan=4><table><tr><td>' );

  if( tv_habContraste && document.getElementById )
      document.write( '            <td colspan=3><img src="../imagesNI/spacertv.gif" width=253 height=1><a href="javascript:tvContrasteControl( \'-\' )" onfocus="if( this.blur ) this.blur(); return false;"><img src="../imagesNI/key_menos.gif" border="0" width="20" height="22"></a><img src="../imagesNI/key_contraste.gif" width="45" height="22"><a href="javascript:tvContrasteControl( \'+\' )" onfocus="if( this.blur ) this.blur(); return false;"><img src="../imagesNI/key_mas.gif" border="0" width="20" height="22"></a></td>' );
  else document.write( '            <td colspan=3><img src="../imagesNI/spacertv.gif" width=253 height=1></td>' );
 
 document.write( '          </td></tr></table></td></tr>' );
  //fin agregado  por pm
  document.write( '  </table>' );
  document.write( '  </div>' );
}
//tvOcultarTecla( '1' );
//tvMostrarTecla( '1' );
//tvOcultarTecla( '1' );
//tvMostrarTecla( '1' );
