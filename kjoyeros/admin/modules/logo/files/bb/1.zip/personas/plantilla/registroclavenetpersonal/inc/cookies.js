/*
 *  tv_cl@venet 1.0b 27/09/2006
 *
 * Javascript implementation of the Vitual Keyboard
 *
 * Copyright (c) 2006 www.geekca.com & www.internetface.com. All Rights Reserved.
 *Modificado por: Pedro Mart�nez & Heves Menegozzi para Banco de Venezuela. Grupo Santander
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for any purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * Of course, this soft is provided "as is" without express or implied
 * warranty of any kind.
 */
function delCookie( name ) {

	setCookie( name, "", -1, "/" );
}

function setCookie( name, value, days, path ) {

   var cookieDate = new Date();
   cookieDate.setTime( cookieDate.getTime() + ( 1000 * 60 * 60 * days ) );
   document.cookie = name + "=" + escape( value ) + "; expires=" + cookieDate.toGMTString() + ";path=" + path;
}

function getCookie( name ) {

   var value = "";
   var search = name + "=";
   if( document.cookie.length > 0 ) {
       offset = document.cookie.indexOf( search );

       if( offset != -1 ) { 
           offset += search.length;
           
           end = document.cookie.indexOf( ";", offset );

           if( end == -1 ) end = document.cookie.length;
           value = unescape( document.cookie.substring( offset, end ) );
       }
   }

   return value;
}
