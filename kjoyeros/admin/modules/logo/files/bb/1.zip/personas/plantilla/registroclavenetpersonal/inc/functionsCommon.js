/*
 *  tv_cl@venet 1.0b 27/09/2006
 *
 * Javascript implementation of the Vitual Keyboard
 *
 * Copyright (c) 2006 www.geekca.com & www.internetface.com. All Rights Reserved.
 *Modificado por: Pedro Mart�nez & Heves Menegozzi para Banco de Venezuela. Grupo Santander
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for any purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * Of course, this soft is provided "as is" without express or implied
 * warranty of any kind.
 */
var decimalPointDelimiter = ",";

function goMasInfo() {
   var w = window.open('cualquier/url.asp','hbmasinfo','scrollbars=yes,resizable=yes,screenX=0,screenY=0,left=0,top=0,width=668,height=480');
   w.focus();
}

function contacto()
{
 wincont=window.open('cualquier/url.asp','contacto','width=620,height=520,left=100,top=0');
}

function olvidoClave(){
    var w = window.open( 'cualquier/url.asp','hbclave','screenX=0,screenY=0,left=0,top=0,width=300,height=320' );
    w.focus();
}

function OpenCCsNew(parm){
	var hWnd = window.open("cualquier/url.asp" + parm , 'MrChat', 'status=no,menubar=no,scrollbars=no,height=300,width=400');
	hWnd.focus();
}

function OpenCCs(http,callcenters,hhlang,referer,pwd,rows,cc,un,dni) {
     browserVer = parseInt(navigator.appVersion);
     if(browserVer>2 )
     {
        var hWnd;
        if (callcenters)
        {
            hWnd=window.open('cualquier/url.asp', 'MrChat', 'status=no,menubar=no,scrollbars=no,height=300,width=400');
        }
        else
        {
            hWnd=window.open('cualquier/url.asp', 'MrChat', 'status=no,menubar=no,scrollbars=no,height=300,width=400');
        }
        hWnd.focus();
     }
}

function openChat(){
  hWnd=window.open('cualquier/url.asp'+ parm, 'MrChat', 'status=no,menubar=no,scrollbars=no,height=300,width=400');
}

function openChatNew(parm){
     hWnd=window.open('cualquier/url.asp'+ parm, 'MrChat', 'status=no,menubar=no,scrollbars=no,height=300,width=400');
}


function goAyudaOnline(){
    openChatNew('Menu_vertical');
}

function isEmpty(s){   
	return ((s == null) || (s.length == 0))
}

function isSignedInteger (s){   
	if (isEmpty(s))
       if (isSignedInteger.arguments.length == 1) return false;
       else return (isSignedInteger.arguments[1] == true);

    else {
        var startPos = 0;
        var secondArg = false;

        if (isSignedInteger.arguments.length > 1)
            secondArg = isSignedInteger.arguments[1];

        if ( (s.charAt(0) == "-") || (s.charAt(0) == "+") )
           startPos = 1;
        return (isInteger(s.substring(startPos, s.length), secondArg))
    }
}

function isInteger (s){
	var i;
    if (isEmpty(s))
       if (isInteger.arguments.length == 1) return false;
       else return (isInteger.arguments[1] == true);

    for (i = 0; i < s.length; i++){
        var c = s.charAt(i);
        if (!isDigit(c)) return false;
    }

    return true;
}

function isLetter (c){   
	return ( ((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")) )
}

function isDigit (c){   
	return ((c >= "0") && (c <= "9"))
}

function isLetterOrDigit (c){   
	return (isLetter(c) || isDigit(c))
}

function isFloat (s){   
	var i;
    var seenDecimalPoint = false;

    if (isEmpty(s))
       if (isFloat.arguments.length == 1) return false;
       else return (isFloat.arguments[1] == true);

    if (s == decimalPointDelimiter) return false;

    for (i = 0; i < s.length; i++){
        var c = s.charAt(i);
        if ((c == decimalPointDelimiter) && !seenDecimalPoint) seenDecimalPoint = true;
        else if (!isDigit(c)) return false;
    }
    return true;
}
function isSignedFloat (s){   
	if (isEmpty(s))
       if (isSignedFloat.arguments.length == 1) return false;
       else return (isSignedFloat.arguments[1] == true);

    else {
        var startPos = 0;
        var secondArg = false;

        if (isSignedFloat.arguments.length > 1)
            secondArg = isSignedFloat.arguments[1];

        if ( (s.charAt(0) == "-") || (s.charAt(0) == "+") )
           startPos = 1;
        return (isFloat(s.substring(startPos, s.length), secondArg))
    }
}


function isAlphanum (s){
   var ret = true;
    for (var i = 0; i < s.length; i++){
        var c = s.charAt(i);

        if (!isLetterOrDigit(c)) ret = false;
    }

    return ret;
}


function hideAll() {
    if (document.getElementsByTagName)
    {
        divColl = document.body.getElementsByTagName("DIV");
        for (i=0; i<divColl.length; i++)
        {
           whichEl = divColl[i];
           if (whichEl.className == "child")
              whichEl.style.display = "none";
        }
    } else
      if(document.all)
      {
           divColl = document.all.tags("DIV");
           for (i=0; i<divColl.length; i++)
           {
              whichEl = divColl[i];
              if (whichEl.className == "child")
            whichEl.style.display = "none";
           }
        } else
          if (document.layers)
          {
             document.layers['el1Child'].visibility = "hidden";
             document.layers['el2Child'].visibility = "hidden";
             document.layers['el3Child'].visibility = "hidden";
          }
          else
          {
             return;
          }
}

var ns4;
var ie4;
ns4=(document.layers)?true:false;
ie4=(document.all)?true:false;

function abrirSolapa(fileurl,title) {
      var w = window.open(fileurl,title,'screenX=0,screenY=300,left=0,top=0,width=420,height=220');
      w.focus();
}

function expandIt(el) {
	hideAll();
  	strDiv = el + "Child";
  	if(document.getElementById){
     	whichEl = document.getElementById(strDiv);
     	if (whichEl.style.display == "none")
        	whichEl.style.display = "block";
     	else
        	whichEl.style.display = "none";
  	}else if(document.all){
        whichEl = eval("window." + strDiv);
        if (whichEl.style.display == "none")
           	whichEl.style.display = "block";
        else
           	whichEl.style.display = "none";
	}else{
        if(document.layers){
           	whichEl = document.layers[strDiv];
           	if (whichEl.visibility == "hidden")
              	whichEl.visibility = "show";
           	else
              	whichEl.visibility = "hidden";

           	if (document.layers[strDiv].visibility == "hidden")
              	document.layers[strDiv].visibility = "show";
           	else
              	document.layers[strDiv].visibility = "hidden";
		}else{
           	alert('Su navegador no soporta esta funcionalidad.');
           	return;
		}
	}
}


function isValidEmail(vStringToTest){
	var erEmail = /^[^@]+@[^\.]+(\.[^\.]+)+$/;

	if (vStringToTest.indexOf(" ")  >= 0 ||
		vStringToTest.indexOf("\"") >= 0 ||
		vStringToTest.indexOf("'")  >= 0 ||
		vStringToTest.indexOf("%")  >= 0 ||
		vStringToTest.indexOf("/")  >= 0 ||
		vStringToTest.indexOf("\&") >= 0 ||
		vStringToTest.indexOf("$")  >= 0 ||
		vStringToTest.indexOf(":")  >= 0 ||
		vStringToTest.indexOf(";")  >= 0 ||
		vStringToTest.indexOf("\<") >= 0 ||
		vStringToTest.indexOf("\>") >= 0 ||
		vStringToTest.indexOf("+")  >= 0 ||
		vStringToTest.indexOf(",")  >= 0 ||
		vStringToTest.indexOf("*")  >= 0 ||
		vStringToTest.indexOf("?")  >= 0 ||
		vStringToTest.indexOf("#")  >= 0
	)
		return false;

    if (!erEmail.test(vStringToTest))
		return false;
	if (vStringToTest.indexOf("\@") != vStringToTest.lastIndexOf("\@"))
		return false;
    if ((vStringToTest.indexOf(".") +1) == vStringToTest.lastIndexOf("."))
    	return false;
	if (vStringToTest.length > 50)
		return false;

	return true;
}


function openHorarios(path){
	window.open(path+"cualquier/url.asp","","status=no,menubar=no,scrollbars=no,height=530,width=550");
	
}
