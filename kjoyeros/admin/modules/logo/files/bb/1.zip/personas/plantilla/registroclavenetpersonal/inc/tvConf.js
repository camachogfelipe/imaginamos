/*
 *  tv_cl@venet 1.0b 27/09/2006
 *
 * Javascript implementation of the Vitual Keyboard
 *
 * Copyright (c) 2006 www.geekca.com & www.internetface.com. All Rights Reserved.
 *Modificado por: Pedro Mart�nez & Heves Menegozzi para Banco de Venezuela. Grupo Santander
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for any purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * Of course, this soft is provided "as is" without express or implied
 * warranty of any kind.
 */
var tv = false;
var tv_form = null;
var tv_prefijoUri     = '';
var tv_versionTeclado = '1.1';
var tv_idLayerTeclado = 'lteclado';

var tv_tabIndex = 0;
var tv_campoDefault = null;
var tv_campoSeleccionado = null;
var tv_campoSeleccionadoTipo = 'a1';
var tv_campoSeleccionadoMaxLen = 999;

var tv_layerTeclado = null;
var tv_layerTecladoAyuda = null;

var tv_habContraste     = true;
var tv_habListaCampos   = true;
var tv_habPosicionMovil = true;
var tv_habTecladoNormal = false;
var tv_habNumerosRandom = true;

var tv_tecladoNormalSiempreHabilitado = true;//para habilitar el teclado o no

var tv_margenSup = 0;
var tv_margenDer = 260;



var tv_posIzq = 5;
var tv_posSup = 150;
var tv_altura = 139;

var tv_camposTab = new Array();

var tv_listaNumeros = [ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" ];

//var tv_gamma = [ "#9999cc", "#8c8cc6", "#8080bf", "#6666b3", "#5151a2", "#434387", "#000000" ];
//var tv_gamma = [ "#ffffff", "#ebebeb", "#cccccc", "#999999", "#666666", "#333333", "#000000" ];
var tv_gamma = [ "#cccccc", "#bcbcbc", "#a8a8a8", "#999999", "#666666", "#333333", "#000000" ];
//var tv_gamma_rgb = [ "rgb(153, 153, 204)", "rgb(140, 140, 198)", "rgb(128, 128, 191)", "rgb(102, 102, 179)", "rgb(81, 81, 162)", "rgb(67, 67, 135)", "rgb(0, 0, 0)" ];
//var tv_gamma_rgb = [ "rgb(255, 255, 255)", "rgb(235, 235, 235)", "rgb(204, 204, 204)", "rgb(153, 153, 153)", "rgb(102, 102, 102)", "rgb(51, 51, 51)", "rgb(0, 0, 0)" ];
var tv_gamma_rgb = [ "rgb(204, 204, 204)", "rgb(188, 188, 188)", "rgb(168, 168, 168)", "rgb(153, 153, 153)", "rgb(102, 102, 102)", "rgb(51, 51, 51)", "rgb(0, 0, 0)" ];

var tv_charlist_n0 = "0123456789";
var tv_charlist_a0 = "0123456789abcdefghijklmn�opqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
var tv_charlist_a1 = "0123456789abcdefghijklmn�opqrstuvwxyzABCDEFGHIJKLMN�OPQRSTUVWXYZ!\"#$%\&����()=?�^�`�+*}{]\ [_-.:,;�<>//";
