/*
 *  tv_cl@venet 1.0b 27/09/2006
 *
 * Javascript implementation of the Vitual Keyboard
 *
 * Copyright (c) 2006 www.geekca.com & www.internetface.com. All Rights Reserved.
 *Modificado por: Pedro Mart�nez & Heves Menegozzi para Banco de Venezuela. Grupo Santander
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for any purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * Of course, this soft is provided "as is" without express or implied
 * warranty of any kind.
 */

function Cripto()
{
	this.E  = 3;
	this.N  = 391;

	this.CI = "A";
	this.CF = "A";
	this.CS = "A";

    this.enc     = Cripto_enc;
    this.encchar = Cripto_encchar;
    this.ASC     = Cripto_ASC;

    this.getCI   = Cripto_getCI;
    this.getCF   = Cripto_getCF;
    this.getCS   = Cripto_getCS;
}


function Cripto_enc( tcstring )
{
    var lcstring  = tcstring;
    var lcencrypt = "";

    for ( var i = 0; i < lcstring.length; i++ ) {
          lcencrypt += this.encchar( lcstring.substr( i, 1 ), this.E, this.N );
          lcencrypt += this.CS;
    }

    return ( lcencrypt );
}


function Cripto_encchar( tcchar, E, N )
{
    var F, G;
    var C = this.ASC( tcchar );

    if ( E % 2 == 0 ) {
         G = 1;
         for ( var i = 1; i <= E/2; i++ ) {
               F = (C * C) % N;
               G = (F * G) % N;
         }
    } else {
         G = C;
         for ( var i = 1; i <= E/2; i++ ) {
               F = (C * C) % N;
               G = (F * G) % N;
         }
    }

    return ( G );
}


function Cripto_ASC( tcchar )
{
    return ( tcchar.charCodeAt(0) );
}


function Cripto_getCI()
{
	return this.CI;
}


function Cripto_getCF()
{
	return this.CF;
}


function Cripto_getCS()
{
	return this.CS;
}