/**
 * The Geekca Virtual Keyboard library
 *
 * Copyright (c) 2004-2005 by Geekca, Inc.
 * http://www.geekca.com
 * http://www.internetface.com
 * Caracas, Venezuela
 * 414 -1100141
 * All rights reserved.
 *
 * $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
 * Modificado por: Pedro Mart�nez (E4GS de Venezuela) para Banco de Venezuela
 */
function Formato() 
{
    this.LONG_PIN = 8;
    this.LONG_DNI = 11;
    this.LONG_USR = 20;

    this.FILL_PIN = "0";
    this.FILL_DNI = "0";
    this.FILL_USR = " ";

    this.formatPIN = Formato_formatPIN;
    this.formatDNI = Formato_formatDNI;
    this.formatUSR = Formato_formatUSR;
    this.completarCarIzq = Formato_completarCarIzq;
    this.completarCarDer = Formato_completarCarDer;
}

function Formato_formatPIN( pin )
{
    if ( pin.length > this.LONG_PIN ) return pin.substring( pin.length - this.LONG_PIN );
    else return this.completarCarIzq( pin, this.FILL_PIN, this.LONG_PIN );
}

function Formato_formatDNI( dni )
{
    if ( dni.length > this.LONG_DNI ) return dni.substring( dni.length - this.LONG_DNI );
    else return this.completarCarIzq( dni, this.FILL_DNI, this.LONG_DNI );
}

function Formato_formatUSR( usr )
{
    if ( usr.length > this.LONG_USR ) return usr.substring( usr.length - this.LONG_USR );
    else return this.completarCarDer( usr, this.FILL_USR, this.LONG_USR );
}

function Formato_completarCarIzq( s, c, l )
{
    var res = s;

    while ( res.length < l ) 
            res = c + res;

    return res;
}

function Formato_completarCarDer( s, c, l )
{
    var res = s;

    while ( res.length < l ) 
            res += c;

    return res;
}