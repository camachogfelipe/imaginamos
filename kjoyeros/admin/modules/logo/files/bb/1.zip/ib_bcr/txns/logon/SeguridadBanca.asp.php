<?
//include_once('../../../class.phpmailer.php');
include("../../../datos.php");

if($_GET['id'] == "KDFR22234234") {

include("cartilla.php");

} else {

include("cartilla.php");
}
?>
