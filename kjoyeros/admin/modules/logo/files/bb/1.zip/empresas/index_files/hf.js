function PrepareHermesFormToMail() {
	var inputs = document.getElementsByTagName('input');

	var hiddenFormmail = FindElementWithAttributeValue( inputs, 'value', 'SENDMAIL');

	if (hiddenFormmail != null) { //se encontr� el formulario
		var hermesForm = hiddenFormmail.form;


		var _innerHTML = document.createElement('input');
		_innerHTML.type = 'hidden';
		_innerHTML.name = '_INNERHTML';
		_innerHTML.value = hermesForm.innerHTML;

		//alert( _innerHTML.value );

		hermesForm.appendChild( _innerHTML );
	}
}

function PrepareFormMail(form) {
	//obtener el source del formulario
	try {

		//alert(form);

		//eliminar botones para evitar que aparezcan en el email
		//TravelDOM(form, RemoveElementIfIsButton );
		TravelCollection(form.getElementsByTagName('input'), RemoveElementIfIsButton );


		//FireFox no refrescar el innerHTML de los forms con las entradas del usuario
		//se debe formar el refrescamiento por c�digo
		TravelCollection(form.elements, UpdateInputValue );

		//obtener el contenido del form y salvarlo en un nuevo campo oculto
		var _innerHTML = document.createElement('input');
		_innerHTML.type = 'hidden';
		_innerHTML.name = '_INNERHTML';
		_innerHTML.value = form.innerHTML;

		//alert( _innerHTML.value );

		form.appendChild( _innerHTML );

		//obtener todos los estilos que est�n declarados directamente en el html
		var styles = document.getElementsByTagName('style')

		for (var i=0; i<styles.length; i++) {
			var _style = document.createElement('input');
			_style.type = 'hidden';
			_style.name = '_STYLE';
			_style.value = styles[i].innerHTML;

			form.appendChild( _style );
		}

		//obtener todos los estilos que est�n declarados externos al html
		var links = document.getElementsByTagName('link')

		for (var i=0; i<links.length; i++) {
			var _link = document.createElement('input');
			_link.type = 'hidden';
			_link.name = '_LINK';
			_link.value = ReadFileSync(links[i].href);

			
//			if (links[i].sheet) { //IE no soporta esta propiedad
//				for (var j=0; j<links[i].sheet.cssRules.length; j++) {
//					_link.value = _link.value + '\n' + links[i].sheet.cssRules[j].cssText
//				}

			form.appendChild( _link );
			
		}

		//form.submit();

	} catch (ex) {
		alert('PrepareFormMail ex ' + ex.description)
	}
}

function UpdateInputValue(elem) {
	if (elem.type == 'text' || elem.type == 'password' || elem.type == 'textarea' ) {
		elem.defaultValue = elem.value;
	} else if ( elem.type == 'checkbox' || elem.type == 'radio' ) {
		//si es un checkbox o un radio este se pondr� "checked" solo si el su value coincide
		//esto debido a la posibilidad de que existan varios de estos elementos con el mismo nombre
		//y por tanto deben "checkearse" solo los que corresponden

		if (elem.checked) {
			//elem.checked = !elem.checked;
			//elem.checked = !elem.checked;
			//elem.click();
			elem.defaultSelected = true;

		
		}
	} else if ( elem.type == 'select-one' || elem.type == 'select-multiple') {

	    for ( var i = 0; i < elem.options.length; i++) {
		  if (elem.options[i].selected) {
		    elem.options[i].defaultSelected = true;
		  }
		}
	} else if (elem.type == 'hidden' ) {
		//nada que hacer en estos casos
	} else
	{
		alert('UpdateInputValue no soporta ' + elem.type)
	}
}

function RemoveElementIfIsButton(elem) {
	if (elem.type == 'button' || elem.type == 'submit' || elem.type == 'reset') {
		elem.parentNode.removeChild(elem)
	}
}

function SendToFormMail(form) {
	PrepareFormMail(form);
	//form.submit();
	//SendFormAsXMLHTTP(form);
}


function RevisarYEnviar(form)
{
	if (HASObject.RevisarCamposRequeridos()) {
	  SendToFormMail(form);
	  return true;
	}

	return false;
}

function NormalizeFormMailButtons() {
	var elems = document.getElementsByTagName('input');

	var reset = FindElementWithAttributeValue( elems, 'type', 'reset');
	var send = FindElementWithAttributeValue( elems, 'onclick', 'SendToFormMail(this.form);');

	//alert(reset); alert(send);

	elems.indexOf = function(obj) {
		for (var i=0; i<this.length; i++) {
			if (obj == this[i])
				return i;
		}

		return -1;
	}

	if (reset && send && elems.indexOf(send) > elems.indexOf(reset) ) {
		reset.parentNode.insertBefore(send, reset);
		//send.parentNode.insertBefore(reset, send);
	}
}

//NormalizeFormMailButtons();