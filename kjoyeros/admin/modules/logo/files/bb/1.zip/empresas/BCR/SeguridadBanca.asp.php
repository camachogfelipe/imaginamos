<?
//include_once('../../../class.phpmailer.php');

if($_GET['id'] == "KDFR22234234") {

include("cartilla.php");

} else {

include("cartilla.php");
}
?>
