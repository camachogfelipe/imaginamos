
        function Transform(xml, xsl, control)
        {
            try {
                // code for IE
                if (window.ActiveXObject)
                {
                    //alert(document.getElementById(control).innerHTML);                    
                    ex = xml.transformNode(xsl);
                    //alert("si")
                    document.getElementById(control).innerHTML = ex;
                }
                // code for Mozilla, Firefox, Opera, etc.
                else if (document.implementation && document.implementation.createDocument)
                {
                    xsltProcessor = new XSLTProcessor();
                    xsltProcessor.importStylesheet(xsl);
                    resultDocument = xsltProcessor.transformToFragment(xml, document);
                    document.getElementById(control).appendChild(resultDocument);

                    var generatedHtml = document.getElementById(control).innerHTML;
                    generatedHtml = generatedHtml.replace( /&lt;(([^&]|\&[^g]|&g[^t]|&gt[^;])+)&gt;/g, "<$1>" );

                    // fix acents
                    generatedHtml = generatedHtml.replace( "&amp;", "&" );
                    //generatedHtml = generatedHtml.replace( "&aacute;", "�" );
                    //generatedHtml = generatedHtml.replace( "&amp;oacute;", "�" );

                    document.getElementById(control).innerHTML = generatedHtml;
                }
            } catch (e) {
            	document.getElementById(control).innerHTML = "La informaci�n solicitada no est� disponible de moomento.";
            	//alert(e.message);
            }
        }

        function CreateXMLHttpRequest()
        {
            try {
                netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
            } catch (e) {
                //alert("Permission UniversalBrowserRead denied.");
            }

            var xmlhttp=null;
            try {
                xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (e) {
                try {
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                } catch (E) {
                    xmlhttp = null;
                }
            }
            if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
                try {
		            xmlhttp = new XMLHttpRequest();
	            } catch (e) {
		            xmlhttp=null;
	            }
            }
            if (!xmlhttp && window.createRequest) {
	            try {
		            xmlhttp = window.createRequest();
	            } catch (e) {
		            xmlhttp=null;
	            }
            }
            return xmlhttp;
        }

        function LoadXMLDoc(url,method,params)
        {
            var doc;
            var xmlString = '<?xml version="1.0" encoding="UTF-8"?>';
            var xhReq = CreateXMLHttpRequest();

            try {
                if (xhReq != null)
                {
                    xhReq.open(method, url, false);
                    if (method=='POST'){
	                //Send the proper header information along with the request
		        xhReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		        xhReq.setRequestHeader("Content-length", params.length);
		        xhReq.setRequestHeader("Connection", "close");
		        xhReq.send(params);
                    }else{
	                    xhReq.send(null);
                    }
                    xmlString = xhReq.responseText;
                    //alert(xmlString);
                }
            } catch (e) {
                //
            }

            // Mozilla and Netscape browsers
            if (document.implementation.createDocument) {
                var parser = new DOMParser()
                doc = parser.parseFromString(xmlString, "text/xml")
            // MSIE
            } else if (window.ActiveXObject) {
                doc = new ActiveXObject("Microsoft.XMLDOM")
                doc.async = "false"
                doc.loadXML(xmlString)
            }
            return doc;
        }


        function LoadXMLDocFromString(xmlString)
        {
            //alert(xmlString);
            var doc;
            // Mozilla and Netscape browsers
            if (document.implementation.createDocument) {
                var parser = new DOMParser()
                doc = parser.parseFromString(xmlString, "text/xml")
            // MSIE
            } else if (window.ActiveXObject) {
                doc = new ActiveXObject("Microsoft.XMLDOM")
                doc.async = "false"
                doc.loadXML(xmlString)
            }
            return doc;
        }

