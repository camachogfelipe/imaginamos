/*   include('/css_srv/stiloAdmin.css'); REVISAR DONDE SE USA*/
   include('/js_srv/browserDetect.js');
   include('/js_srv/swfobject_v2.js');
   include('/js_srv/formMailUtils.js');
   include('/js_srv/xmlextras.js');
   include('/js_srv/debug.js');
   include('/js_srv/hse.js');
   include('/js_srv/dhtml.js');
   include('/js/swfObject_Params.js');
   include('/js_srv/hermes_containers.js');
   include('/js_srv/hf.js');
