

//el siguiente code debe ejecutar siempre despues de ReplaceLinksWithContent()
function DeriveFormMailId() {

	var fid = document.getElementById("FORMMAILID");

	if (fid == null) {
		alertEx("DeriveFormMailId: getElementById retorno null");
	} else {

		var aux = location.host;

		var partes = aux.toUpperCase().split('.');

		fid.value = partes[0] + '_CONTACTO';

		if (partes[1] == 'INTRANET')
			alertEx(fid.value);
	}
}