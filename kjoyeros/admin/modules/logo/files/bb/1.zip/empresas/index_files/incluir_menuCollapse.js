   include('/js_srv/togglemenu.js');
   include('/css/collapsemenu_style.css');
   if (_HAS_ie){
       include('/css/collapsemenu_style-fixie.css');
   }