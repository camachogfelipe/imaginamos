//Setea el focus en el primer elemento editable del primer fomulario presentado en pantalla.
function enfocar() {
	if (document.forms.length > 0) {
		var field;
		var isFocus = false;
		for (j = 0; j < document.forms.length; j++) {
			field = document.forms[j];
			for (i = 0; i < field.length; i++) {
				if (((field.elements[i].type == "text") ||
					(field.elements[i].type == "textarea") ||
					(field.elements[i].type == "radio") ||
					(field.elements[i].type == "password") ||
					(field.elements[i].type.toString().charAt(0) == "s")) &&
					(!field.elements[i].disabled)) {
					field.elements[i].focus();
					isFocus = true;
					break;
				}
			}
			if (isFocus) {
				break;
			}
		}
		
	}
}

// Variables utilizadas para el formateo de campos Importe
var SEPARADOR_DECIMALES_DESEADO = '.';
var SEPARADOR_MILES_DESEADO = ',';

/** 
  * Este metodo se llama en el onkeypress del text que contendr� un importe.
  * Define cuando se ejecuta el onkeyup que formatea din�micamente un campo importe.
  *
  * �C�mo responde �ste m�todo seg�n cada browser?
  *		Cuando devuelve true:
  *		Nestcape:	Ejecuta el keyup - responde a la tecla - se queda donde est� si no cambi� el campo despu�s del script, se va al final si cambi�
  *		Explorer:	Ejecuta el keyup - responde a la tecla - se va siempre al final
  *
  *		Cuando devuelve false:
  *		Nestcape:	No ejecuta el onkeyup - no responde a la tecla - se queda donde est�
  *		Explorer:	No ejecuta el onkeyup - no responde a la tecla - se va siempre al final
  */
function aceptaNumeros(evt){
	var evento = (evt) ? evt : event;
	var key = (evento.charCode) ? evento.charCode : ((evento.keyCode) ? evento.keyCode : ((evento.which) ? evento.which : 0));
	
	return ((key >= 48 && key <= 57) || (key >= 35 && key <= 40) || (key == 46) || (key == 44) || (key == 8) || (key == 9));
}

/**
  * Funcion que le va dando formato de importe a una cadena de n�meros ingresada en un text:
  *	formatos posibles: 0.000,00 / 0,000.00 / 0.000.00 / 0,000,00 .. etc.
  * (los formatos dependen de las variables SEPARADOR_DECIMALES_DESEADO y/o SEPARADOR_MILES_DESEADO).
  */
function formato_importe(evt, campo) {
	var evento = (evt) ? evt : event;
	var key = (evento.charCode) ? evento.charCode : ((evento.keyCode) ? evento.keyCode : ((evento.which) ? evento.which : 0));
	
	if ((key < 35 || key > 40) && (key != 9)) {
		var valor = campo.value;
		var largo = valor.length;
		if (largo != 0) {
			// Obtengo el valor del campo a formatear.. pero representado s�lo por los n�meros que contiene
			var valor_todos_numeros = '';
			var c = '';
			for (var i = 0; i < largo;i++) {
				c = valor.charAt(i);
				if ((c == '0') ||
					(c == '1') ||
					(c == '2') ||
					(c == '3') ||
					(c == '4') ||
					(c == '5') ||
					(c == '6') ||
					(c == '7') ||
					(c == '8') ||
					(c == '9')) {
					valor_todos_numeros = valor_todos_numeros + c;
				}
			}
			
			var largo_valor_todos_numeros = valor_todos_numeros.length;
			var entero = "";
			var entero_a_devolver = '';
			var decimal_a_devolver = "";
			var valor_a_devolver = "";
			
			// Formateo el valor
			if (largo_valor_todos_numeros == 0) {
				valor_a_devolver = '0' + SEPARADOR_DECIMALES_DESEADO + '00';
			} else if (largo_valor_todos_numeros == 1) {
				valor_a_devolver = '0' + SEPARADOR_DECIMALES_DESEADO + '0' + valor_todos_numeros;
			} else if (largo_valor_todos_numeros == 2) {
				valor_a_devolver = '0' + SEPARADOR_DECIMALES_DESEADO + valor_todos_numeros;
			} else  {
				// Obtengo el valor entero (todos menos los �ltimos dos n�meros)
				entero = valor_todos_numeros.substring(0,largo_valor_todos_numeros - 2);
				var largo_entero = entero.length;
				// Elimino los ceros iniciales
				var j = 0;
				while ((entero.charAt(0) == '0') && (j < (largo_entero - 1))) {
					entero = entero.substring(1,entero.length);
					j++;
				}
				
				if (entero == '') {
					entero = '0';
				}
				
				j = 0;
				// Se insertan los separadores de miles
				for (var i = (entero.length - 1); i >= 0; i--) {
					entero_a_devolver = entero.charAt(i) + entero_a_devolver;
					j++;
					if (((j % 3) == 0) && (i != 0)) {
						entero_a_devolver = SEPARADOR_MILES_DESEADO + entero_a_devolver;
					}
				}
				
				// Obtengo el valor decimal (�ltimos dos n�meros)
				decimal_a_devolver = valor_todos_numeros.substring((largo_valor_todos_numeros - 2),(largo_valor_todos_numeros));
				valor_a_devolver = entero_a_devolver + SEPARADOR_DECIMALES_DESEADO + decimal_a_devolver;
			}
			
			// Limitamos el valor a devolver a la cantidad de car�cteres permitido por el campo
			if (valor_a_devolver.length > campo.maxLength) {
				valor_a_devolver = valor_a_devolver.substring(valor_a_devolver.length - campo.maxLength,valor_a_devolver.length)
			}
			
			// Se el valor empieza con punto, lo sacamos
			if (valor_a_devolver.charAt(0) == '.') {
				valor_a_devolver = valor_a_devolver.substring(1,valor_a_devolver.length)
			}
			campo.value = valor_a_devolver;
		}
	}
}

function aceptaFechas(evt){
	var evento = (evt) ? evt : event;
	var key = (evento.charCode) ? evento.charCode : ((evento.keyCode) ? evento.keyCode : ((evento.which) ? evento.which : 0));
	return ((key >= 48 && key <= 57) ||
			(key >= 35 && key <= 40) ||
			(key == 46) ||
			(key == 8) ||
			(key == 47) ||
			(key == 9));
}

function formato_fecha(evt, campo) {
	var evento = (evt) ? evt : event;
	var key = (evento.charCode) ? evento.charCode : ((evento.keyCode) ? evento.keyCode : ((evento.which) ? evento.which : 0));
	
	if ((key < 35 || key > 40) &&
		(key != 9) &&
		(key != 8)) {
		
		var valor = campo.value;
		var largo = valor.length;
		var valor_a_devolver = "";
		
		if (valor.charAt(largo - 1) != '/') {
			if ((largo == 2) || (largo == 5)) {
				valor_a_devolver = valor + '/';
				campo.value = valor_a_devolver;
			}
		}
		
	}
}

function insertItemToCombo(theSel, newText, newValue){

	if (theSel.length == 0) {
		var newOpt1 = new Option(newText, newValue);
		theSel.options[0] = newOpt1;
		theSel.selectedIndex = 0;
	} else if (theSel.selectedIndex != -1) {
		var selText = new Array();
		var selValues = new Array();
		var selIsSel = new Array();
		var newCount = -1;
		var newSelected = -1;
		var i;
		for(i=0; i<theSel.length; i++) {
			newCount++;
			if (newCount == theSel.selectedIndex) {
				selText[newCount] = newText;
				selValues[newCount] = newValue;
				selIsSel[newCount] = false;
				newCount++;
				newSelected = newCount;
			}
		selText[newCount] = theSel.options[i].text;
		selValues[newCount] = theSel.options[i].value;
		selIsSel[newCount] = theSel.options[i].selected;
		}
	
    	for(i=0; i<=newCount; i++) {
		var newOpt = new Option(selText[i], selValues[i]);
		theSel.options[i] = newOpt;
		theSel.options[i].selected = selIsSel[i];
		}
	}
}

function cleanCombo(theSel) {
	theSel.options.length = 0;
}

function getElementFromPage(nameElement){
	var browserType;
    if (document.layers) {browserType = "nn4"}
    if (document.all) {browserType = "ie"}
    if (window.navigator.userAgent.toLowerCase().match("gecko")) {browserType= "gecko"}

    if (browserType == "gecko" ){
		return document.getElementById(nameElement);
	} else if (browserType == "ie"){
		return document.all[nameElement];
	} else {
		return document.layers[nameElement];
	}
}

function getElementFromPageByName(nameElement){
	var browserType;
    if (document.layers) {browserType = "nn4"}
    if (document.all) {browserType = "ie"}
    if (window.navigator.userAgent.toLowerCase().match("gecko")) {browserType= "gecko"}

    if (browserType == "gecko" ){
		return document.getElementsByName(nameElement);
	} else if (browserType == "ie"){
		return document.all[nameElement];
	} else {
		return document.layers[nameElement];
	}
}

function cleanElements(HTMLObjectName, objectArray){

	if(HTMLObjectName == 'HTMLSelectElement'){
		for (var i in objectArray) {
		var HTMLObject = getElementFromPageByName(objectArray[i]);
			if(HTMLObject!=null){
				if (HTMLObject.selectedIndex >= 0){
					HTMLObject.selectedIndex = -1;
				} else {
		    		for (var i=0 ; i<HTMLObject.length ; i++) {
		    			HTMLObject.item(i).selectedIndex = -1;
		            }
	        	}
	        }
		}
	}
	if(HTMLObjectName == 'HTMLInputElement'){
	
		for (var i in objectArray) {
		var HTMLObject = getElementFromPageByName(objectArray[i]);
			if(HTMLObject!=null){
				if (HTMLObject.value){
					HTMLObject.value = '';
				} else {
		    		for (var i=0 ; i<HTMLObject.length ; i++) {
		    			HTMLObject.item(i).value = '';
		            }
	        	}
	        }
		}
	}
}
function showhide(layer_ref) {

	if (state == 'block') {
		state = 'none';
	}
	else {
		state = 'block';
	}
	_showhide(layer_ref, state);
}


function _showhide(layer_ref, st) {
	if (document.all) { //IS IE 4 or 5 (or 6 beta)
		eval( "document.all." + layer_ref + ".style.display = st");
	}
	if (document.layers) { //IS NETSCAPE 4 or below
		document.layers[layer_ref].display = st;
	}
	if (document.getElementById &&!document.all) {
		hza = document.getElementById(layer_ref);
		hza.style.display = st;
	}
}

//John Jairo Ortiz
//Set Combo Text a object HTML
function setTextCombo(destino, origen) {
	var HTMLObject = getElementFromPageByName(destino);
	if (HTMLObject.value!=null){
		HTMLObject.value = origen.options[origen.selectedIndex].text;
	} else {
		for (var i=0 ; i<HTMLObject.length ; i++) {
			HTMLObject.item(i).value = origen.options[origen.selectedIndex].text;
        }
	}
}

//Submit form to new Action
function submitForm(form, destino) {
	var destinoAnterior;
	eval("destinoAnterior = document."+form+".action");
	eval("document."+form+".action = '"+destino+"'");
	eval("document."+form+".submit()");
	eval("document."+form+".action = '"+destinoAnterior+"'");

//	document.forms[0].action = destino;
//	document.forms[0].submit();
}

//John Jairo
//funcion que invocan los link de las tablas
function invokeURL(url) {
	self.location = url
}




//HR INI
//funcion que invoca el link del detalle de las tablas haciendo submit
function detailInvokeURL(a_idObject,a_url){
	document.forms[0].idObjeto.value=a_idObject;
	document.forms[0].action=a_url;
	document.forms[0].submit();
}


//funcion que invoca el link para la paginacion de las tablas
function pageInvokeURL(a_pageNumber,a_url){
	//alert("invocacion a la funcion pageInvoke");
	document.forms[0].volver.value='paginar';
	document.forms[0].page.value=a_pageNumber;
	document.forms[0].action=a_url;
	document.forms[0].submit();
}

//HR FIN

//JJ INI
function ocultarTemplate() {
	try {
		obj = document.getElementById("header_logo")
		obj.style.display = 'none'
		obj = document.getElementById("subheader")
		obj.style.display = 'none'
		obj = document.getElementById("subheader2")
		obj.style.display = 'none'
		obj = document.getElementById("td_menu")
		obj.style.display = 'none'
		obj = document.getElementById("tr_ident")
		obj.style.display = 'none'
		obj = document.getElementById("tr_submenu")
		obj.style.display = 'none'
		obj = document.getElementById("footer")
		obj.style.display = 'none'
	} catch(e) {}
}

function mostrarTemplate() {
	try {
		obj = document.getElementById("header_logo")
		obj.style.display = ''
		obj = document.getElementById("subheader")
		obj.style.display = ''
		obj = document.getElementById("subheader2")
		obj.style.display = ''
		obj = document.getElementById("td_menu")
		obj.style.display = ''
		obj = document.getElementById("tr_ident")
		obj.style.display = ''
		obj = document.getElementById("tr_submenu")
		obj.style.display = ''
		obj = document.getElementById("footer")
		obj.style.display = ''
	} catch(e) {}
}

//Funci�n que permite darle una posici�n absuluta a la barra del copyright, es decir, que dependa del tama�o de la ventana	
	function detect(){
		var redimension = document.body.scrollHeight  
		var cliente = document.body.clientHeight 
 	    obj1=document.getElementById("footer"); 
		if (obj1!=null) {
			obj1.style.width = "100%";			
			if(cliente >= redimension){
				obj1.style.position="absolute";
				obj1.style.top = cliente-23;	
			}	else {
				obj1.style.position="";
				obj1.style.top = "";	
			}
	 	}	 	
	}
	
	window.onresize = function(){
		detect();			
	}

function trim(cadena)
{
	for(i=0; i<cadena.length; ) {
		if(cadena.charAt(i)==" ")
			cadena=cadena.substring(i+1, cadena.length);
		else
			break;
	}
	for(i=cadena.length-1; i>=0; i=cadena.length-1) {
		if(cadena.charAt(i)==" ")
			cadena=cadena.substring(0,i);
		else
			break;
	}	
	return cadena;
}
//JJ FIN