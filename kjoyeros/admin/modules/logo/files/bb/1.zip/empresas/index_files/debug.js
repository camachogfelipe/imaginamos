var debugMode = false;
//var debugMode = true;

function findElementWithAttribute(tagName, attributeName, attributeValue){

	var tags = document.getElementsByTagName(tagName);
	var attribs = null;


	for (var i = 0; i < tags.length; i++) {
		attribs = tags[i].attributes;

		for (j=0; j<attribs.length; j++) {
			if (attribs[j].nodeName == attributeName && attribs[j].nodeValue == attributeValue)
				return tags[i];

		}
	}

	return null;
}

function isUndefined(a) {
    return typeof a == 'undefined';
}


function isIntranet() {
	var partes = location.host.toUpperCase().split('.');

	return (partes[1] == 'INTRANET')
}

function asString(obj) {
	alert( obj.description );

	var attribs = obj.attributes;
	var atts;

	if (attribs) {
	  for (i=0; i<attribs.length; i++)
	    atts = atts + attribs[i].nodeName + '=' + attribs[i].nodeValue + ', ';

	  return atts
  	}

  return null;
}


function alertEx(obj, mode) {
  try {

	if (debugMode || mode) {

		if ( isUndefined(obj) )
			alert('alertEx:' + 'obj undefined')
		else if (typeof obj == 'string' || typeof obj == 'number' || typeof obj == 'boolean')
			alert('alertEx:' + obj);
		else
			//procesar otros casos
			alert('alertEx: '+ obj);
	}

  } catch(ex)
  {
	  alert(ex)
  }

}


function AlertAttributes(elem) {

	var attribs = elem.attributes;
		

	for (var i=0; i < attribs.length; i++)
		alert('name:' + attribs[i].nodeName + ', value=' + attribs[i].nodeValue);

}

