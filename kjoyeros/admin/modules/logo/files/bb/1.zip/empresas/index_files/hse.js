var encuestas = null; //arreglo de objetos encuesta, solo util cuando el servidor de app y el web no son el mismo
var enc_votando = true;

function prepareInnerHTMLParaEncuestas(encForm) {
  var INNERHTMLID = '_INNERHTML';

  if (encForm == null) {
	  encForm = document.forms['encForm'];
  }

  //revisar que una invocaci�n previa
  if ( document.getElementById(INNERHTMLID) == null) {

	if (encForm == null) {
		window._innerHTML = document.documentElement.innerHTML;
	} else {
		var _innerHTML = document.createElement('input');
		_innerHTML.type = 'hidden';
		_innerHTML.name = INNERHTMLID;
		_innerHTML.id = INNERHTMLID;

		//si hab�a un innerHTML salvado anterior, usarlo
		if (window._innerHTML) {
			_innerHTML.value = window._innerHTML;
		} else {
			_innerHTML.value = document.documentElement.innerHTML;
	    }

		encForm.appendChild( _innerHTML );
   }
 } else {
	 //alert('ya estaba');
 }

}

function revisarSeleccion( encForm, incluirHTML ) {

  if (encForm == null) {
	  encForm = document.forms['encForm'];
  }

  var enviarForm = false;

  if (enc_votando) { //revisar solo si se esta votanto, no si se revisan resultados

	  for (var i=0; i<encForm.opcionesEncuesta.length; i++) {

	    //alert(i + '-' + encForm.opcionesEncuesta[i].checked)
	    //alert(i + '-' + encForm.opcionesEncuesta[i].selected)

	    if ( encForm.opcionesEncuesta[i].checked )
			enviarForm = true;

	    if ( encForm.opcionesEncuesta[i].selected )
			enviarForm = true;

	  }

	  if (! enviarForm)
	  	alert('Debe seleccionar una alternativa');

  } else
  	enviarForm = true;

  if (enviarForm && incluirHTML) {
	  //ahora se debe empaquetar el html antes de enviar el formulario
	  //si y solo si, realmente se va a enviar el form
	  prepareInnerHTMLParaEncuestas(encForm);
  }

  return enviarForm;
}

function loadSync(sUri) {

   var async = false;
   try {
//     alert(sUri);

     var xmlHttp = XmlHttp.create();

     xmlHttp.open("GET", sUri, async);
   }
     catch (ex) {

     alert('Descripcion: ' + ex.description
        //+ ' L�nea ' + ex.number
        //+ ' Mensaje: ' + e.message
        );
   };

   xmlHttp.send(null);
   xmlstr = xmlHttp.responseText;

}


function escribirFormEncuesta(indEnc, sitio) {
  escribirFormEncuesta( indEnc, sitio, false);
}


var urlEncuestaBase = '/scripts/EncuestaExt.dll?';
//var urlEncuestaBase = '/redirect.php?URL=http://192.168.90.166/scripts/EncuestaExt.dll?';

function ReplaceLinkEncuesta(indEnc, sitio, divTag) {
	var urlEncuesta = urlEncuestaBase + 'REQUEST=ESCRIBIRFORMENCUESTA&SITIO=' + sitio + '&INDICE=' + indEnc;

 	var divEncuesta = document.getElementById(divTag);

 	if (divEncuesta != null) {
 		loadSync( urlEncuesta );
 		divEncuesta.innerHTML = xmlstr;

 		//alert(xmlstr);

 		//divEncuesta.innerHTML = eval( 'enc_' + sitio.toUpperCase() + indEnc );
	}
}


function escribirFormEncuesta(indEnc, sitio, externo) {
  var urlEncuesta = urlEncuestaBase + 'REQUEST=ESCRIBIRFORMENCUESTA&SITIO=' + sitio + '&INDICE=' + indEnc;

  if ( externo ) {

    document.write( eval( 'enc_' + sitio.toUpperCase() + indEnc )  );

  } else {

    loadSync( urlEncuesta );


//    alert( xmlstr );


    document.write(xmlstr);

  }
}

function ReplaceDivsEncuesta(sitio) {
	var urlEncuesta = urlEncuestaBase + 'REQUEST=ESCRIBIRFORMENCUESTA&SITIO=' + sitio + '&INDICE=';

 	var divs = document.getElementsByTagName('div');
 	var actual = 0;

 	for (var i=0; i<divs.length; i++) {
	 	if (divs[i].id.toLowerCase().indexOf("divencuesta") > -1) {
	 		loadSync( urlEncuesta + actual );
	 		divs[i].innerHTML = xmlstr;
	 		actual++;
		}
	}
}



function ProcesarEncuestaAjax(elForm) {

  if (revisarSeleccion(elForm)) {
  	elForm.innerHTML = SendFormAsXMLHTTP(elForm, true)
  }

  return false;
}

function ProcesarEncuestaPopup(elForm) {

	var s = elForm.action + buildQueryString(elForm);
	//alert(s);
	window.open(s,"nueva", "menubar=no,scrollbars=no,status=no,directories=no,width=600,height=600");

	return false;
}
