/**
 * @author Jorge Villalobos
 */

/**
* Function : dump()
* Arguments: The data - array,hash(associative array),object
*    The level - OPTIONAL
* Returns  : The textual representation of the array.
* This function was inspired by the print_r function of PHP.
* This will accept some data as the argument and return a
* text that will be a more readable version of the
* array/hash/object that is given.
*/
function dump(arr,limit,level) {
	var dumped_text = "";

	if(!level) level = 0;

	//The padding given at the beginning of the line.
	var level_padding = "";
	for(var j=0;j<level+1;j++) level_padding += "    ";

	if(typeof(arr) == 'object') { //Array/Hashes/Objects
		for(var item in arr) {
			var value = arr[item];

			if(typeof(value) == 'object') { //If it is an array,
				dumped_text += level_padding + "'" + item + "' ...\n" + "<br>";
				if (level < limit)
				    dumped_text += dump(value,limit,level+1);
			} else {
				dumped_text += level_padding + "'" + item + "' => \"" + value + "\"\n" + "<br>";
			}
		}
	} else { //Stings/Chars/Numbers etc.
		dumped_text = "===>"+arr+"<===("+typeof(arr)+")";
	}
	return dumped_text;
}

function convertHermesContainer(){
	var tabContainer_number=0;
	var formContainer_number=0;
	var table_index =0;
	var trIndex;
	var tdIndex;
	var tables;
	var element;
	var eleParent;
	var tableContainer;
	var tabsDiv;
	var tabsElementsCollection;
	var tmpRow;
	var tmpCell;
	var newul;
	var newli;
	var newanchor;
	var newspaninicio;
	var newspanmedio;
	var newspanfin;
	var newspancontent;
	var tabContentDiv;
	var newscript;
	var incluidoIdTabsScript=false;
	var obj;
	var tmpCellIndex;
	var tmpCellChildren;


	var head = document.getElementsByTagName('head')[0];

	tables = document.getElementsByTagName('TABLE');
	while (table_index < tables.length) {
		tableContainer = tables.item(table_index);
		//alert(tableContainer);
		if (tableContainer.className.match('HERMESTABS') != null){
			if (false){
				newscript = document.createElement('link');
				newscript.type="text/css";
				newscript.rel="stylesheet";
				newscript.href="tabs_style.css";
				head.appendChild(newscript);

				newscript = document.createElement('script');
				newscript.src="jquery.idTabs.pack.js";
				newscript.type="text/javascript";
				head.appendChild(newscript);

				incluidoIdTabsScript = true;
			}
			tabContainer_number++;
			eleParent = tableContainer.parentNode;
			tmpRow = tableContainer.rows[1].cells[0];




			tdIndex = 0;
			while (tmpRow.childNodes[tdIndex].id != "HERMES_TABS"){
				//alert(dump(tmpRow.childNodes[tdIndex].className,2,3));
				tdIndex++;
			}



			element = tmpRow.childNodes[tdIndex];

			tabsDiv = document.createElement('div');
			tabsDiv.id ="HERMES_TABS_"+tabContainer_number;
			tabsElementsCollection = element.rows;
			for (trIndex=0; trIndex <tabsElementsCollection.length ;trIndex++){
				if (trIndex == 0){
					newul = document.createElement('ul');
					tmpRow = tabsElementsCollection[trIndex];
					for(tdIndex=0; tdIndex < tmpRow.cells.length;tdIndex++ ){
						newli = document.createElement('li');
						newanchor = document.createElement('a');
						newanchor.href="#HERMES_TABS_"+tabContainer_number+'_'+tdIndex;
						newanchor.id = "_HERMES_TABS_" + tabContainer_number+'_'+tdIndex;
						newspaninicio = document.createElement('div');
						newspanmedio = document.createElement('div');
						newspanfinal = document.createElement('div');
						newspancontent = document.createElement('span');
						newspaninicio.className = 'HERMES_TAB_INICIO';
						newspanmedio.className = 'HERMES_TAB_MEDIO';
						newspanfinal.className = 'HERMES_TAB_FINAL';
						newspancontent.className = 'HERMES_TAB_CONTENT';


						tmpCellChildren = tmpRow.cells[tdIndex].childNodes;
						for (tmpCellIndex=0; tmpCellIndex < tmpCellChildren.length;tmpCellIndex++){
							if (tmpCellChildren[tmpCellIndex].tagName == 'P') {
								newspancontent.appendChild(tmpCellChildren[tmpCellIndex]);
							}
						}
						newspanfinal.appendChild(newspancontent);
						newspanmedio.appendChild(newspanfinal);
						newspaninicio.appendChild(newspanmedio);
						newanchor.appendChild(newspaninicio);
						newli.appendChild(newanchor);
						newul.appendChild(newli);
					}
					tabsDiv.appendChild(newul);
				}
				else{
					tmpRow = tabsElementsCollection[trIndex];
					tabContentDiv =  document.createElement("div");
					tabContentDiv.id = "HERMES_TABS_"+tabContainer_number+'_'+(trIndex-1);
					tabContentDiv.innerHTML = tmpRow.cells[0].innerHTML;
					tabsDiv.appendChild(tabContentDiv);
				}
			}
			eleParent.replaceChild(tabsDiv,tableContainer);
			newscript = document.createElement('script');
		    newscript.text = 'jQuery("#'+tabsDiv.id +'").tabs({ fx: { height: \'toggle\' } });';
			head.appendChild(newscript);
		}


		else if (tableContainer.className.match('HERMESFORMS') != null){
			formContainer_number++;
			eleParent = tableContainer.parentNode;
			tmpCell = tableContainer.rows[1].cells[0];
			formDiv = document.createElement('div');
			formDiv.id = 'HERMES_FORM_' + formContainer_number;
			formDiv.innerHTML = tmpCell.innerHTML;
//			alert(tmpCell.innerHTML);
			eleParent.replaceChild(formDiv,tableContainer);
		}
		else {
			//Para poder hacerlo anidado
			table_index++;
		}
	}
}

