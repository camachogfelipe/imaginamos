<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$config['useragent'] = 'R';
$config['mailtype'] = 'html';
$config['protocol'] = 'mail';
$config['smtp_host'] = 'ssl://smtp.googlemail.com';
$config['smtp_user'] = 'admin@imaginamos.com.co';
$config['smtp_pass'] = 'Soporte2009';
$config['smtp_port'] = '465';