<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['appId'] = '294256367352979';
$config['secret'] = 'dcccadbb3f6a76cd4eac934427e238b4';