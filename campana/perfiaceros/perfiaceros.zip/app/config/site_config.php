<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['social_urls'] = (object) array(
    'facebook' => 'http://fb.me/veego.co',
    'twitter' => 'http://twitter.com/veegoco',
    'youtube' => 'http://www.youtube.com/channel/UCANGi9B4Q8UjiSwmKWbecqw'
);


$config['emails'] = (object) array(
    'from' => 'mailing@veego.co',
    'from_name' => 'Veego',
    
    'to' => array('rigo.castro@imaginamos.co', 'admin@veego.co')
);