# Imaginamos CMS

Versión estable actual : 1.6.1

## Team

* [Rigo B castro]
* [Jose Fonseca](http://josefonseca.me/)

## Description

CMS Para uso general en Imginamos

### Contribuidores

Para estar en la lista por favor hacer pull request.